package com.loandlt.cordapp.service.investor.controller;

import com.loandlt.cordapp.service.investor.model.request.AppointServicerRequest;
import com.loandlt.cordapp.service.investor.model.response.LoanResponse;
import com.loandlt.cordapp.service.investor.service.InvestorService;
import net.corda.core.crypto.SecureHash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * <h1>Investor<h1/>
 * A Investor API Controller class manages the loans.
 *
 * @author Synechron Technology
 * @version 0.1
 * @see InvestorService
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/investor")
public class InvestorApiController implements InvestorApi {

    @Autowired
    private InvestorService investorService;

    /**
     * {@inheritDoc}
     */
    @Override
    @PostMapping("/loans")
    public ResponseEntity appointServicer(@RequestBody AppointServicerRequest appointServicerRequest) {
        SecureHash secureHash = investorService.appointServicer(appointServicerRequest);
        return new ResponseEntity<>(secureHash, HttpStatus.CREATED);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @GetMapping("/loans/{loanId}")
    public ResponseEntity<LoanResponse> getLoan(@PathVariable String loanId) {
        LoanResponse loanResponse = investorService.getLoan(loanId);
        return new ResponseEntity<>(loanResponse, HttpStatus.OK);
    }
}
