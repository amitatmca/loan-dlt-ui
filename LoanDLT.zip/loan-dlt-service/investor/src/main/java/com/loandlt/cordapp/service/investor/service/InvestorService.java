package com.loandlt.cordapp.service.investor.service;

import com.loandlt.cordapp.service.investor.model.request.AppointServicerRequest;
import com.loandlt.cordapp.service.investor.model.response.LoanResponse;
import net.corda.core.crypto.SecureHash;

/**
 * <h1>Investor<h1/>
 * A Service interface provides method to manage the loans..
 *
 * @author Synechron Technology
 * @version 0.1
 * @see InvestorServiceImpl
 */
public interface InvestorService {

    /**
     * This method responsible to call the DAO method to appoint servicer for Investor.
     * <p>
     * This method converts request model to entity of CordApp and call the DAO method.
     *
     * @param appointServicerRequest - Appoint servicer request
     * @return SecureHash - Hash of transaction.
     */
    SecureHash appointServicer(AppointServicerRequest appointServicerRequest);


    /**
     * A method calls DAO method to fetch loan state and loan snapshots.
     *
     * @param loanId
     * @return - LoanResponse model
     */
    LoanResponse getLoan(String loanId);

}
