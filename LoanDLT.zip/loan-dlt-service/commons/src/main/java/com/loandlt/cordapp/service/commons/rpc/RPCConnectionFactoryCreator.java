package com.loandlt.cordapp.service.commons.rpc;

public class RPCConnectionFactoryCreator {
    public static RPCConnectionFactory getInstance(RpcHostPort rpcHostPort, String userName, String password) {
        return new RPCConnectionFactory(rpcHostPort, userName, password);
    }
}