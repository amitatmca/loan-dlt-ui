package com.loandlt.cordapp.service.commons.exception;

public enum ErrorCode {
    EXCEPTION("1000", "Internal server error. ", ""),
    PARTY_NOT_FOUND("1001", "Party not found on the network. ", ""),
    INVALID_X500_NAME("1003", "Invalid X500 name of corda party. ", ""),
    INVALID_DATE_FORMAT("1004", "Invalid date format. ", "");

    private final String code;
    private final String description;
    private String placeHolder;

    ErrorCode(String code, String description, String placeHolder) {
        this.code = code;
        this.description = description;
        this.placeHolder = placeHolder;
    }

    public String getDescription() {
        return description;
    }

    public String getCode() {
        return code;
    }

    public String getPlaceHolder() {
        return placeHolder;
    }

    @Override
    public String toString() {
        return code + ": " + description;
    }
}
