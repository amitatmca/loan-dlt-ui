package com.loandlt.cordapp.service.commons.rpc;

import net.corda.core.messaging.CordaRPCOps;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import javax.annotation.PreDestroy;

/**
 * Class to initiate RPCConnection on request
 */
@RequestScope
@Component
public class RPCConnection {

    @Autowired
    private RPCConnectionManager RPCConnectionManager;

    private final Log logger = LogFactory.getLog(this.getClass());

    private CordaRPCOps cordaRPCOps = null;

    //private RpcUser rpcUser;

    /**
     * This methods returns RPC connection object back to the pool using its key.
     * Once the request is processed the method is invoked before beans gets destroyed.
     * It uses key to put object back to the pool.
     * The object is validated before it is added back to pool.
     * If validatiion fails the returning object is destroyed.
     */
    @PreDestroy
    void destroy() {
        logger.info("Calling destroy method of RPCConnection");
        if (cordaRPCOps != null) {
            logger.info("Returning CordaRPCOPs object");
            //RPCConnectionManager.returnConnection(rpcUser,cordaRPCOps);
            //RPCConnectionManager.returnConnection(cordaRPCOps);
        }
    }
}
