package com.loandlt.cordapp.service.commons.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.http.HttpStatus;

public class ErrorResponse {
    @JsonProperty("result_code")
    private String resultCode;

    @JsonProperty("status")
    private HttpStatus status;

    @JsonProperty("message")
    private String message;

    public ErrorResponse() {
    }

    public ErrorResponse(String message, String resultCode, HttpStatus status) {
        this.message = message;
        this.resultCode = resultCode;
        this.status = status;
    }

    /**
     * @return the Result Code
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     * @param resultCode
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    /**
     * @return the Status
     */
    public HttpStatus getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    /**
     * @return the Error Message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ErrorResponse [resultCode=" + resultCode + ", status=" + status + ", message=" + message + "]";
    }
}
