package com.loandlt.cordapp.service.commons.model.response;

public class TransactionInfo {

    private String datetime;
    private String txHash;
    private String notary;
    private String txNote;

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getTxHash() {
        return txHash;
    }

    public void setTxHash(String txHash) {
        this.txHash = txHash;
    }

    public String getNotary() {
        return notary;
    }

    public void setNotary(String notary) {
        this.notary = notary;
    }

    public String getTxNote() {
        return txNote;
    }

    public void setTxNote(String txNote) {
        this.txNote = txNote;
    }
}
