package com.loandlt.cordapp.service.commons.model.request;

public class MembershipRequest {
    private String businessRole;
    private String displayName;

    public String getBusinessRole() {
        return businessRole;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setBusinessRole(String businessRole) {
        this.businessRole = businessRole;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
}