package com.loandlt.cordapp.service.servicer.dao;

import org.springframework.stereotype.Repository;

/**
 * A DAO class provides method to call CordApp through RPCConnection.
 *
 * @author Synechron Technology
 * @version 0.1
 */
@Repository
public class ServicerDaoImpl implements ServicerDao {

    // Implements methods
}
