package com.loandlt.cordapp.service.servicer.dao;


/**
 * A DAO interface provides method to call CordApp through RPCConnection.
 *
 * @author Synechron Technology
 * @version 0.1
 */
public interface ServicerDao {
//Declare Methods
}
