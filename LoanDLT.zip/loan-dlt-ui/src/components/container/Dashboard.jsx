import React, { Component } from 'react';
import Header from '../container/Header';
import AppServices from '../../services/index';
import config from 'react-global-configuration';
import ReactFileReader from 'react-file-reader';
import {Growl} from 'primereact/growl';

class Dashboard extends Component{
    constructor(props) {
        super(props);      
        this.handleFiles = this.handleFiles.bind(this);
    }

    /** 
     * Function to set Page Title of Application
    */
    componentDidMount(){
        document.title = config.get('pageTitle')
    }

    /** 
     * Function to upload file
    */
    handleFiles = files => {
        var reader = new FileReader();
        reader.onload = (e) => {
            let jsonData = reader.result.split('\n');        
            console.log("TCL: Dashboard -> reader.onload -> reader.result", reader.result)
            console.log("TCL: Dashboard -> reader.onload -> jsonData", jsonData)
            let param;
            jsonData.forEach((element, index) => {
                if(index) {
                    const elementRaw = element.split(',');
                    console.log(element, index);
                    if(elementRaw[0]) {
                        param = {
                            'loanId' : elementRaw[0],
                            'servicer' : elementRaw[1],
                            'msrOwner' : elementRaw[2],
                            'unpaidPrincipalBalance' : parseFloat(elementRaw[3]),
                            'dueDate' : elementRaw[4],
                            'noteRate' : parseFloat(elementRaw[5]),
                            'pmtCalcPrincipal' : parseFloat(elementRaw[6]),                             
                            'pmtCalcTerm' : parseInt(elementRaw[7]),
                            'indexCode' : elementRaw[8],
                            'firstRateChangeDate' : elementRaw[9],
                            'rateChangeFrequency' : parseInt(elementRaw[10]),
                            'rateMargin' : parseFloat(elementRaw[11]),
                            'corporateAdvanceBalance' : parseFloat(elementRaw[12]),
                            'escrowAdvanceBalance' : parseFloat(elementRaw[13])
                        }
                        //loanData.push(param);
                    }
                }
            });
            // console.log("TCL: Dashboard -> loanData", loanData);     
            // this.growl.show({severity: 'success', summary: 'Success', detail: 'File Uploaded Sucessfully'});
            AppServices.postLoanData(param).then(res => {       
                if(res) {
                    this.growl.show({severity: 'success', summary: 'Success', detail: 'File Uploaded Sucessfully'});
                } else {
                    this.growl.show({severity: 'error', summary: 'Error', detail: 'File Upload Failed'});
                }              
            });
        }
        console.log("TCL: Dashboard -> reader.readyState", reader.readyState)          
        reader.readAsText(files[0]);
    }
    
    render(){       
      return(
          <div className="container-fluid">
            <Growl ref={(el) => this.growl = el} />
            <div className="row"><Header/></div>            
            <div className="row m-t-10 m-l-10">
                <div className="col-md-12">
                    <h4>Upload File</h4>
                    <div className="m-b-10">Accepted File format: csv</div>
                </div>
                <div className="col-md-12 uploadfrm">
                    <p>
                        <ReactFileReader handleFiles={this.handleFiles} fileTypes={'.csv'}>
                            <button className='btn btn-primary btn-file'>Upload</button>
                        </ReactFileReader>
                    </p>
                </div>
            </div>
          </div>
      );
   }
}
export default Dashboard;