import React, { Component } from 'react';
import logo from "./../../assets/images/logo.png";

class Header extends Component{
   constructor(props) {
      super(props);
   }

   render(){
      return(
         <div className="col-md-12">
            <div className="row header">
                <div className="logo-wrapper m-l-40">
                    <img src={logo} alt="" /> 
                </div>                               
            </div>
        </div>
      );
   }
}
export default Header;