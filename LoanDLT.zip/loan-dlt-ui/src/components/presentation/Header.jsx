import React from 'react';
import logo from "./../../assets/images/logo.png";

function Header() {
    return (
        <div className="col-md-12">
            <div className="row header">
                <div className="logo-wrapper m-l-40">
                    <img src={logo} alt="" /> 
                </div>                               
            </div>
            <div className="row">
                <div className="m-l-40">
                    <ul className="nav">
                        <li className="nav-item">
                        Accounts
                        </li>                        
                        <li className="nav-item">
                        Admin
                        </li>
                        <li className="nav-item" >
                        My Profile  
                        </li>
                        <li className="nav-item" >
                        Reports  
                        </li>
                        <li className="nav-item selected" >
                        Project Dashboard
                        </li>                        
                    </ul>
                </div>
            </div> 
        </div>
    )
}
export default Header;