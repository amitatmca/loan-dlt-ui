import config from 'react-global-configuration';

function fetchStatusHandler(response) {
    if (response.status === 201) {
        return response;
    } else {
        throw new Error(response.statusText);
    }
}

const AppServices = {    
    postLoanData: (data) => {
        return fetch(config.get('apiUrl') + '/investor/loans', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        }).then(
            fetchStatusHandler
        ).then(res => res.json());        
    }
}
export default AppServices;