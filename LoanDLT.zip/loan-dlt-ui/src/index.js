import React from 'react';
import ReactDOM from 'react-dom';
import './../node_modules/bootstrap/dist/css/bootstrap.css';
import './../node_modules/bootstrap/dist/css/bootstrap-grid.css';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import './index.scss';
import Dashboard from './components/container/Dashboard';
import * as serviceWorker from './serviceWorker';
import config from 'react-global-configuration';

/* Application Config */
config.set(
    { 
        pageTitle: 'Dashboard', 
        apiUrl: 'http://172.20.236.179:9090/loan-dlt' 
    });
/* Application Config */

ReactDOM.render(<Dashboard />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
serviceWorker.unregister();