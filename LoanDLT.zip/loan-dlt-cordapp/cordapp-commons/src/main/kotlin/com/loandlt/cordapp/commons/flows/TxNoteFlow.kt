package com.loandlt.cordapp.commons.flows

import co.paralleluniverse.fibers.Suspendable
import com.google.common.base.Splitter
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.FlowSession
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.identity.Party
import net.corda.core.utilities.unwrap
import java.util.*

/**
 * [TxNoteFlow] flow logic to add the notes to a committed transaction.
 * */
@InitiatingFlow
open class TxNoteFlow(val txId: SecureHash, val txNotes: List<String>,
                      val otherParties: Collection<Party> = listOf()) : FlowLogic<Unit>() {
    constructor(txId: SecureHash, txNote: String, otherParties: Collection<Party> = listOf()) :
            this(txId, listOf(txNote), otherParties)

    constructor(txId: SecureHash, txNote: String, counterParty: Party) :
            this(txId, listOf(txNote), listOf(counterParty))

    constructor(txId: SecureHash, txNotes: List<String>, counterParty: Party) :
            this(txId, txNotes, listOf(counterParty))

    @Suspendable
    override fun call() {
        val txNotes255: MutableList<String> = ArrayList(txNotes.size)
        //Handle the string value with length more that 255.
        //Because Corda VAULT_TRANSACTION_NOTES table has NOTE column with size 255.
        txNotes.forEach {
            if (it.length > 255) {
                Splitter.fixedLength(255).split(it).iterator().forEach {
                    txNotes255.add(it)
                }
            } else {
                txNotes255.add(it)
            }
        }

        //Add note to transaction for calling node.
        txNotes255.forEach {
            serviceHub.vaultService.addNoteToTransaction(txId, it)
        }
        //Remove flow initiator identity from otherParties list.
        val counterParties = otherParties.filter { it.name != ourIdentity.name }
        //Create flow sessions for counter-parties.
        val flowSessions = counterParties.map { initiateFlow(it) }
        flowSessions.forEach { session -> session.send(Pair(txId, txNotes255)) }
    }
}

/**
 * [TxNoteAcceptorFlow] is add the responder flow for [TxNoteFlow].
 * It add the note for a transaction stored in counter party vault.
 * */
@InitiatedBy(TxNoteFlow::class)
open class TxNoteAcceptorFlow(val otherPartyFlow: FlowSession) : FlowLogic<Unit>() {
    @Suspendable
    override fun call() {
        otherPartyFlow.receive<Pair<SecureHash, List<String>>>().unwrap {
            val txId = it.first
            it.second.forEach {
                serviceHub.vaultService.addNoteToTransaction(txId, it)
            }
        }
    }
}

