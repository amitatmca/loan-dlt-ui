package com.loandlt.cordapp.state

import com.fasterxml.jackson.annotation.JsonValue
import com.loandlt.cordapp.contract.LoanSnapshotContract
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import net.corda.core.contracts.BelongsToContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Instant

/***
 * LoanSnapshot state object to be stored on vault.
 */

@BelongsToContract(LoanSnapshotContract::class)
data class LoanSnapshot(
        val loanId: UniqueIdentifier,
        val unpaidPrincipalBalance: BigDecimal,
        val dueDate: Instant,
        val noteRate: BigDecimal,
        val pmtCalcPrincipal: BigDecimal,
        val pmtCalcTerm: BigInteger,
        val indexCode: String,
        val firstRateChangeDate: Instant,
        val rateChangeFrequency: BigInteger,
        val rateMargin: BigDecimal,
        val corporateAdvanceBalance: BigDecimal,
        val escrowAdvanceBalance: BigDecimal,
        val owningInvestor: AbstractParty,
        val servicer: AbstractParty,
        val servicingIntervalId: UniqueIdentifier? = null,
        val actionType: ActionType? = null,
        val actionDate: Instant? = null,
        val actionAmount: BigDecimal? = null,
        val nextSnapshot: UniqueIdentifier? = null,
        override val linearId: UniqueIdentifier = UniqueIdentifier(),
        override val participants: List<AbstractParty> = listOf(owningInvestor, servicer)) : LinearState, QueryableState {

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is LoanSnapshotSchemaV1 -> LoanSnapshotSchemaV1.PersistentLoanSnapshot(
                    loanId = this.loanId.toString(),
                    unpaidPrincipalBalance = this.unpaidPrincipalBalance,
                    dueDate = this.dueDate,
                    noteRate = this.noteRate,
                    pmtCalcPrincipal = this.pmtCalcPrincipal,
                    pmtCalcTerm = this.pmtCalcTerm,
                    indexCode = this.indexCode,
                    firstRateChangeDate = this.firstRateChangeDate,
                    rateChangeFrequency = this.rateChangeFrequency,
                    rateMargin = this.rateMargin,
                    corporateAdvanceBalance = this.corporateAdvanceBalance,
                    escrowAdvanceBalance = this.escrowAdvanceBalance,
                    owningInvestor = this.owningInvestor,
                    servicer = this.servicer,
                    nextSnapshot = this.nextSnapshot.toString(),
                    linearId = this.linearId.toString(),
                    participants = this.participants.toMutableSet()
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(LoanSnapshotSchemaV1)
}

@CordaSerializable
enum class ActionType(@JsonValue val value: String) {
    PNI("PNI"),
    CURTAILMENT("Curtailment");

    companion object {
        @JvmStatic
        fun fromValue(value: String): ActionType {
            return ActionType.values()
                    .filter { it -> it.value.equals(value) }
                    .firstOrNull() ?: throw IllegalArgumentException(value)
        }
    }
}