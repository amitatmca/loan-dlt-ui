package com.loandlt.cordapp.contract

import net.corda.core.contracts.ContractState
import java.security.PublicKey

class ContractUtil {
    companion object {
        @JvmStatic
        fun keysFromParticipants(loanState: ContractState): Set<PublicKey> {
            return loanState.participants.map {
                it.owningKey
            }.toSet()
        }
    }
}