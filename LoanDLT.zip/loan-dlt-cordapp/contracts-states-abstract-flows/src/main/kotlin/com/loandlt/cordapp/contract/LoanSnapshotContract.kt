package com.loandlt.cordapp.contract

import com.loandlt.cordapp.state.LoanSnapshot
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction
import java.math.BigDecimal
import java.security.PublicKey

class LoanSnapshotContract : Contract {

    companion object {
        @JvmStatic
        val ID = LoanSnapshotContract::class.java.name!!
    }

    interface Commands : CommandData {
        class CreateLoanSnapshot : TypeOnlyCommandData(), Commands
        class ConfirmLoanSnapshot : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) {
        require(tx.timeWindow?.midpoint != null) { "Transaction must be timestamped." }
        val command = tx.commands.requireSingleCommand<Commands>()
        val signers = command.signers.toSet()

        when (command.value) {
            is Commands.CreateLoanSnapshot -> verifyCreateLoanSnapshot(tx, signers)
            else -> throw IllegalArgumentException("Unrecognised command.")
        }
    }

    private fun verifyCreateLoanSnapshot(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        "No inputs should be consumed when creating loan snapshot." using (tx.inputStates.isEmpty())
        "Only one loan snapshot output state should be created." using (tx.outRefsOfType<LoanSnapshot>().size == 1)

        val loanSnapshot = tx.outputsOfType<LoanSnapshot>().single()
        "A newly issued obligation must have a positive amount." using (loanSnapshot.noteRate > BigDecimal(0))
        "The OwningInvestor and Servicer cannot be the same identity." using (loanSnapshot.servicer != loanSnapshot.owningInvestor)
        "Both owning investor and servicer may sign the transaction." using (signers.contains(loanSnapshot.owningInvestor.owningKey))
        //TODO Add any other crucial business rules.
    }
}