package com.loandlt.cordapp.contract

import com.loandlt.cordapp.state.LoanState
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction
import java.security.PublicKey

class LoanStateContract : Contract {

    companion object {
        @JvmStatic
        val ID = LoanStateContract::class.java.name!!
    }

    interface Commands : CommandData {
        class Appoint : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) {
        require(tx.timeWindow?.midpoint != null) { "Transaction must be timestamped." }
        val command = tx.commands.requireSingleCommand<Commands>()
        val signers = command.signers.toSet()

        when (command.value) {
            is Commands.Appoint -> verifyAppointServicer(tx, signers)
            else -> throw IllegalArgumentException("Unrecognised command.")
        }
    }

    private fun verifyAppointServicer(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        "No inputs should be consumed when appointing the servicer." using (tx.inputStates.isEmpty())
        "The loan on-boarding transaction must have only two output state." using (tx.outputStates.size == 2)
        "Only one loan state should be created when appointing the servicer." using (tx.outRefsOfType<LoanState>().size == 1)

        val loanState = tx.outputsOfType<LoanState>().single()
        "The OwningInvestor and Servicer cannot be the same identity." using (loanState.servicer != loanState.owningInvestor)
        "The MSR Owner and Servicer cannot be the same identity." using (loanState.servicer != loanState.msrOwner)
        "Both owning investor and servicer may sign the transaction." using (signers.contains(loanState.owningInvestor.owningKey))
        //TODO Add any other crucial business rules.
    }
}