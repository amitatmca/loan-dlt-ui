package com.loandlt.cordapp.schema

import net.corda.core.crypto.NullKeys
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Instant
import javax.persistence.*

/**
 * The family of schemas for [LoanSnapshotSchema].
 */
object LoanSnapshotSchema

/**
 * First version of an [LoanSnapshotSchema] schema.
 */
object LoanSnapshotSchemaV1 : MappedSchema(schemaFamily = LoanSnapshotSchema.javaClass,
        version = 1, mappedTypes = listOf(PersistentLoanSnapshot::class.java)) {
    @Entity
    @Table(name = "loan_snapshot", indexes = arrayOf(
            Index(name = "loan_snapshot_loanId_idx", columnList = "loan_id"),
            Index(name = "loan_snapshot_linearId_idx", columnList = "linear_id")
    ))
    class PersistentLoanSnapshot(
            @Column(name = "loan_id")
            val loanId: String,

            @Column(name = "unpaid_principal_balance")
            val unpaidPrincipalBalance: BigDecimal,

            @Column(name = "due_date")
            val dueDate: Instant,

            @Column(name = "note_rate")
            val noteRate: BigDecimal,

            @Column(name = "pmt_calc_principal")
            val pmtCalcPrincipal: BigDecimal,

            @Column(name = "pmt_cal_term")
            val pmtCalcTerm: BigInteger,

            @Column(name = "index_code")
            val indexCode: String,

            @Column(name = "first_rate_change_date")
            val firstRateChangeDate: Instant,

            @Column(name = "rate_change_frequency")
            val rateChangeFrequency: BigInteger,

            @Column(name = "rate_margin")
            val rateMargin: BigDecimal,

            @Column(name = "corporate_advance_balance")
            val corporateAdvanceBalance: BigDecimal,

            @Column(name = "escrow_advance_balance")
            val escrowAdvanceBalance: BigDecimal,

            @Column(name = "owning_investor")
            val owningInvestor: AbstractParty,

            @Column(name = "servicer")
            val servicer: AbstractParty,

            @Column(name = "next_snapshot")
            val nextSnapshot: String,

            @Column(name = "linear_id")
            val linearId: String,

            @ElementCollection
            @Column(name = "participants")
            @CollectionTable(name = "loan_snapshot_participants", joinColumns = arrayOf(
                    JoinColumn(name = "output_index", referencedColumnName = "output_index"),
                    JoinColumn(name = "transaction_id", referencedColumnName = "transaction_id")))
            var participants: MutableSet<AbstractParty>? = null

    ) : PersistentState() {
        //Default Ctor for hibernate.
        constructor() : this("", BigDecimal(0), Instant.now(), BigDecimal(0), BigDecimal(0), BigInteger.ZERO, "",
                Instant.now(), BigInteger.ZERO, BigDecimal(0), BigDecimal(0), BigDecimal(0), NullKeys.NULL_PARTY,
                NullKeys.NULL_PARTY, "", "", null)
    }
}