package com.loandlt.cordapp.schema

import net.corda.core.crypto.NullKeys
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import javax.persistence.*

/**
 * The family of schemas for [LoanStateSchema].
 */
object LoanStateSchema

/**
 * First version of an [LoanStateSchema] schema.
 */
object LoanStateSchemaV1 : MappedSchema(schemaFamily = LoanStateSchema.javaClass,
        version = 1, mappedTypes = listOf(PersistentLoanState::class.java)) {
    @Entity
    @Table(name = "loan_state", indexes = arrayOf(
            Index(name = "loan_state_linearId_idx", columnList = "linear_id"),
            Index(name = "loan_state_loand_idx", columnList = "loan_id")
    ))
    class PersistentLoanState(
            @Column(name = "loan_id")
            val loanId: String,

            @Column(name = "owning_investor")
            val owningInvestor: AbstractParty,

            @Column(name = "msrOwner")
            val msrOwner: AbstractParty,

            @Column(name = "servicer")
            val servicer: AbstractParty,

            @Column(name = "linear_id")
            val linearId: String,

            @ElementCollection
            @Column(name = "participants")
            @CollectionTable(name = "loan_state_participants", joinColumns = arrayOf(
                    JoinColumn(name = "output_index", referencedColumnName = "output_index"),
                    JoinColumn(name = "transaction_id", referencedColumnName = "transaction_id")))
            var participants: MutableSet<AbstractParty>? = null

    ) : PersistentState() {
        //Default Ctor for hibernate.
        constructor() : this("", NullKeys.NULL_PARTY, NullKeys.NULL_PARTY, NullKeys.NULL_PARTY, "", null)
    }
}