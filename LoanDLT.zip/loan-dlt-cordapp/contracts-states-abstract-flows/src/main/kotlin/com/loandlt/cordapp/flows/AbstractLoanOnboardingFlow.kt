package com.loandlt.cordapp.flows

import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow

@InitiatingFlow
abstract class AbstractLoanOnboardingFlow<out T> : FlowLogic<T>(), FlowHelper