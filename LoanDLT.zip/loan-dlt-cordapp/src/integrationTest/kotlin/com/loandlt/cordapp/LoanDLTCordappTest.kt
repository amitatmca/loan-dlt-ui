package com.loandlt.cordapp

import net.corda.client.rpc.CordaRPCClient
import net.corda.core.identity.CordaX500Name
import net.corda.core.utilities.getOrThrow
import net.corda.testing.driver.DriverParameters
import net.corda.testing.driver.driver
import net.corda.testing.node.NotarySpec
import net.corda.testing.node.User
import org.junit.Test

class LoanDLTCordappTest {
    @Test
    fun `loan dlt cordapp integration test`() {
        driver(DriverParameters(isDebug = true,
                startNodesInProcess = true,
                extraCordappPackagesToScan = listOf("net.corda.finance"),
                notarySpecs = listOf(NotarySpec(CordaX500Name("Notary", "London", "GB"))))
        ) {
            val testUser = User("usr1", "pass", setOf("ALL"))
            // This starts nodes simultaneously with startNode, which returns a future that completes when the node
            // has completed startup. Then these are all resolved with getOrThrow which returns the NodeHandle list.
            val (investorAHandle, servicerAHandle) = listOf(
                    startNode(providedName = CordaX500Name("InvestorA", "London", "GB"), rpcUsers = listOf(testUser)),
                    startNode(providedName = CordaX500Name("ServicerA", "New York", "US"), rpcUsers = listOf(testUser))
            ).map { it.getOrThrow() }

            val investorAClient = CordaRPCClient(investorAHandle.rpcAddress)
            val investorAProxy = investorAClient.start(testUser.username, testUser.password).proxy

            val servicerClient = CordaRPCClient(servicerAHandle.rpcAddress)
            val servicerProxy = servicerClient.start(testUser.username, testUser.password).proxy

            val servicerParty = servicerProxy.nodeInfo().legalIdentities.first()
            val investorParty = investorAProxy.nodeInfo().legalIdentities.first()
            val notaryParty = defaultNotaryHandle.identity
        }
    }
}