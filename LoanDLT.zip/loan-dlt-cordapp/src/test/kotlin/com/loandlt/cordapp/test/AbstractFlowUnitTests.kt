package com.loandlt.cordapp.test

import com.loandlt.cordapp.commons.flows.TxNoteAcceptorFlow
import com.loandlt.cordapp.investor.flows.LoanOnboardingFlow
import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.servicer.flows.LoanOnboardingResponder
import net.corda.core.identity.CordaX500Name
import net.corda.core.identity.Party
import net.corda.core.utilities.getOrThrow
import net.corda.testing.internal.chooseIdentity
import net.corda.testing.node.MockNetwork
import net.corda.testing.node.MockNetworkNotarySpec
import net.corda.testing.node.StartedMockNode
import org.junit.After
import org.junit.Before

/**
 * A base class to reduce the boilerplate when writing obligation flow tests.
 */
abstract class AbstractFlowUnitTests {
    lateinit var network: MockNetwork
    lateinit var investorNode1: StartedMockNode
    lateinit var servicerNode1: StartedMockNode
    lateinit var notary: Party
    lateinit var investor1: Party
    lateinit var servicer1: Party

    @Before
    fun setup() {
        network = MockNetwork(listOf("com.loandlt.cordapp", "net.corda.finance"),
                threadPerNode = true,
                notarySpecs = listOf(MockNetworkNotarySpec(CordaX500Name.parse("O=Notary,L=London,C=GB"))))
        investorNode1 = network.createNode()
        servicerNode1 = network.createNode()

        notary = network.defaultNotaryIdentity
        investor1 = investorNode1.info.chooseIdentity()
        servicer1 = servicerNode1.info.chooseIdentity()

        servicerNode1.registerInitiatedFlow(LoanOnboardingResponder::class.java)
        servicerNode1.registerInitiatedFlow(TxNoteAcceptorFlow::class.java)
        investorNode1.registerInitiatedFlow(TxNoteAcceptorFlow::class.java)
    }

    @After
    open fun tearDown() {
        network.stopNodes()
    }

    fun loanOnboarding(loan: Loan, investorNode: StartedMockNode) {
        investorNode.startFlow(LoanOnboardingFlow(loan)).getOrThrow()
    }
}
