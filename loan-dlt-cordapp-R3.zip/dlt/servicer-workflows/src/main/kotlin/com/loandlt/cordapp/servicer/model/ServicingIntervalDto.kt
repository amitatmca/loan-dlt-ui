package com.loandlt.cordapp.servicer.model

import net.corda.core.serialization.CordaSerializable
import java.time.Instant

@CordaSerializable
data class ServicingIntervalDto(
        /** The identifiable/human readable ID for new ServicingInterval.*/
        val servicingIntervalId: String,
        val startDate: Instant
)