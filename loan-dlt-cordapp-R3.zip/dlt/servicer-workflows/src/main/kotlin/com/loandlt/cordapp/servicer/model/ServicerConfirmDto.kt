package com.loandlt.cordapp.servicer.model

import com.loandlt.cordapp.state.LoanState
import net.corda.core.serialization.CordaSerializable
import java.time.Instant

@CordaSerializable
data class ServicerConfirmDto(
        /** The identifiable/human readable ID for new ServicingInterval.*/
        val servicingIntervalId: String,
        /** The [LoanState.linearId] value of on-leger contract state.*/
        val loanLinearId: String,
        val startDate: Instant
)