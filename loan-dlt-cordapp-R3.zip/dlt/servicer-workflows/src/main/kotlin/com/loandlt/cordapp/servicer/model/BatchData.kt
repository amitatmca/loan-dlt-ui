package com.loandlt.cordapp.servicer.model

import net.corda.core.serialization.CordaSerializable
import java.time.Instant

@CordaSerializable
data class BatchData(val owningInvestor: String,
                     val servicingBatchId: String,
                     val startDate: Instant,
                     val cutOffDate: Instant)
