package com.loandlt.cordapp.servicer.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.contract.ServicingIntervalContract
import com.loandlt.cordapp.exception.InvalidLoanStateLinearIdException
import com.loandlt.cordapp.exception.TooManyStatesFoundException
import com.loandlt.cordapp.flows.AbstractAddActionFlow
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import com.loandlt.cordapp.servicer.exception.MissingServicingIntervalInfoException
import com.loandlt.cordapp.servicer.model.ActionData
import com.loandlt.cordapp.servicer.model.ServicingIntervalDto
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds

/**
 * Flow logic to record the new action by creating the new loan snapshot state.
 */
@StartableByRPC
class AddActionFlow private constructor(private val actionData: ActionData,
                                        private val servicingIntervalLinearId: String?,
                                        private val servicingIntervalDto: ServicingIntervalDto?) : AbstractAddActionFlow<Unit>() {
    /**
     * @param actionData The data to record new loan servicing action.
     */
    constructor(actionData: ActionData) : this(actionData, null, null)

    /**
     * @param actionData The data to record new loan servicing action.
     * @param servicingIntervalLinearId The [ServicingInterval.linearId] value of existing/unconsumed contract state.
     * This Id required to provide while starting the new servicing interval after close of the previous.
     */
    constructor(actionData: ActionData, servicingIntervalLinearId: String) : this(actionData, servicingIntervalLinearId, null)

    /***
     * @param actionData The data to record new loan servicing action.
     * @param servicingIntervalDto - The data to create new servicing interval contract state.
     * It required to provide while starting the new servicing interval after close of the previous.
     */
    constructor(actionData: ActionData, servicingIntervalDto: ServicingIntervalDto) : this(actionData, null, servicingIntervalDto)

    companion object {
        object QUERY_SNAPSHOT : Step("Query the vault to retrieve the LoanSnapshot state by loanId.")
        object ADD_ACTION : Step("Add new action to loan snapshot.")
        object GENERATE_TX : Step("Generate the transaction.")
        object ADD_SERVICING_INTERVAL : Step("Add servicing interval contract state if required.")
        object QUERT_SERVICING_INTERVAL : Step("Query the vault to retrieve the ServicingInterval state by linearId. Add it as reference state to the transaction")
        object BUILD_SERVICING_INTERVAL : Step("Build the ServicingInterval state with given user data and add it to the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_SNAPSHOT, ADD_ACTION, GENERATE_TX, ADD_SERVICING_INTERVAL,
                QUERT_SERVICING_INTERVAL, BUILD_SERVICING_INTERVAL, SIGN_TX, FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start AddActionFlow.")
        progressTracker.currentStep = QUERY_SNAPSHOT
        val expLoanId = LoanSnapshotSchemaV1.PersistentLoanSnapshot::loanId.equal(actionData.loanLinearId)
        val loanSnapshotStates = serviceHub.vaultService.queryBy(
                LoanSnapshot::class.java,
                QueryCriteria.VaultCustomQueryCriteria(expLoanId)).states
        if (loanSnapshotStates.size > 1) throw TooManyStatesFoundException("LoanSnapshot states with LoanId: ${actionData.loanLinearId}")
        val prevLoanSnapshotStateRef = loanSnapshotStates.singleOrNull()
                ?: throw InvalidLoanStateLinearIdException(actionData.loanLinearId)

        progressTracker.currentStep = ADD_ACTION
        val outLoanSnapshot = actionData.run {
            prevLoanSnapshotStateRef.state.data.addAction(
                    actionType,
                    actionAmount,
                    actionDate,
                    unpaidPrincipalBalance,
                    dueDate)
        }

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(prevLoanSnapshotStateRef.state.notary)
                .addInputState(prevLoanSnapshotStateRef)
                .addCommand(ServicingContract.Commands.AddAction(), outLoanSnapshot.servicer.owningKey)
                .setTimeWindow(serviceHub.clock.instant(), 60.seconds)

        progressTracker.currentStep = ADD_SERVICING_INTERVAL
        if (prevLoanSnapshotStateRef.state.data.actionType == ActionType.CLOSE_SERVICING_INTERVAL) {
            val servicingInterval = addServicingIntervalStateIfRequired(utx, prevLoanSnapshotStateRef.state.data)

            val outLoanSnapshotStartServicingInterval = outLoanSnapshot.copy(
                    servicingIntervalId = servicingInterval.linearId,
                    servicingIntervalPayout = outLoanSnapshot.actionAmount)

            utx.addOutputState(outLoanSnapshotStartServicingInterval, ServicingContract.ID)
        } else {
            utx.addOutputState(outLoanSnapshot, ServicingContract.ID)
        }

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val owningInvestor = serviceHub.resolveIdentity(outLoanSnapshot.owningInvestor)
        val owningInvestorSession = initiateFlow(owningInvestor)
        val ftx = subFlow(FinalityFlow(stx, listOf(owningInvestorSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Confirmed loan-snapshot and issued new servicing interval by servicer: `$ourIdentity` " +
                        "and shared with owning investor: `$owningInvestor`.",
                owningInvestor))
        logger.info("End AddActionFlow.")
    }

    @Suspendable
    private fun addServicingIntervalStateIfRequired(utx: TransactionBuilder, input: LoanSnapshot): ServicingInterval {
        return when {
            servicingIntervalLinearId != null -> {
                progressTracker.currentStep = QUERT_SERVICING_INTERVAL
                val linearId = servicingIntervalLinearId.toUniqueIdentifier()
                val servicingInterval = serviceHub.getSingleStateByLinearId(linearId, ServicingInterval::class.java)
                        .referenced()
                utx.addReferenceState(servicingInterval)

                servicingInterval.stateAndRef.state.data
            }
            servicingIntervalDto != null -> {
                progressTracker.currentStep = BUILD_SERVICING_INTERVAL
                val servicingInterval = ServicingInterval(servicingIntervalDto.servicingIntervalId,
                        servicingIntervalDto.startDate,
                        input.owningInvestor,
                        input.servicer)

                utx.addOutputState(servicingInterval, ServicingIntervalContract.ID)
                        .addCommand(ServicingIntervalContract.Commands.CreateServicingInterval(), ourIdentity.owningKey)

                servicingInterval
            }
            else -> throw MissingServicingIntervalInfoException("Missing servicing interval ID or Data Info.")
        }
    }
}