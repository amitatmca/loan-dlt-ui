package com.loandlt.cordapp.servicer.model

import com.loandlt.cordapp.state.ActionType
import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.time.Instant

@CordaSerializable
data class ActionData(
        val loanLinearId: String,
        val actionType: ActionType,
        val actionAmount: BigDecimal,
        val actionDate: Instant,
        val unpaidPrincipalBalance: BigDecimal,
        val dueDate: Instant
)