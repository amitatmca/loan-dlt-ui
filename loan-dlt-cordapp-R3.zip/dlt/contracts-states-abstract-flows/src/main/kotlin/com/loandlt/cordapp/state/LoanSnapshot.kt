package com.loandlt.cordapp.state

import com.fasterxml.jackson.annotation.JsonValue
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.exception.InvalidLoanServicingActionTypeException
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import net.corda.core.contracts.BelongsToContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.contracts.hash
import net.corda.core.crypto.SecureHash
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Instant

/***
 * LoanSnapshot state object to be stored on vault.
 */

@BelongsToContract(ServicingContract::class)
data class LoanSnapshot(
        /** The [LoanState.linearId] field value*/
        val loanId: UniqueIdentifier,
        val unpaidPrincipalBalance: BigDecimal,
        val dueDate: Instant,
        val noteRate: BigDecimal,
        val pmtCalcPrincipal: BigDecimal,
        val pmtCalcTerm: BigInteger,
        val indexCode: String,
        val firstRateChangeDate: Instant,
        val rateChangeFrequency: BigInteger,
        val rateMargin: BigDecimal,
        val corporateAdvanceBalance: BigDecimal,
        val escrowAdvanceBalance: BigDecimal,
        val owningInvestor: AbstractParty,
        val servicer: AbstractParty,
        val actionType: ActionType,
        val actionDate: Instant,
        val actionAmount: BigDecimal = BigDecimal.ZERO,
        /** The [ServicingInterval.linearId] field value*/
        val servicingIntervalId: UniqueIdentifier? = null,
        val servicingIntervalPayout: BigDecimal = BigDecimal.ZERO,
        /** The [LoanSnapshot.linearId] field value of existing on-ledger contract state.*/
        val prevSnapshotId: UniqueIdentifier? = null,
        val prevSnapshotHash: SecureHash? = null,
        override val linearId: UniqueIdentifier = UniqueIdentifier(Instant.now().toEpochMilli().toString()),
        override val participants: List<AbstractParty> = listOf(owningInvestor, servicer)) : LinearState, QueryableState {

    fun confirmServicing(actionDate: Instant, servicingIntervalId: UniqueIdentifier): LoanSnapshot {
        return copy(prevSnapshotId = this.linearId, prevSnapshotHash = this.hash(),
                actionType = ActionType.SERVICER_CONFIRM, actionDate = actionDate,
                servicingIntervalId = servicingIntervalId, linearId = UniqueIdentifier(Instant.now().toEpochMilli().toString()))
    }

    fun addAction(actionType: ActionType, actionAmount: BigDecimal, actionDate: Instant, unpaidPrincipalBalance: BigDecimal,
                  dueDate: Instant): LoanSnapshot {
        return when (actionType) {
            ActionType.PNI, ActionType.CURTAILMENT -> addAction(
                    actionType,
                    actionAmount,
                    actionDate,
                    unpaidPrincipalBalance,
                    dueDate,
                    this.escrowAdvanceBalance,
                    this.corporateAdvanceBalance
            )
            ActionType.ESCROW_ADV -> addAction(
                    actionType,
                    actionAmount,
                    actionDate,
                    unpaidPrincipalBalance,
                    dueDate,
                    (this.escrowAdvanceBalance + actionAmount),
                    this.corporateAdvanceBalance
            )
            ActionType.CORP_ADV -> addAction(
                    actionType,
                    actionAmount,
                    actionDate,
                    unpaidPrincipalBalance,
                    dueDate,
                    this.escrowAdvanceBalance,
                    (this.corporateAdvanceBalance + actionAmount)
            )
            else -> throw InvalidLoanServicingActionTypeException(actionType.name)
        }
    }

    private fun addAction(actionType: ActionType, actionAmount: BigDecimal, actionDate: Instant, unpaidPrincipalBalance: BigDecimal,
                          dueDate: Instant, escrowAdvanceBalance: BigDecimal, corporateAdvanceBalance: BigDecimal): LoanSnapshot {
        return copy(actionType = actionType, actionDate = actionDate, actionAmount = actionAmount,
                unpaidPrincipalBalance = unpaidPrincipalBalance, dueDate = dueDate,
                escrowAdvanceBalance = escrowAdvanceBalance,
                corporateAdvanceBalance = corporateAdvanceBalance,
                servicingIntervalPayout = this.servicingIntervalPayout + actionAmount,
                prevSnapshotId = this.linearId, prevSnapshotHash = this.hash(),
                linearId = UniqueIdentifier(Instant.now().toEpochMilli().toString()))
    }

    fun rollbackSnapshot(): LoanSnapshot {
        return this.copy(linearId = UniqueIdentifier(Instant.now().toEpochMilli().toString()),
                actionType = ActionType.REMOVE_PREV_ACTION,
                actionDate = Instant.now(),
                actionAmount = BigDecimal.ZERO)
    }

    fun closeServicingInterval(): LoanSnapshot {
        return this.copy(linearId = UniqueIdentifier(Instant.now().toEpochMilli().toString()),
                actionType = ActionType.CLOSE_SERVICING_INTERVAL,
                actionDate = Instant.now(),
                actionAmount = BigDecimal.ZERO,
                prevSnapshotId = this.linearId,
                prevSnapshotHash = this.hash())
    }

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is LoanSnapshotSchemaV1 -> LoanSnapshotSchemaV1.PersistentLoanSnapshot(
                    loanId = this.loanId.toString(),
                    unpaidPrincipalBalance = this.unpaidPrincipalBalance,
                    dueDate = this.dueDate,
                    noteRate = this.noteRate,
                    pmtCalcPrincipal = this.pmtCalcPrincipal,
                    pmtCalcTerm = this.pmtCalcTerm,
                    indexCode = this.indexCode,
                    firstRateChangeDate = this.firstRateChangeDate,
                    rateChangeFrequency = this.rateChangeFrequency,
                    rateMargin = this.rateMargin,
                    corporateAdvanceBalance = this.corporateAdvanceBalance,
                    escrowAdvanceBalance = this.escrowAdvanceBalance,
                    owningInvestor = this.owningInvestor,
                    servicer = this.servicer,
                    actionType = this.actionType.name,
                    actionDate = this.actionDate,
                    actionAmount = this.actionAmount,
                    servicingIntervalId = this.servicingIntervalId.toString(),
                    servicingIntervalPayout = this.servicingIntervalPayout,
                    prevSnapshotId = this.prevSnapshotId.toString(),
                    prevSnapshotHash = this.prevSnapshotHash.toString(),
                    linearId = this.linearId.toString(),
                    participants = this.participants.toMutableSet()
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(LoanSnapshotSchemaV1)
}

@CordaSerializable
enum class ActionType(@JsonValue val value: String) {
    APPOINT("Appoint"),
    SERVICER_CONFIRM("Servicer Confirm"),
    PNI("PNI"),
    CURTAILMENT("Curtailment"),
    CORP_ADV("corporate Advance"),
    ESCROW_ADV("Escrow Advance"),
    REMOVE_PREV_ACTION("Remove Prev Action"),
    CLOSE_SERVICING_INTERVAL("Close Servicing Interval");

    companion object {
        @JvmStatic
        fun fromValue(value: String): ActionType {
            return ActionType.values()
                    .firstOrNull { it -> (it.value == value) }
                    ?: throw IllegalArgumentException(value)
        }

        @JvmStatic
        val addActions = listOf(PNI, CURTAILMENT, CORP_ADV, ESCROW_ADV)
    }
}