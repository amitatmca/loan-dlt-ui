package com.loandlt.cordapp.state

import com.loandlt.cordapp.contract.ServicingBatchContract
import com.loandlt.cordapp.schema.ServicingBatchSchemaV1
import net.corda.core.contracts.BelongsToContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.time.Instant

/***
 * ServicingInterval state holds loan servicing interval or cycle data.
 */
@BelongsToContract(ServicingBatchContract::class)
data class ServicingBatch(
        val owningInvestor: AbstractParty,
        val servicer: AbstractParty,
        val servicingBatchId: String,
        val startDate: Instant,
        val cutOffDate: Instant,
        val wireId: String = "",
        val wireXferDate: Instant? = null,
        val calculatedPayout: BigDecimal = BigDecimal.ZERO,
        val status: BatchStatus = BatchStatus.OPEN,
        override val participants: List<AbstractParty> = listOf(owningInvestor, servicer),
        override val linearId: UniqueIdentifier = UniqueIdentifier(servicingBatchId)) : LinearState, QueryableState {

    fun isOpen() = this.status == BatchStatus.OPEN
    fun isClosed() = this.status == BatchStatus.CLOSED
    fun isSettled() = this.status == BatchStatus.SETTLED

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is ServicingBatchSchemaV1 -> ServicingBatchSchemaV1.PersistentServicingBatch(
                    owningInvestor = this.owningInvestor,
                    servicer = this.servicer,
                    servicingBatchId = this.servicingBatchId,
                    startDate = this.startDate,
                    cutOffDate = this.cutOffDate,
                    wireId = this.wireId,
                    wireXferDate = this.wireXferDate,
                    calculatedPayout = calculatedPayout,
                    status = this.status.name,
                    participants = this.participants.toMutableSet(),
                    linearId = linearId.toString()
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(ServicingBatchSchemaV1)
}

@CordaSerializable
enum class BatchStatus {
    OPEN,
    CLOSED,
    SETTLED
}
