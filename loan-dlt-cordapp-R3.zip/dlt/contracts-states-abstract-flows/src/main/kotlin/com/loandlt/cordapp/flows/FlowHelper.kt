package com.loandlt.cordapp.flows

import com.loandlt.cordapp.exception.NotaryNotFoundException
import com.loandlt.cordapp.exception.StateNotFoundOnVaultException
import com.loandlt.cordapp.exception.TooManyStatesFoundException
import net.corda.core.contracts.ContractState
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.node.ServiceHub
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.schemas.PersistentState
import java.util.*
import kotlin.reflect.KProperty1

/**
 * It offers helper methods to get Notary from network, resolve [AbstractParty] to well-known identity,
 * query vault for [ContractState] by it's [UniqueIdentifier] linearId.
 */
interface FlowHelper {
    //Default functions definition.
    fun ServiceHub.firstNotary(): Party {
        return this.networkMapCache.notaryIdentities.firstOrNull()
                ?: throw NotaryNotFoundException("No available notary.")
    }

    fun <T : ContractState, P : PersistentState> ServiceHub.getStateByFieldValue(
            clazz: Class<T>,
            field: KProperty1<P, Any?>,
            criteriaValue: Any): List<StateAndRef<T>> {

        val loanIdExp = field.equal(criteriaValue)
        val criteria = net.corda.core.node.services.vault.QueryCriteria.VaultCustomQueryCriteria(loanIdExp)
        return this.vaultService.queryBy(clazz, criteria).states
    }

    fun <T : ContractState> ServiceHub.getStatesByLinearId(linearId: UniqueIdentifier,
                                                           clazz: Class<T>,
                                                           stateStatus: Vault.StateStatus = Vault.StateStatus.UNCONSUMED): List<StateAndRef<T>> {
        val queryCriteria = QueryCriteria.LinearStateQueryCriteria(null, listOf(linearId), stateStatus, null)
        return this.vaultService.queryBy(clazz, queryCriteria).states
    }

    fun <T : ContractState> ServiceHub.getSingleStateByLinearId(linearId: UniqueIdentifier,
                                                                clazz: Class<T>,
                                                                stateStatus: Vault.StateStatus = Vault.StateStatus.UNCONSUMED): StateAndRef<T> {
        val states = getStatesByLinearId(linearId, clazz, stateStatus)
        if (states.size > 1) throw TooManyStatesFoundException("for LinearId: $linearId.")
        return states.singleOrNull() ?: throw StateNotFoundOnVaultException("for linearId: $linearId")
    }

    fun ServiceHub.resolveIdentity(abstractParty: AbstractParty): Party {
        return this.identityService.requireWellKnownPartyFromAnonymous(abstractParty)
    }

    fun String?.toUniqueIdentifier(): UniqueIdentifier {
        val str = this
        if (str == null) {
            throw IllegalArgumentException("Invalid UniqueIdentifier string: $str!")
        }
        try {
            // Check if externalId and UUID may be separated by underscore.
            if (str.contains("_")) {
                val ids = str.split("_".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                // Create UUID object from string.
                val uuid = UUID.fromString(ids[1])
                // Create UniqueIdentifier object using externalId and UUID.
                return UniqueIdentifier(ids[0], uuid)
            }

            // Any other string used as id (i.e. UUID).
            return UniqueIdentifier(null, UUID.fromString(str))
        } catch (exception: IllegalArgumentException) {
            throw IllegalArgumentException("Invalid UniqueIdentifier string: $exception")
        }

    }
}