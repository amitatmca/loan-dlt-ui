package com.loandlt.cordapp.flows

import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow

@InitiatingFlow
abstract class AbstractLoanOnboardingFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractServicerConfirmationFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractAddActionFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractRemovePrevActionFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractCloseServicingIntervalFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractServicerConfirmationWithExistingServicingIntervalFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractCloseServicingBatchFlow<out T> : FlowLogic<T>(), FlowHelper

@InitiatingFlow
abstract class AbstractConfirmPaymentFlow<out T> : FlowLogic<T>(), FlowHelper