package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.contracts.hash
import net.corda.core.node.services.Vault
import org.junit.Test
import java.math.BigDecimal
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals

class ContractStateHashTests : AbstractFlowUnitTests() {

    @Test
    fun `verify hash of states to ensure valid changes`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot1 = servicerNode1.get(LoanSnapshot::class.java)

        val pniActionAmount = BigDecimal(1000)
        val pniLoanSnapshot = prevLoanSnapshot1.addAction(
                ActionType.PNI,
                pniActionAmount,
                Instant.now(),
                prevLoanSnapshot1.unpaidPrincipalBalance - pniActionAmount,
                Instant.now()
        )

        val prevLoanSnapshot1CopyFromPniSnapshot = prevLoanSnapshot1.run {
            pniLoanSnapshot.copy(actionType = actionType,
                    actionDate = actionDate,
                    actionAmount = actionAmount,
                    unpaidPrincipalBalance = unpaidPrincipalBalance,
                    dueDate = dueDate,
                    servicingIntervalPayout = servicingIntervalPayout,
                    prevSnapshotId = prevSnapshotId,
                    prevSnapshotHash = prevSnapshotHash,
                    linearId = linearId)
        }

        assert(prevLoanSnapshot1.hash() == prevLoanSnapshot1CopyFromPniSnapshot.hash())
    }

    @Test
    fun `rollback to previous state and verify with hash`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Rollback to previous state.
        val loanSnapshotLatest = servicerNode1.get(LoanSnapshot::class.java)
        val prevLoanSnapshot = servicerNode1.services.getStatesByLinearId(
                loanSnapshotLatest.prevSnapshotId!!,
                LoanSnapshot::class.java,
                Vault.StateStatus.CONSUMED
        ).first().state.data
        val newLoanSnapshot = prevLoanSnapshot.copy(linearId = UniqueIdentifier())

        // Compare the hashes.
        assertEquals(prevLoanSnapshot.hash(),
                newLoanSnapshot.copy(linearId = prevLoanSnapshot.linearId).hash())
    }
}
