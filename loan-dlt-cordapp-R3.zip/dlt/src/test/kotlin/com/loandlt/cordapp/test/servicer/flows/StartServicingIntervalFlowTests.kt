package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.schema.ServicingIntervalSchemaV1
import com.loandlt.cordapp.servicer.model.BatchData
import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.servicer.model.ServicingIntervalDto
import com.loandlt.cordapp.state.*
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.hash
import net.corda.testing.node.StartedMockNode
import org.junit.Test
import java.math.BigDecimal
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class StartServicingIntervalFlowTests : AbstractFlowUnitTests() {

    private fun verifyLedgerAfterPrevSnapshotRemoval(servicer: StartedMockNode, investor: StartedMockNode, prevSnapshot: LoanSnapshot) {
        listOf(servicer, investor).forEach { node ->
            val head = node.getSnapshotByLoanId(prevSnapshot.loanId).single()
            assertNotNull(head.prevSnapshotId)
            assertEquals(head.actionType, ActionType.REMOVE_PREV_ACTION)
            assertEquals(head.actionAmount, BigDecimal.ZERO)

            val tempPrevSnapshot = head.copy(
                    linearId = prevSnapshot.linearId,
                    actionType = prevSnapshot.actionType,
                    actionDate = prevSnapshot.actionDate,
                    actionAmount = prevSnapshot.actionAmount)
            assertEquals(tempPrevSnapshot.hash(), prevSnapshot.hash())
        }
    }

    @Test
    fun `start new servicing interval`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData = pni(snapshot1, BigDecimal(10000))
        addAction(actionData, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode1, investorNode1, snapshot2)

        // Close servicing interval.
        val loanSnapshotBeforeCloseInterval = servicerNode1.get(LoanSnapshot::class.java)
        val servIntervalId = servicerNode1.get(ServicingInterval::class.java).linearId.toString()
        val batchData = BatchData(investor1.toString(),
                "Batch001",
                servicingIntervalDto.startDate,
                Instant.now().plus(30L, ChronoUnit.DAYS))
        closeServicingInterval(servIntervalId, batchData, servicerNode1)
        network.waitQuiescent()

        listOf(investorNode1, servicerNode1).forEach {
            val loanSnapshot = it.get(LoanSnapshot::class.java)
            val interval = it.get(ServicingInterval::class.java)
            val batch = it.get(ServicingBatch::class.java)
            assert(loanSnapshot.prevSnapshotId == loanSnapshotBeforeCloseInterval.linearId)
            assert(loanSnapshot.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
            assert(loanSnapshot.actionAmount == BigDecimal.ZERO)
            assert(interval.calculatedPayout == loanSnapshotBeforeCloseInterval.servicingIntervalPayout)
            assert(interval.batchId == batch.linearId)
            assert(interval.cutOffDate == batch.cutOffDate)
            assert(interval.isClosed())
        }

        //Get last unconsumed loan snapshot.
        val snapshot4 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData4 = pni(snapshot4, BigDecimal(10000))
        val intervalData2 = ServicingIntervalDto("SRV002", Instant.now())
        addActionWithStartInterval(actionData4, intervalData2, servicerNode1)
        network.waitQuiescent()

        listOf(investorNode1, servicerNode1).forEach {
            val loanSnapshot = it.get(LoanSnapshot::class.java)
            val interval = it.getStateByFieldValue(
                    ServicingInterval::class.java,
                    ServicingIntervalSchemaV1.PersistentServicingInterval::servicingIntervalId,
                    intervalData2.servicingIntervalId).single()

            assert(loanSnapshot.actionType == ActionType.PNI)
            assert(loanSnapshot.servicingIntervalId == interval.linearId)
            assert(loanSnapshot.servicingIntervalPayout == loanSnapshot.actionAmount)

            assert(interval.calculatedPayout == BigDecimal.ZERO)
            assertNull(interval.batchId)
            assertNull(interval.cutOffDate)
            assert(interval.isOpen())

            assert(it.getStates(ServicingInterval::class.java).size == 2)
        }
    }

    @Test
    fun UseExistingServicingInterval() {

        val (loan1, interval1) = createLoanDoServicing(investorNode1, servicerNode1)
        val (loan2, interval2) = createLoanDoServicing(investorNode1, servicerNode1)

        val loanSnapshotsInvestor1 = investorNode1.getStates(LoanSnapshot::class.java)
        assertEquals(loanSnapshotsInvestor1.size, 2)
        assertEquals(investorNode1.getStates(LoanState::class.java).size, 2)
        assertEquals(investorNode1.getStates(ServicingInterval::class.java).size, 2)

        val loanSnapshotsServicerNode1 = servicerNode1.getStates(LoanSnapshot::class.java)
        assertEquals(loanSnapshotsServicerNode1.size, 2)
        assertEquals(servicerNode1.getStates(LoanState::class.java).size, 2)
        assertEquals(servicerNode1.getStates(ServicingInterval::class.java).size, 2)

        //region ################# Close servicing interval #1 #################
        // Close servicing cycle.
        val batchData1 = BatchData(
                investor1.toString(),
                "Batch${Instant.now().toEpochMilli()}",
                interval1.startDate,
                Instant.now().plus(5L, ChronoUnit.DAYS))
        closeServicingInterval(interval1.linearId.toString(), batchData1, servicerNode1)
        network.waitQuiescent()

        //endregion

        // Retrieve snapshot of loan #1
        val loan1_snapshot1 = servicerNode1.getSnapshotByLoanId(loan1.linearId).single()
        assert(loan1_snapshot1.actionType == ActionType.CLOSE_SERVICING_INTERVAL)

        //Add PNI payment, start new servicing interval by attaching the existing servicing interval to loan snapshot.
        val actionData1 = pni(loan1_snapshot1, BigDecimal(10000))
        addActionWithStartInterval(actionData1, interval2.linearId.toString(), servicerNode1)
        network.waitQuiescent()

        val loan1_snapshot2 = servicerNode1.getSnapshotByLoanId(loan1.linearId).single()
        assert(loan1_snapshot2.actionType == ActionType.PNI)
        assert(loan1_snapshot2.actionAmount == actionData1.actionAmount)
        assert(loan1_snapshot2.actionAmount == loan1_snapshot2.servicingIntervalPayout)
        // Loan #1 now servicing under the servicing interval #2.
        assert(loan1_snapshot2.servicingIntervalId == interval2.linearId)

        val loanSnapshots = servicerNode1.getSnapshotByIntervalId(interval2.linearId)
        assert(loanSnapshots.size == 2)
        assertNotNull(loanSnapshots.firstOrNull { it.loanId == loan1.linearId })
        assertNotNull(loanSnapshots.firstOrNull { it.loanId == loan2.linearId })

        val intervals = investorNode1.getStates(ServicingInterval::class.java)
        val s1 = intervals.firstOrNull { it.linearId == interval1.linearId }
        val s2 = intervals.firstOrNull { it.linearId == interval2.linearId }

        assertNotNull(s1)
        assertNotNull(s2)
        assert(s1!!.isClosed())
        assert(s2!!.isOpen())
    }

    fun createLoanDoServicing(investorNode: StartedMockNode, servicerNode: StartedMockNode)
            : Pair<LoanState, ServicingInterval> {

        //region ################# First loan servicing #################
        val loanState1 = loanOnboarding(investorNode, servicerNode)
        network.waitQuiescent()
        //Confirm servicing by servicer.
        val confirmServicing = ServicerConfirmDto(
                "SI${Instant.now().toEpochMilli()}",
                loanState1.linearId.toString(),
                Instant.now())
        confirmLoanSnapshot(confirmServicing, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode.getSnapshotByLoanId(loanState1.linearId).single()
        //Add PNI payment.
        val actionData1 = pni(snapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode.getSnapshotByLoanId(loanState1.linearId).single()
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode.getSnapshotByLoanId(loanState1.linearId).single()
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode, investorNode, snapshot2)
        //endregion

        val servicingInterval = servicerNode.getStateByFieldValue(
                ServicingInterval::class.java,
                ServicingIntervalSchemaV1.PersistentServicingInterval::servicingIntervalId,
                confirmServicing.servicingIntervalId).single()

        return Pair(loanState1, servicingInterval)
    }
}