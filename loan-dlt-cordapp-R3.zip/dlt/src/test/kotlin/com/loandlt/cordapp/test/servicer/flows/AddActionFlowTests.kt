package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.servicer.model.ActionData
import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.LoanState
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.testing.node.StartedMockNode
import org.junit.Test
import java.math.BigDecimal
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class AddActionFlowTests : AbstractFlowUnitTests() {

    private fun verifyLedger(servicer: StartedMockNode, investor: StartedMockNode, actionData: ActionData,
                             prevLoanSnapshot: LoanSnapshot, loanState: LoanState) {
        listOf(servicer, investor).forEach { node ->
            val loanSnapshot = node.get(LoanSnapshot::class.java)
            assert(loanSnapshot.loanId == loanState.linearId)
            assertNotNull(loanSnapshot.prevSnapshotId)
            assert(loanSnapshot.prevSnapshotId == prevLoanSnapshot.linearId)
            assertEquals(loanSnapshot.unpaidPrincipalBalance, actionData.unpaidPrincipalBalance)
            assertEquals(loanSnapshot.actionType, actionData.actionType)
            assertEquals(loanSnapshot.actionAmount, actionData.actionAmount)
            if (actionData.actionType == ActionType.CORP_ADV){
                val expectedCorpAdv = prevLoanSnapshot.corporateAdvanceBalance + actionData.actionAmount
            assertEquals(loanSnapshot.corporateAdvanceBalance, expectedCorpAdv)}
            else if (actionData.actionType == ActionType.ESCROW_ADV) {
                val expectedEscrowAdv = prevLoanSnapshot.escrowAdvanceBalance + actionData.actionAmount
                assertEquals(loanSnapshot.escrowAdvanceBalance, expectedEscrowAdv)
            }
        }
    }

    @Test
    fun `add pni payment action`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot = servicerNode1.get(LoanSnapshot::class.java)

        //Add PNI payment.
        val actionData = pni(prevLoanSnapshot, BigDecimal(10000))
        addAction(actionData, servicerNode1)
        network.waitQuiescent()

        verifyLedger(servicerNode1, investorNode1, actionData, prevLoanSnapshot, loanState)
    }

    @Test
    fun `add Corp advance payment action`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot1 = servicerNode1.get(LoanSnapshot::class.java)

        //Add PNI payment.
        val actionData1 = pni(prevLoanSnapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot2 = servicerNode1.get(LoanSnapshot::class.java)

        //Add CorpAdv payment.
        val actionDataCorpAdv = corpAdv(prevLoanSnapshot2, BigDecimal(1000))
        addAction(actionDataCorpAdv, servicerNode1)
        network.waitQuiescent()

        verifyLedger(servicerNode1, investorNode1, actionDataCorpAdv, prevLoanSnapshot2, loanState)
    }

    @Test
    fun `add Escrow advance payment action`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot1 = servicerNode1.get(LoanSnapshot::class.java)

        //Add PNI payment.
        val actionData1 = pni(prevLoanSnapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot2 = servicerNode1.get(LoanSnapshot::class.java)

        //Add Escrow payment.
        val actionDataEscrowAdv = escrowAdv(prevLoanSnapshot2, BigDecimal(2000))
        addAction(actionDataEscrowAdv, servicerNode1)
        network.waitQuiescent()

        verifyLedger(servicerNode1, investorNode1, actionDataEscrowAdv, prevLoanSnapshot2, loanState)
    }

    @Test
    fun `add PNI, Curtailment, Corp and Escrow advance payment actions`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val pniAction1 = pni(prevLoanSnapshot1, BigDecimal(10000))
        addAction(pniAction1, servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, pniAction1, prevLoanSnapshot1, loanState)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add escrow adv payment.
        val escrowAction2 = escrowAdv(prevLoanSnapshot2, BigDecimal(2000))
        addAction(escrowAction2, servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, escrowAction2, prevLoanSnapshot2, loanState)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        //Add Corp payment.
        val corpAction3 = corpAdv(prevLoanSnapshot3, BigDecimal(3000))
        addAction(corpAction3, servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, corpAction3, prevLoanSnapshot3, loanState)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot4 = servicerNode1.get(LoanSnapshot::class.java)
        //Add pni payment.
        val pniAction4 = pni(prevLoanSnapshot4, BigDecimal(5000))
        addAction(pniAction4, servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, pniAction4, prevLoanSnapshot4, loanState)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot5 = servicerNode1.get(LoanSnapshot::class.java)
        //Add Curtailment payment.
        val curtAction5 = curtailment(prevLoanSnapshot5, BigDecimal(5000))
        addAction(curtAction5, servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, curtAction5, prevLoanSnapshot5, loanState)

        //Get last unconsumed loan snapshot.
        val prevLoanSnapshot6 = servicerNode1.get(LoanSnapshot::class.java)
        //Add pni payment.
        val pniAction6 = pni(prevLoanSnapshot6, BigDecimal(5000))
        addAction(pniAction6, servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, pniAction6, prevLoanSnapshot6, loanState)
    }
}