package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.schema.LoanStateSchemaV1
import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.servicer.model.ServicerConfirmWithExistingServicingIntervalDto
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.LoanState
import com.loandlt.cordapp.state.ServicingInterval
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.TransactionVerificationException
import net.corda.core.contracts.hash
import net.corda.testing.node.StartedMockNode
import org.junit.Test
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Duration
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull

class ServicerConfirmationFlowTests : AbstractFlowUnitTests() {
    private fun verifyLedgerAfterPrevSnapshotRemoval(servicer: StartedMockNode, investor: StartedMockNode, prevSnapshot: LoanSnapshot) {
        listOf(servicer, investor).forEach { node ->
            val head = node.getSnapshotByLoanId(prevSnapshot.loanId).single()
            assertNotNull(head.prevSnapshotId)
            assertEquals(head.actionType, ActionType.REMOVE_PREV_ACTION)
            assertEquals(head.actionAmount, BigDecimal.ZERO)

            val tempPrevSnapshot = head.copy(
                    linearId = prevSnapshot.linearId,
                    actionType = prevSnapshot.actionType,
                    actionDate = prevSnapshot.actionDate,
                    actionAmount = prevSnapshot.actionAmount)
            assertEquals(tempPrevSnapshot.hash(), prevSnapshot.hash())
        }
    }

    @Test
    fun `confirming loan snapshot and issuance of servicing interval`() {
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        val prevLoanSnapshot = servicerNode1.get(LoanSnapshot::class.java)

        val servicingIntervalDto = ServicerConfirmDto("Sep2019", loanState.linearId.toString(), Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)

        listOf(servicerNode1, investorNode1).forEach { node ->
            val loanSnapshot = node.get(LoanSnapshot::class.java)
            val servicingInterval = node.get(ServicingInterval::class.java)
            assert(loanSnapshot.loanId == loanState.linearId)
            assertNotNull(loanSnapshot.prevSnapshotId)
            assert(loanSnapshot.prevSnapshotId == prevLoanSnapshot.linearId)
            assert(servicingInterval.isOpen())
            assert(servicingInterval.servicingIntervalId == servicingIntervalDto.servicingIntervalId)
        }
    }

    @Test
    fun `must not use same servicing interval for servicing two loans of different investors`() {
        //region ################# First loan servicing #################
        val loanState1 = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val confirmServicing = ServicerConfirmDto(
                "Sep2019",
                loanState1.linearId.toString(),
                Instant.now())
        confirmLoanSnapshot(confirmServicing, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData1 = pni(snapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode1, investorNode1, snapshot2)
        //endregion

        //region ################# Second loan servicing #################
        //Loan on-boarding.
        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("2000000")
        val loan2 = Loan("LOAN${Instant.now().toEpochMilli()}",
                loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investor2.toString(), servicer1.toString())

        // Loan on-boarding.
        loanOnboarding(loan2, investorNode2)
        network.waitQuiescent()

        // Get states from vault
        val loanState2 = servicerNode1.getStateByFieldValue(LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan2.loanId).single()
        val servicingInterval = servicerNode1.get(ServicingInterval::class.java)

        // Confirm servicing by servicer1.
        val confirmServicingUseExistingInterval = ServicerConfirmWithExistingServicingIntervalDto(
                servicingInterval.linearId.toString(),
                loanState2.linearId.toString(),
                Instant.now())

        assertFailsWith(TransactionVerificationException.ContractRejection::class) {
            confirmLoanSnapshotWithExistingServicingInterval(confirmServicingUseExistingInterval, servicerNode1)
            network.waitQuiescent()
        }
        //endregion
    }
}