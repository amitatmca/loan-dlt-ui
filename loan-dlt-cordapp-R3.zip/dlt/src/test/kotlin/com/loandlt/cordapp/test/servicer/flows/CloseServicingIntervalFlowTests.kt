package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.schema.LoanStateSchemaV1
import com.loandlt.cordapp.schema.ServicingIntervalSchemaV1
import com.loandlt.cordapp.servicer.model.BatchData
import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.servicer.model.ServicerConfirmWithExistingServicingIntervalDto
import com.loandlt.cordapp.state.*
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.TransactionVerificationException
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.contracts.hash
import net.corda.core.internal.sum
import net.corda.core.transactions.LedgerTransaction
import net.corda.testing.internal.chooseIdentity
import net.corda.testing.node.StartedMockNode
import org.junit.Test
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Duration
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.*
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class CloseServicingIntervalFlowTests : AbstractFlowUnitTests() {

    private fun verifyLedgerAfterPrevSnapshotRemoval(servicer: StartedMockNode, investor: StartedMockNode, prevSnapshot: LoanSnapshot) {
        listOf(servicer, investor).forEach { node ->
            val head = node.getSnapshotByLoanId(prevSnapshot.loanId).single()
            assertNotNull(head.prevSnapshotId)
            assertEquals(head.actionType, ActionType.REMOVE_PREV_ACTION)
            assertEquals(head.actionAmount, BigDecimal.ZERO)

            val tempPrevSnapshot = head.copy(
                    linearId = prevSnapshot.linearId,
                    actionType = prevSnapshot.actionType,
                    actionDate = prevSnapshot.actionDate,
                    actionAmount = prevSnapshot.actionAmount)
            assertEquals(tempPrevSnapshot.hash(), prevSnapshot.hash())
        }
    }

    private fun groupLoanSnapshotStates(prevSnapshots: List<LoanSnapshot>, onLedgerSnapshots: List<LoanSnapshot>)
            : List<LedgerTransaction.InOutGroup<LoanSnapshot, UniqueIdentifier>> {

        val inGroups: Map<UniqueIdentifier, List<LoanSnapshot>> = prevSnapshots.groupBy(LoanSnapshot::linearId)
        val outGroups: Map<UniqueIdentifier?, List<LoanSnapshot>> = onLedgerSnapshots.groupBy(LoanSnapshot::prevSnapshotId)

        val result = ArrayList<LedgerTransaction.InOutGroup<LoanSnapshot, UniqueIdentifier>>()

        for ((k, v) in inGroups.entries)
            result.add(LedgerTransaction.InOutGroup(v, outGroups[k] ?: emptyList(), k))
        for ((k, v) in outGroups.entries) {
            if (inGroups[k] == null)
                result.add(LedgerTransaction.InOutGroup(emptyList(), v, k!!))
        }

        return result
    }

    private fun verifyLedgerAfterClosingServicingInterval(node: StartedMockNode, prevSnapshots: List<LoanSnapshot>) {
        node.transaction {
            val loanSnapshots = node.getStates(LoanSnapshot::class.java)
            val intervals = node.getStates(ServicingInterval::class.java)
            val batches = node.getStates(ServicingBatch::class.java)

            assert(loanSnapshots.size == prevSnapshots.size)
            assert(intervals.isNotEmpty())
            assert(batches.isNotEmpty())


            val groupLoanSnapshotPrevAndUnconsumedStates = groupLoanSnapshotStates(prevSnapshots, loanSnapshots)
            groupLoanSnapshotPrevAndUnconsumedStates.forEach { prevAndUnconsumedStates ->
                val prev = prevAndUnconsumedStates.inputs.single()
                val unconsumed = prevAndUnconsumedStates.outputs.single()

                assert(unconsumed.prevSnapshotId == prev.linearId)
                assert(unconsumed.prevSnapshotHash == prev.hash())
                assert(unconsumed.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
                assert(unconsumed.actionAmount == BigDecimal.ZERO)
            }

            batches.forEach { batch ->
                val interval = intervals.firstOrNull { it.batchId == batch.linearId }
                assertNotNull(interval, "Servicing interval NOT found for batch: ${batch.linearId}")

                val loanSnapshotsForInterval = loanSnapshots.filter { it.servicingIntervalId == interval!!.linearId }
                assertTrue(loanSnapshots.isNotEmpty(), "Loan snapshot NOT found for servicing interval id: ${interval!!.linearId}")

                val expectedIntervalPayout = loanSnapshotsForInterval
                        .map { it.servicingIntervalPayout }
                        .sum()

                assert(interval.calculatedPayout == expectedIntervalPayout)
                assert(interval.cutOffDate == batch.cutOffDate)
                assert(interval.isClosed())
            }
        }
    }

    @Test
    fun `close servicing interval`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData = pni(snapshot1, BigDecimal(10000))
        addAction(actionData, servicerNode1)
        network.waitQuiescent()


        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode1, investorNode1, snapshot2)

        // Close servicing interval.
        val loanSnapshotBeforeCloseInterval = servicerNode1.get(LoanSnapshot::class.java)
        val servIntervalId = servicerNode1.get(ServicingInterval::class.java).linearId.toString()
        val batchData = BatchData(investor1.toString(),
                "Batch001",
                servicingIntervalDto.startDate,
                Instant.now().plus(30L, ChronoUnit.DAYS))
        closeServicingInterval(servIntervalId, batchData, servicerNode1)
        network.waitQuiescent()

        listOf(investorNode1, servicerNode1).forEach {
            val loanSnapshot = it.get(LoanSnapshot::class.java)
            val interval = it.get(ServicingInterval::class.java)
            val batch = it.get(ServicingBatch::class.java)
            assert(loanSnapshot.prevSnapshotId == loanSnapshotBeforeCloseInterval.linearId)
            assert(loanSnapshot.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
            assert(loanSnapshot.actionAmount == BigDecimal.ZERO)
            assert(interval.calculatedPayout == loanSnapshotBeforeCloseInterval.servicingIntervalPayout)
            assert(interval.batchId == batch.linearId)
            assert(interval.cutOffDate == batch.cutOffDate)
            assert(interval.isClosed())
        }
    }

    @Test
    fun `close servicing interval that referenced in two loans`() {
        //region ################# First loan servicing #################
        val loanState1 = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val confirmServicing = ServicerConfirmDto(
                "Sep2019",
                loanState1.linearId.toString(),
                Instant.now())
        confirmLoanSnapshot(confirmServicing, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData1 = pni(snapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode1, investorNode1, snapshot2)
        //endregion

        //region ################# Second loan servicing #################
        //Loan on-boarding.
        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("2000000")
        val loan2 = Loan("LOAN${Instant.now().toEpochMilli()}",
                loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investor1.toString(), servicer1.toString())

        // Loan on-boarding.
        loanOnboarding(loan2, investorNode1)
        network.waitQuiescent()

        // Get states from vault
        val loanState2 = servicerNode1.getStateByFieldValue(LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan2.loanId).single()
        val servicingInterval = servicerNode1.get(ServicingInterval::class.java)

        // Confirm servicing by servicer1.
        val confirmServicingUseExistingInterval = ServicerConfirmWithExistingServicingIntervalDto(
                servicingInterval.linearId.toString(),
                loanState2.linearId.toString(),
                Instant.now())
        confirmLoanSnapshotWithExistingServicingInterval(confirmServicingUseExistingInterval, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot22 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData21 = pni(snapshot22, BigDecimal(20000))
        addAction(actionData21, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot23 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData22 = pni(snapshot23, BigDecimal(20000))
        addAction(actionData22, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot24 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        // Remove pni payment action.
        removeAction(snapshot24.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode1, investorNode1, snapshot23)
        //endregion

        //region ################# Close servicing interval #################
        val prevLoanSnapshotsOfServicer = servicerNode1.getStates(LoanSnapshot::class.java)
        val prevLoanSnapshotsOfInvestor = investorNode1.getStates(LoanSnapshot::class.java)

        // Close servicing cycle.
        val batchData = BatchData(
                investor1.toString(),
                "Batch001",
                servicingInterval.startDate,
                Instant.now().plus(5L, ChronoUnit.DAYS))
        closeServicingInterval(servicingInterval.linearId.toString(), batchData, servicerNode1)
        network.waitQuiescent()

        verifyLedgerAfterClosingServicingInterval(servicerNode1, prevLoanSnapshotsOfServicer)
        verifyLedgerAfterClosingServicingInterval(investorNode1, prevLoanSnapshotsOfInvestor)
        //endregion
    }

    @Test
    fun `must not  use same servicing batch for two close servicing intervals of different investors party`() {
        //region ################# First loan servicing #################
        val loanState1 = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val confirmServicing = ServicerConfirmDto(
                "Sep2019",
                loanState1.linearId.toString(),
                Instant.now())
        confirmLoanSnapshot(confirmServicing, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData1 = pni(snapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode1, investorNode1, snapshot2)
        //endregion

        //region ################# Second loan servicing #################
        //Loan on-boarding.
        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("2000000")
        val loan2 = Loan("LOAN${Instant.now().toEpochMilli()}",
                loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investor2.toString(), servicer1.toString())

        // Loan on-boarding.
        loanOnboarding(loan2, investorNode2)
        network.waitQuiescent()

        // Get states from vault
        val loanState2 = servicerNode1.getStateByFieldValue(LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan2.loanId).single()

        // Confirm servicing by servicer1.
        val confirmServicing2 = ServicerConfirmDto(
                "SID${Instant.now().toEpochMilli()}",
                loanState2.linearId.toString(),
                Instant.now())

        confirmLoanSnapshot(confirmServicing2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot22 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData22 = pni(snapshot22, BigDecimal(10000))
        addAction(actionData22, servicerNode1)
        network.waitQuiescent()
        //endregion

        // region Close servicing interval of two different investor but use single batch state.
        val intervals = servicerNode1.getStates(ServicingInterval::class.java)
        assert(intervals.size == 2)

        // Close servicing interval.
        val batchData = BatchData(
                investor1.toString(),
                "Batch001",
                confirmServicing2.startDate,
                Instant.now().plus(5L, ChronoUnit.DAYS))

        // Close first servicing interval with `Batch001`.
        closeServicingInterval(intervals[0].linearId.toString(), batchData, servicerNode1)
        network.waitQuiescent()

        // Get existing batch state.
        val batchState = servicerNode1.get(ServicingBatch::class.java)

        // Close second servicing interval using existing batch `Batch001`.
        assertFailsWith(TransactionVerificationException.ContractRejection::class) {
            closeServicingIntervalUsingExistingBatch(
                    intervals[1].linearId.toString(),
                    batchState.linearId.toString(),
                    servicerNode1)
        }
        // endregion
    }

    @Test
    fun `create and close two servicing interval for four loans`() {

        val (_, _, interval1) = createLoanDoServicingByTwoServicerParites(investorNode1, servicerNode1)
        val (_, _, interval2) = createLoanDoServicingByTwoServicerParites(investorNode1, servicerNode2)

        val loanSnapshotsInvestor1 = investorNode1.getStates(LoanSnapshot::class.java)
        assertEquals(loanSnapshotsInvestor1.size, 4)
        assertEquals(investorNode1.getStates(LoanState::class.java).size, 4)
        assertEquals(investorNode1.getStates(ServicingInterval::class.java).size, 2)

        val loanSnapshotsServicerNode1 = servicerNode1.getStates(LoanSnapshot::class.java)
        assertEquals(loanSnapshotsServicerNode1.size, 2)
        assertEquals(servicerNode1.getStates(LoanState::class.java).size, 2)
        assertEquals(servicerNode1.getStates(ServicingInterval::class.java).size, 1)

        val loanSnapshotsServicerNode2 = servicerNode2.getStates(LoanSnapshot::class.java)
        assertEquals(loanSnapshotsServicerNode2.size, 2)
        assertEquals(servicerNode2.getStates(LoanState::class.java).size, 2)
        assertEquals(servicerNode2.getStates(ServicingInterval::class.java).size, 1)

        //region ################# Close servicing interval by ServicerNode1 #################
        // Close servicing cycle.
        val batchData1 = BatchData(
                investor1.toString(),
                "Batch${Instant.now().toEpochMilli()}",
                interval1.startDate,
                Instant.now().plus(5L, ChronoUnit.DAYS))
        closeServicingInterval(interval1.linearId.toString(), batchData1, servicerNode1)
        network.waitQuiescent()

        verifyLedgerAfterClosingServicingInterval(servicerNode1, loanSnapshotsServicerNode1)
        //endregion

        //region ################# Close servicing interval by ServicerNode2 #################
        // Close servicing cycle.
        val batchData2 = BatchData(
                investor1.toString(),
                "Batch${Instant.now().toEpochMilli()}",
                interval2.startDate,
                Instant.now().plus(5L, ChronoUnit.DAYS))
        closeServicingInterval(interval2.linearId.toString(), batchData2, servicerNode2)
        network.waitQuiescent()

        verifyLedgerAfterClosingServicingInterval(servicerNode2, loanSnapshotsServicerNode2)
        //endregion

        // Verify vault state of investor1 party.
        verifyLedgerAfterClosingServicingInterval(investorNode1, loanSnapshotsInvestor1)
    }

    fun createLoanDoServicingByTwoServicerParites(investorNode: StartedMockNode, servicerNode: StartedMockNode)
            : Triple<LoanState, LoanState, ServicingInterval> {

        //region ################# First loan servicing #################
        val investorParty = investorNode.info.chooseIdentity()
        val servicerParty = servicerNode.info.chooseIdentity()

        val loanState1 = loanOnboarding(investorNode, servicerNode)
        network.waitQuiescent()
        //Confirm servicing by servicer.
        val confirmServicing = ServicerConfirmDto(
                "SI${Instant.now().toEpochMilli()}",
                loanState1.linearId.toString(),
                Instant.now())
        confirmLoanSnapshot(confirmServicing, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode.getSnapshotByLoanId(loanState1.linearId).single()
        //Add PNI payment.
        val actionData1 = pni(snapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode.getSnapshotByLoanId(loanState1.linearId).single()
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode.getSnapshotByLoanId(loanState1.linearId).single()
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode, investorNode, snapshot2)
        //endregion

        //region ################# Second loan servicing #################
        //Loan on-boarding.
        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("2000000")
        val loan2 = Loan("LOAN${Instant.now().toEpochMilli()}",
                loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investorParty.toString(), servicerParty.toString())

        // Loan on-boarding.
        loanOnboarding(loan2, investorNode)
        network.waitQuiescent()

        // Get states from vault
        val loanState2 = servicerNode.getStateByFieldValue(LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan2.loanId).single()

        val servicingInterval = servicerNode.getStateByFieldValue(
                ServicingInterval::class.java,
                ServicingIntervalSchemaV1.PersistentServicingInterval::servicingIntervalId,
                confirmServicing.servicingIntervalId).single()

        // Confirm servicing by servicer1.
        val confirmServicingUseExistingInterval = ServicerConfirmWithExistingServicingIntervalDto(
                servicingInterval.linearId.toString(),
                loanState2.linearId.toString(),
                Instant.now())
        confirmLoanSnapshotWithExistingServicingInterval(confirmServicingUseExistingInterval, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot22 = servicerNode.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData21 = pni(snapshot22, BigDecimal(20000))
        addAction(actionData21, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot23 = servicerNode.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData22 = pni(snapshot23, BigDecimal(20000))
        addAction(actionData22, servicerNode)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot24 = servicerNode.getSnapshotByLoanId(loanState2.linearId).single()
        // Remove pni payment action.
        removeAction(snapshot24.linearId.toString(), servicerNode)
        network.waitQuiescent()
        verifyLedgerAfterPrevSnapshotRemoval(servicerNode, investorNode, snapshot23)
        //endregion

        return Triple(loanState1, loanState2, servicingInterval)
    }
}