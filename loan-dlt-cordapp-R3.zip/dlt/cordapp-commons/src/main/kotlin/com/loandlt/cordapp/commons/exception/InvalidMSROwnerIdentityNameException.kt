package com.loandlt.cordapp.commons.exception

import net.corda.core.CordaRuntimeException

class InvalidMSROwnerIdentityNameException(override val message: String) : CordaRuntimeException(message)