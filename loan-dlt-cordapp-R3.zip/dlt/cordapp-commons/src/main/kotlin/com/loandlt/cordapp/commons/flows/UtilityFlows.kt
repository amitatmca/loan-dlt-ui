package com.loandlt.cordapp.commons.flows

import net.corda.core.contracts.requireThat
import net.corda.core.crypto.isFulfilledBy
import net.corda.core.flows.FlowSession
import net.corda.core.flows.SignTransactionFlow
import net.corda.core.transactions.SignedTransaction

class SignTxFlowNoChecking(otherSideSession: FlowSession) : SignTransactionFlow(otherSideSession) {
    override fun checkTransaction(stx: SignedTransaction) = requireThat {
        val isSignedByInitiator = stx.sigs.any { otherSideSession.counterparty.owningKey.isFulfilledBy(it.by) }
        require(isSignedByInitiator) {
            "Must be signed by transaction initiating party"
        }
    }
}