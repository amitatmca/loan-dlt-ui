package com.loandlt.cordapp.investor.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.exception.InvalidMSROwnerIdentityNameException
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.LoanStateContract
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.flows.AbstractLoanOnboardingFlow
import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.LoanState
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.CordaX500Name
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds

/**
 * Flow logic to create the LoanState and LoanSnapshot on the ledger and share it with Servicer party.
 */
@StartableByRPC
class LoanOnboardingFlow(private val loan: Loan) : AbstractLoanOnboardingFlow<SignedTransaction>() {

    companion object {
        object RESOLVE_IDENTITIES : Step("Resolve identities from the string values.")
        object BUILD_LOAN_STATE : Step("Building loan state.")
        object BUILD_LOAN_SNAPSHOT : Step("Building the loan snapshot.")
        object GENERATE_TX : Step("Generate the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(RESOLVE_IDENTITIES, BUILD_LOAN_STATE, BUILD_LOAN_SNAPSHOT, GENERATE_TX, SIGN_TX,
                FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call(): SignedTransaction {
        logger.info("Start LoanOnboardingFlow.")
        progressTracker.currentStep = RESOLVE_IDENTITIES
        val msrOwner = serviceHub.networkMapCache.getPeerByLegalName(CordaX500Name.parse(loan.msrOwner))
                ?: throw InvalidMSROwnerIdentityNameException(loan.msrOwner)
        val servicer = serviceHub.networkMapCache.getPeerByLegalName(CordaX500Name.parse(loan.servicer))
                ?: throw InvalidMSROwnerIdentityNameException(loan.servicer)

        progressTracker.currentStep = BUILD_LOAN_STATE
        val loanState = LoanState(loan.loanId, ourIdentity, msrOwner, servicer)

        progressTracker.currentStep = BUILD_LOAN_SNAPSHOT
        val instant = serviceHub.clock.instant()!!
        val loanSnapshot = loan.run {
            LoanSnapshot(loanState.linearId, unpaidPrincipalBalance, dueDate, noteRate, pmtCalcPrincipal, pmtCalcTerm,
                    indexCode, firstRateChangeDate, rateChangeFrequency, rateMargin, corporateAdvanceBalance,
                    escrowAdvanceBalance, ourIdentity, servicer, ActionType.APPOINT, instant)
        }

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(serviceHub.firstNotary())
                .addOutputState(loanState, LoanStateContract.ID)
                .addOutputState(loanSnapshot, ServicingContract.ID)
                .addCommand(LoanStateContract.Commands.Appoint(), loanState.owningInvestor.owningKey)
                .addCommand(ServicingContract.Commands.CreateLoanSnapshot(), loanSnapshot.owningInvestor.owningKey)
                .setTimeWindow(serviceHub.clock.instant(), 60.seconds)

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val servicerSession = initiateFlow(servicer)
        val ftx = subFlow(FinalityFlow(stx, listOf(servicerSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Loan on-boarded and created the loan-snapshot by investor: `$ourIdentity` and shared with servicer: `$servicer`.",
                servicer))
        logger.info("End LoanOnboardingFlow.")
        return ftx
    }
}