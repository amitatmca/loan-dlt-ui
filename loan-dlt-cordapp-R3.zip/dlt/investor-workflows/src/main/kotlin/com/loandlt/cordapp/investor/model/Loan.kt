package com.loandlt.cordapp.investor.model

import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Instant

@CordaSerializable
data class Loan(
        val loanId: String,
        val unpaidPrincipalBalance: BigDecimal,
        val dueDate: Instant,
        val noteRate: BigDecimal,
        val pmtCalcPrincipal: BigDecimal,
        val pmtCalcTerm: BigInteger,
        val indexCode: String,
        val firstRateChangeDate: Instant,
        val rateChangeFrequency: BigInteger,
        val rateMargin: BigDecimal,
        val corporateAdvanceBalance: BigDecimal,
        val escrowAdvanceBalance: BigDecimal,
        val msrOwner: String,
        val servicer: String
)