package com.loandlt.cordapp.investor.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingBatchContract
import com.loandlt.cordapp.contract.ServicingIntervalContract
import com.loandlt.cordapp.flows.AbstractConfirmPaymentFlow
import com.loandlt.cordapp.schema.ServicingIntervalSchemaV1
import com.loandlt.cordapp.state.BatchStatus
import com.loandlt.cordapp.state.ServicingBatch
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds

/**
 * Investor confirms the payment received for given wire ID shared by Servicer party.
 * This flow creates new output of [ServicingBatch] state with updated status value to [BatchStatus.SETTLED] as token of payment confirmation.
 * It also consumes all [ServicingInterval] states has reference of this servicing batch linearId.
 */
@StartableByRPC
class ConfirmPaymentFlow(private val batchLinearId: String) : AbstractConfirmPaymentFlow<Unit>() {

    companion object {
        object QUERY_BATCH : Step("Query the vault to retrieve batch state with given batch linearId.")
        object QUERY_INTERVAL : Step("Query the vault to retrieve servicing intervals.")
        object BUILD_BATCH_STATE : Step("Building servicing batch output state.")
        object GENERATE_TX : Step("Generate the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_BATCH, QUERY_INTERVAL, BUILD_BATCH_STATE, GENERATE_TX, SIGN_TX, FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start ConfirmPaymentFlow.")
        progressTracker.currentStep = QUERY_BATCH
        val linearId = batchLinearId.toUniqueIdentifier()
        val inBatch = serviceHub.getSingleStateByLinearId(linearId, ServicingBatch::class.java)

        progressTracker.currentStep = QUERY_INTERVAL
        val inServicingIntervals = serviceHub.getStateByFieldValue(
                ServicingInterval::class.java,
                ServicingIntervalSchemaV1.PersistentServicingInterval::batchId,
                batchLinearId)

        progressTracker.currentStep = BUILD_BATCH_STATE
        val outBatch = inBatch.state.data.copy(status = BatchStatus.SETTLED)

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(inBatch.state.notary)
                .addInputState(inBatch)
                .addOutputState(outBatch, ServicingBatchContract.ID)
                .addCommand(ServicingBatchContract.Commands.SettleBatch(), ourIdentity.owningKey)
                .addCommand(ServicingIntervalContract.Commands.SettleBatch(), ourIdentity.owningKey)
                .setTimeWindow(serviceHub.clock.instant(), 60.seconds)

        inServicingIntervals.forEach { utx.addInputState(it) }

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val servicer = serviceHub.resolveIdentity(outBatch.servicer)
        val servicerSession = initiateFlow(servicer)
        val ftx = subFlow(FinalityFlow(stx, listOf(servicerSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Owning investor `${outBatch.owningInvestor}` confirmed payment received for wiredId `${outBatch.wireId}` from servicer `${outBatch.servicer}`.",
                servicer))
        logger.info("End ConfirmPaymentFlow.")
    }
}