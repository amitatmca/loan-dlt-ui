package com.loandlt.cordapp.investor.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.flows.AbstractServicerConfirmationWithExistingServicingIntervalFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.FlowSession
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.ReceiveFinalityFlow

@InitiatedBy(AbstractServicerConfirmationWithExistingServicingIntervalFlow::class)
class ServicerConfirmationWithExistingServicingIntervalFlowResponder(private val otherSideSession: FlowSession) : FlowLogic<Unit>() {
    @Suspendable
    override fun call() {
        //Await to receive the transaction that was signed then will be committed to vault.
        subFlow(ReceiveFinalityFlow(otherSideSession))
    }
}

