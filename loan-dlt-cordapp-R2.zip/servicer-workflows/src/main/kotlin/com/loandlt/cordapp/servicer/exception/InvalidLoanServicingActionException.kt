package com.loandlt.cordapp.servicer.exception

import net.corda.core.CordaRuntimeException

class InvalidLoanServicingActionException(override val message: String) : CordaRuntimeException(message)