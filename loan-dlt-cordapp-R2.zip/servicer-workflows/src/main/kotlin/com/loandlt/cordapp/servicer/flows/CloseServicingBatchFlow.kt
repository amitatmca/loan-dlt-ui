package com.loandlt.cordapp.servicer.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingBatchContract
import com.loandlt.cordapp.flows.AbstractCloseServicingBatchFlow
import com.loandlt.cordapp.schema.ServicingIntervalSchemaV1
import com.loandlt.cordapp.servicer.exception.NoServicingIntervalFoundException
import com.loandlt.cordapp.servicer.model.CloseBatchDto
import com.loandlt.cordapp.state.BatchStatus
import com.loandlt.cordapp.state.ServicingBatch
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant

/**
 * Flow logic to close the servicing batch by consuming on-ledger state and creating new out [ServicingBatch] contract state.
 */
@StartableByRPC
class CloseServicingBatchFlow(private val closeBatchDto: CloseBatchDto) : AbstractCloseServicingBatchFlow<Unit>() {

    companion object {
        object QUERY_BATCH : Step("Query the vault to retrieve the servicing batch state.")
        object QUERY_SRV_INTERVAL : Step("Query the vault to retrieve the servicing interval state.")
        object BUILD_BATCH : Step("Build servicing batch output state.")
        object GENERATE_TX : Step("Generate the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_SRV_INTERVAL, QUERY_BATCH, BUILD_BATCH, GENERATE_TX, SIGN_TX, FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start CloseServicingBatchFlow.")
        progressTracker.currentStep = QUERY_BATCH
        val batchLinearId = closeBatchDto.servicingBatchLinearId.toUniqueIdentifier()
        val inBatch = serviceHub.getSingleStateByLinearId(
                batchLinearId,
                ServicingBatch::class.java)

        progressTracker.currentStep = QUERY_SRV_INTERVAL
        val inServicingIntervals = serviceHub.getStateByFieldValue(
                ServicingInterval::class.java,
                ServicingIntervalSchemaV1.PersistentServicingInterval::batchId,
                closeBatchDto.servicingBatchLinearId
        )
        if (inServicingIntervals.isEmpty()) throw NoServicingIntervalFoundException("for batch Id: ${closeBatchDto.servicingBatchLinearId}")

        val calculatedPayout = inServicingIntervals.fold(BigDecimal.ZERO) { sum, state -> sum + state.state.data.calculatedPayout }

        progressTracker.currentStep = BUILD_BATCH
        val outBatch = inBatch.state.data.copy(
                calculatedPayout = calculatedPayout,
                status = BatchStatus.CLOSED,
                wireId = closeBatchDto.wireId,
                wireXferDate = closeBatchDto.wireXferDate)

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(inBatch.state.notary)
                .addInputState(inBatch)
                .addOutputState(outBatch, ServicingBatchContract.ID)
                .addCommand(ServicingBatchContract.Commands.CloseBatch(), ourIdentity.owningKey)
                .setTimeWindow(Instant.now(), Duration.ofSeconds(60))

        inServicingIntervals.forEach { utx.addReferenceState(it.referenced()) }

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val owningInvestor = serviceHub.resolveIdentity(outBatch.owningInvestor)
        val owningInvestorSession = initiateFlow(owningInvestor)
        val ftx = subFlow(FinalityFlow(stx, listOf(owningInvestorSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Servicer $ourIdentity closed the servicing batch with id: ${outBatch.linearId}.",
                owningInvestor))
        logger.info("End CloseServicingBatchFlow.")
    }
}