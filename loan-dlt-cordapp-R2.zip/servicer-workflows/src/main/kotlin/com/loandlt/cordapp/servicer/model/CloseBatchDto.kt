package com.loandlt.cordapp.servicer.model

import net.corda.core.serialization.CordaSerializable
import java.time.Instant

@CordaSerializable
data class CloseBatchDto(
        val servicingBatchLinearId: String,
        val wireId: String,
        val wireXferDate: Instant)