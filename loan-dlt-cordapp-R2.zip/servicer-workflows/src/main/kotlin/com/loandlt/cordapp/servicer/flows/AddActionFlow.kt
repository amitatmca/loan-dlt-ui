package com.loandlt.cordapp.servicer.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.exception.InvalidLoanStateLinearIdException
import com.loandlt.cordapp.exception.TooManyStatesFoundException
import com.loandlt.cordapp.flows.AbstractAddActionFlow
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import com.loandlt.cordapp.servicer.model.ActionData
import com.loandlt.cordapp.state.LoanSnapshot
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds

/**
 * Flow logic to record the new action by creating the new loan snapshot state.
 */
// TODO Implement the solution to handle the change in servicing interval after closing of previous one.
// Required to create the new servicing interval or add reference state of the existing in same transaction builder.
@StartableByRPC
class AddActionFlow(private val actionData: ActionData) : AbstractAddActionFlow<Unit>() {

    companion object {
        object QUERY_SNAPSHOT : Step("Query the vault to retrieve the LoanSnapshot state by loanId.")
        object ADD_ACTION : Step("Add new action to loan snapshot.")
        object GENERATE_TX : Step("Generate the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_SNAPSHOT, ADD_ACTION, GENERATE_TX, SIGN_TX, FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start AddActionFlow.")
        progressTracker.currentStep = QUERY_SNAPSHOT
        val expLoanId = LoanSnapshotSchemaV1.PersistentLoanSnapshot::loanId.equal(actionData.loanLinearId)
        val loanSnapshotStates = serviceHub.vaultService.queryBy(
                LoanSnapshot::class.java,
                QueryCriteria.VaultCustomQueryCriteria(expLoanId)).states
        if (loanSnapshotStates.size > 1) throw TooManyStatesFoundException("LoanSnapshot states with LoanId: ${actionData.loanLinearId}")
        val prevLoanSnapshotStateRef = loanSnapshotStates.singleOrNull()
                ?: throw InvalidLoanStateLinearIdException(actionData.loanLinearId)

        progressTracker.currentStep = ADD_ACTION
        val outLoanSnapshot = actionData.run {
            prevLoanSnapshotStateRef.state.data.addAction(
                    actionType,
                    actionAmount,
                    actionDate,
                    unpaidPrincipalBalance,
                    dueDate)
        }

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(prevLoanSnapshotStateRef.state.notary)
                .addInputState(prevLoanSnapshotStateRef)
                .addOutputState(outLoanSnapshot, ServicingContract.ID)
                .addCommand(ServicingContract.Commands.AddAction(), outLoanSnapshot.servicer.owningKey)
                .setTimeWindow(serviceHub.clock.instant(), 60.seconds)

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val owningInvestor = serviceHub.resolveIdentity(outLoanSnapshot.owningInvestor)
        val owningInvestorSession = initiateFlow(owningInvestor)
        val ftx = subFlow(FinalityFlow(stx, listOf(owningInvestorSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Confirmed loan-snapshot and issued new servicing interval by servicer: `$ourIdentity` " +
                        "and shared with owning investor: `$owningInvestor`.",
                owningInvestor))
        logger.info("End AddActionFlow.")
    }
}