package com.loandlt.cordapp.servicer.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.contract.ServicingIntervalContract
import com.loandlt.cordapp.exception.InvalidLoanStateLinearIdException
import com.loandlt.cordapp.exception.TooManyStatesFoundException
import com.loandlt.cordapp.flows.AbstractServicerConfirmationFlow
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds

/**
 * Flow logic to confirm the loan servicing and issue the servicing interval state to investor.
 * This flow will create
 *  1. New [ServicingInterval] contract state contains detail about loan servicing cycle.
 *  2. New version of [LoanSnapshot] contract state as token of servicing confirmation.
 */
@StartableByRPC
class ServicerConfirmationFlow(private val servicerConfirmDto: ServicerConfirmDto) : AbstractServicerConfirmationFlow<Unit>() {

    companion object {
        object QUERY_SNAPSHOT : Step("Query vault to retrieve the LoanSnapshot by loanId.")
        object BUILD_SERVICING_INTERVAL : Step("Build servicing interval state.")
        object ADD_ACTION : Step("Add confirm action to loan snapshot.")
        object GENERATE_TX : Step("Generate the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_SNAPSHOT, ADD_ACTION, BUILD_SERVICING_INTERVAL, GENERATE_TX, SIGN_TX,
                FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start ServicerConfirmationFlow.")
        progressTracker.currentStep = QUERY_SNAPSHOT
        val loanSnapshotStates = serviceHub.getStateByFieldValue(
                LoanSnapshot::class.java,
                LoanSnapshotSchemaV1.PersistentLoanSnapshot::loanId,
                servicerConfirmDto.loanLinearId
        )

        if (loanSnapshotStates.size > 1) throw TooManyStatesFoundException("LoanSnapshot states for LoanId: ${servicerConfirmDto.loanLinearId}")

        val prevLoanSnapshotStateRef = loanSnapshotStates.singleOrNull()
                ?: throw InvalidLoanStateLinearIdException(servicerConfirmDto.loanLinearId)
        val prevLoanSnapshot = prevLoanSnapshotStateRef.state.data

        progressTracker.currentStep = BUILD_SERVICING_INTERVAL
        val servicingInterval = servicerConfirmDto.run {
            ServicingInterval(
                    servicingIntervalId,
                    startDate,
                    prevLoanSnapshot.owningInvestor,
                    prevLoanSnapshot.servicer
            )
        }

        progressTracker.currentStep = ADD_ACTION
        val loanSnapshot = prevLoanSnapshot.confirmServicing(serviceHub.clock.instant(), servicingInterval.linearId)

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(prevLoanSnapshotStateRef.state.notary)
                .addInputState(prevLoanSnapshotStateRef)
                .addOutputState(servicingInterval, ServicingIntervalContract.ID)
                .addOutputState(loanSnapshot, ServicingContract.ID)
                .addCommand(ServicingIntervalContract.Commands.CreateServicingInterval(), servicingInterval.servicer.owningKey)
                .addCommand(ServicingContract.Commands.ServicerConfirms(), loanSnapshot.servicer.owningKey)
                .setTimeWindow(serviceHub.clock.instant(), 60.seconds)

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val owningInvestor = serviceHub.resolveIdentity(loanSnapshot.owningInvestor)
        val owningInvestorSession = initiateFlow(owningInvestor)
        val ftx = subFlow(FinalityFlow(stx, listOf(owningInvestorSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Confirmed loan-snapshot and issued new servicing interval by servicer: `$ourIdentity` " +
                        "and shared with owning investor: `$owningInvestor`.",
                owningInvestor))
        logger.info("End ServicerConfirmationFlow.")
    }
}