package com.loandlt.cordapp.servicer.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.flows.AbstractRemovePrevActionFlow
import com.loandlt.cordapp.servicer.exception.InvalidLoanServicingActionException
import com.loandlt.cordapp.state.LoanSnapshot
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.Vault
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds

/**
 * Flow logic to remove a head of the chain loan snapshot state by consuming it.
 * And restoring back it's previous snapshot as new head/unconsumed state.
 */
@StartableByRPC
class RemovePrevActionFlow(private val loanSnapshotLinearId: String) : AbstractRemovePrevActionFlow<Unit>() {
    companion object {
        object QUERY_SNAPSHOT : Step("Query the vault to retrieve the loan snapshot state by linearId.")
        object BUILD_STATES : Step("Build output states of loan snapshot.")
        object BUILD_COMMAND : Step("Build command with prev snapshot action data.")
        object GENERATE_TX : Step("Generate the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_SNAPSHOT, BUILD_STATES, BUILD_COMMAND, GENERATE_TX, SIGN_TX, FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start RemovePrevActionFlow.")
        progressTracker.currentStep = QUERY_SNAPSHOT
        val headLinearId = loanSnapshotLinearId.toUniqueIdentifier()
        val headLoanSnapshot = serviceHub.getSingleStateByLinearId(
                headLinearId,
                LoanSnapshot::class.java
        )

        if (headLoanSnapshot.state.data.prevSnapshotId == null) throw InvalidLoanServicingActionException("Should not be initial snapshot.")
        val prevLoanSnapshot = serviceHub.getSingleStateByLinearId(
                headLoanSnapshot.state.data.prevSnapshotId!!,
                LoanSnapshot::class.java,
                Vault.StateStatus.CONSUMED
        ).state.data

        progressTracker.currentStep = BUILD_STATES
        val outLoanSnapshot = prevLoanSnapshot.rollbackSnapshot()

        progressTracker.currentStep = BUILD_COMMAND
        val removePrevActionCommand = ServicingContract.Commands.RemovePrevAction(
                prevLoanSnapshot.actionType,
                prevLoanSnapshot.actionDate,
                prevLoanSnapshot.actionAmount)

        progressTracker.currentStep = GENERATE_TX
        val utx = TransactionBuilder(headLoanSnapshot.state.notary)
                .addInputState(headLoanSnapshot)
                .addOutputState(outLoanSnapshot, ServicingContract.ID)
                .addCommand(removePrevActionCommand, ourIdentity.owningKey)
                .setTimeWindow(serviceHub.clock.instant(), 60.seconds)

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val owningInvestor = serviceHub.resolveIdentity(outLoanSnapshot.owningInvestor)
        val owningInvestorSession = initiateFlow(owningInvestor)
        val ftx = subFlow(FinalityFlow(stx, listOf(owningInvestorSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Servicer $ourIdentity removed the loan snapshot with id: ${headLoanSnapshot.state.data.linearId} and rollback to previous snapshot.",
                owningInvestor))
        logger.info("End RemovePrevActionFlow.")
    }
}
