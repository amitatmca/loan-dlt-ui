package com.loandlt.cordapp.servicer.flows

import co.paralleluniverse.fibers.Suspendable
import com.loandlt.cordapp.commons.exception.InvalidInvestorIdentityNameException
import com.loandlt.cordapp.commons.flows.TxNoteFlow
import com.loandlt.cordapp.contract.ServicingBatchContract
import com.loandlt.cordapp.contract.ServicingContract
import com.loandlt.cordapp.contract.ServicingIntervalContract
import com.loandlt.cordapp.flows.AbstractCloseServicingIntervalFlow
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import com.loandlt.cordapp.servicer.exception.MissingServicingBatchInfoException
import com.loandlt.cordapp.servicer.model.BatchData
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.ServicingBatch
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.contracts.Command
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.CordaX500Name
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import net.corda.core.utilities.seconds
import java.math.BigDecimal

/**
 * Flow logic to close the servicing interval by consuming on-ledger state and creating new out [ServicingInterval] contract state.
 * It also may create the [ServicingBatch] contract state if already not exist on-ledger. Or references the existing servicing batch linearId.
 */

// TODO Add new flow to create the new [ServicingBatch] contract state only.

@StartableByRPC
class CloseServicingIntervalFlow private constructor(private val servicingIntervalLinearId: String,
                                                     private val servicingBatchLinearId: String?,
                                                     private val servicingBatchData: BatchData?) : AbstractCloseServicingIntervalFlow<Unit>() {
    constructor(servicingIntervalLinearId: String,
                servicingBatchLinearId: String) : this(servicingIntervalLinearId, servicingBatchLinearId, null)

    constructor(servicingIntervalLinearId: String,
                servicingBatchData: BatchData) : this(servicingIntervalLinearId, null, servicingBatchData)

    companion object {
        object QUERY_SRV_INTERVAL : Step("Query the vault to retrieve the servicing interval state.")
        object GENERATE_TX : Step("Generate the transaction.")
        object QUERY_BATCH : Step("Query the vault to retrieve the servicing batch state and add it as reference state to transaction builder.")
        object BUILD_BATCH : Step("Build servicing batch output state.")
        object QUERY_LOAN_SNAPSHOTS : Step("Query the vault to retrieve the all loan snapshot states that has reference of servicing interval Id.")
        object BUILD_LOAN_SNAPSHOTS : Step("Build loan snapshot output states.")
        object BUILD_SRV_INTERVAL : Step("Build servicing interval output state.")
        object BUILD_COMMAND : Step("Build commands for close servicing interval, to add close action to loan snapshot and if required to create new batch.")
        object ADD_LOAN_SNAPSHOT_SRV_INTERVAL_TO_TX : Step("Add loan snapshot and servicing interval to the transaction.")
        object SIGN_TX : Step("Sign the transaction.")

        object FINALISING : Step("Finalising transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(QUERY_SRV_INTERVAL, QUERY_BATCH, BUILD_BATCH, GENERATE_TX, BUILD_SRV_INTERVAL,
                QUERY_LOAN_SNAPSHOTS, BUILD_LOAN_SNAPSHOTS, BUILD_COMMAND, ADD_LOAN_SNAPSHOT_SRV_INTERVAL_TO_TX, SIGN_TX,
                FINALISING)
    }

    override val progressTracker: ProgressTracker = tracker()

    @Suspendable
    override fun call() {
        logger.info("Start CloseServicingIntervalFlow.")
        progressTracker.currentStep = QUERY_SRV_INTERVAL
        val servicingIntervalId = servicingIntervalLinearId.toUniqueIdentifier()
        val inServicingInterval = serviceHub.getSingleStateByLinearId(
                servicingIntervalId,
                ServicingInterval::class.java
        )

        progressTracker.currentStep = GENERATE_TX
        val txb = TransactionBuilder(inServicingInterval.state.notary)
        val (utx, servicingBatch) = addServicingBatch(txb)


        progressTracker.currentStep = QUERY_LOAN_SNAPSHOTS
        // TODO The below queryBy method retrieve max 200 records found for given criteria.
        // If records founds are more than 200 it throws exception alerting that you must specify a [PageSpecification].
        val servicingIntervalExp = LoanSnapshotSchemaV1.PersistentLoanSnapshot::servicingIntervalId.equal(servicingIntervalLinearId)
        val inLoanSnapshots = serviceHub.vaultService.queryBy(LoanSnapshot::class.java,
                criteria = QueryCriteria.VaultCustomQueryCriteria(servicingIntervalExp)).states

        progressTracker.currentStep = BUILD_LOAN_SNAPSHOTS
        val outLoanSnapshots = inLoanSnapshots.map { it.state.data.closeServicingInterval() }
        val calculatedPayout = outLoanSnapshots.asSequence()
                .map { it.servicingIntervalPayout }
                .fold(BigDecimal.ZERO, BigDecimal::add)

        progressTracker.currentStep = BUILD_SRV_INTERVAL
        val outServicingInterval = inServicingInterval.state.data
                .closeInterval(calculatedPayout, servicingBatch.cutOffDate, servicingBatch.linearId)

        progressTracker.currentStep = BUILD_COMMAND
        val servicingCloseIntervalCmd = ServicingContract.Commands.CloseServicingInterval()
        val addActionCloseIntervalCmd = ServicingIntervalContract.Commands.CloseServicingInterval()

        progressTracker.currentStep = ADD_LOAN_SNAPSHOT_SRV_INTERVAL_TO_TX
        inLoanSnapshots.forEach { utx.addInputState(it) }
        outLoanSnapshots.forEach { utx.addOutputState(it, ServicingContract.ID) }
        utx.apply {
            addInputState(inServicingInterval)
            addOutputState(outServicingInterval)
            addCommand(servicingCloseIntervalCmd, ourIdentity.owningKey)
            addCommand(addActionCloseIntervalCmd, ourIdentity.owningKey)
            setTimeWindow(serviceHub.clock.instant(), 60.seconds)
        }

        progressTracker.currentStep = SIGN_TX
        val stx = serviceHub.signInitialTransaction(utx)

        progressTracker.currentStep = FINALISING
        val owningInvestor = serviceHub.resolveIdentity(outServicingInterval.owningInvestor)
        val owningInvestorSession = initiateFlow(owningInvestor)
        val ftx = subFlow(FinalityFlow(stx, listOf(owningInvestorSession), FINALISING.childProgressTracker()))

        subFlow(TxNoteFlow(ftx.id,
                "Servicer $ourIdentity closed the servicing-interval with with id: ${outServicingInterval.linearId}.",
                owningInvestor))
        logger.info("End CloseServicingIntervalFlow.")
    }

    @Suspendable
    private fun addServicingBatch(transactionBuilder: TransactionBuilder): Pair<TransactionBuilder, ServicingBatch> {
        val batchState = when {
            servicingBatchLinearId != null -> {
                progressTracker.currentStep = QUERY_BATCH
                val batchRefState = serviceHub.getSingleStateByLinearId(
                        servicingBatchLinearId.toUniqueIdentifier(),
                        ServicingBatch::class.java).referenced()

                transactionBuilder.addReferenceState(batchRefState)
                batchRefState.stateAndRef.state.data
            }
            servicingBatchData != null -> {
                progressTracker.currentStep = BUILD_BATCH
                val investorX500Name = CordaX500Name.parse(servicingBatchData.owningInvestor)
                val investorParty = serviceHub.networkMapCache.getPeerByLegalName(investorX500Name)
                        ?: throw InvalidInvestorIdentityNameException(investorX500Name.toString())

                val servicingBatch = ServicingBatch(
                        investorParty,
                        ourIdentity,
                        servicingBatchData.servicingBatchId,
                        servicingBatchData.startDate,
                        servicingBatchData.cutOffDate)
                val createBatchCmd = Command(ServicingBatchContract.Commands.CreateBatch(), ourIdentity.owningKey)
                transactionBuilder.addOutputState(servicingBatch, ServicingBatchContract.ID)
                transactionBuilder.addCommand(createBatchCmd)
                servicingBatch
            }
            else -> throw MissingServicingBatchInfoException("Missing servicing batch ID or Data.")
        }
        return transactionBuilder to batchState
    }
}