package com.loandlt.cordapp.commons.exception

import net.corda.core.CordaRuntimeException

class InvalidInvestorIdentityNameException(override val message: String) : CordaRuntimeException(message)