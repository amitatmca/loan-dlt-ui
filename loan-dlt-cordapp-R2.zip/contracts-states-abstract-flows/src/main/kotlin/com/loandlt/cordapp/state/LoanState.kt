package com.loandlt.cordapp.state

import com.loandlt.cordapp.contract.LoanStateContract
import com.loandlt.cordapp.schema.LoanStateSchemaV1
import net.corda.core.contracts.BelongsToContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState

/***
 * LoanState state object to be stored on vault.
 */

@BelongsToContract(LoanStateContract::class)
data class LoanState(val loanId: String,
                     val owningInvestor: AbstractParty,
                     val msrOwner: AbstractParty,
                     val servicer: AbstractParty,
                     override val linearId: UniqueIdentifier = UniqueIdentifier(loanId),
                     override val participants: List<AbstractParty> = listOf(owningInvestor, servicer)) : LinearState, QueryableState {
    constructor(loanId: String, owningInvestor: AbstractParty, msrOwner: AbstractParty, servicer: AbstractParty)
            : this(loanId, owningInvestor, msrOwner, servicer, UniqueIdentifier(loanId))

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is LoanStateSchemaV1 -> LoanStateSchemaV1.PersistentLoanState(
                    loanId = this.loanId,
                    owningInvestor = this.owningInvestor,
                    msrOwner = this.msrOwner,
                    servicer = this.servicer,
                    linearId = this.linearId.toString(),
                    participants = this.participants.toMutableSet()
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(LoanStateSchemaV1)
}