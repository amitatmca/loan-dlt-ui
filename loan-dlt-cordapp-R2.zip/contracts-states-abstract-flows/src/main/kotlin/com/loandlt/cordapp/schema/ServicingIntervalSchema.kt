package com.loandlt.cordapp.schema

import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.crypto.NullKeys
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import java.math.BigDecimal
import java.time.Instant
import javax.persistence.*

/**
 * The family of schemas for [ServicingInterval].
 */
object ServicingIntervalSchema

/**
 * First version of an [ServicingIntervalSchema] schema.
 */
object ServicingIntervalSchemaV1 : MappedSchema(schemaFamily = ServicingIntervalSchema.javaClass,
        version = 1, mappedTypes = listOf(PersistentServicingInterval::class.java)) {
    @Entity
    @Table(name = "servicing_interval", indexes = arrayOf(
            Index(name = "servicing_interval_linearId_idx", columnList = "linear_id"),
            Index(name = "servicing_interval_servicingIntervalId_idx", columnList = "servicing_interval_id"),
            Index(name = "servicing_interval_status_idx", columnList = "status")
    ))
    class PersistentServicingInterval(
            @Column(name = "servicing_interval_id")
            val servicingIntervalId: String,

            @Column(name = "start_date")
            val startDate: Instant,

            @Column(name = "cutoff_date")
            val cutOffDate: Instant?,

            @Column(name = "calculated_payout")
            val calculatedPayout: BigDecimal,

            @Column(name = "batch_id")
            val batchId: String? = null,

            @Column(name = "owning_investor")
            val owningInvestor: AbstractParty,

            @Column(name = "servicer")
            val servicer: AbstractParty,

            @Column(name = "status")
            val status: String,

            @Column(name = "linear_id")
            val linearId: String,

            @ElementCollection
            @Column(name = "participants")
            @CollectionTable(name = "servicing_interval_participants", joinColumns = arrayOf(
                    JoinColumn(name = "output_index", referencedColumnName = "output_index"),
                    JoinColumn(name = "transaction_id", referencedColumnName = "transaction_id")))
            var participants: MutableSet<AbstractParty>? = null

    ) : PersistentState() {
        //Default ctor for hibernate.
        constructor() : this("", Instant.now(), Instant.now(), BigDecimal.ZERO, null, NullKeys.NULL_PARTY, NullKeys.NULL_PARTY, "", "", null)
    }
}