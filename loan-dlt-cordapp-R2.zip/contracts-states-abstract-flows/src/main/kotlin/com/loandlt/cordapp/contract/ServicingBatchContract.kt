package com.loandlt.cordapp.contract

import com.loandlt.cordapp.contract.ContractUtil.Companion.INVALID_BATCH_STATUS
import com.loandlt.cordapp.state.ServicingBatch
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction
import java.math.BigDecimal
import java.security.PublicKey

class ServicingBatchContract : Contract {

    companion object {
        @JvmStatic
        val ID = ServicingBatchContract::class.java.name!!
    }

    interface Commands : CommandData {
        class CreateBatch : TypeOnlyCommandData(), Commands
        class CloseBatch : TypeOnlyCommandData(), Commands
        class SettleBatch : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) {
        tx.timeWindow?.midpoint ?: throw IllegalArgumentException("Transaction must be timestamped.")
        val command = tx.commands.requireSingleCommand<Commands>()
        val signers = command.signers.toSet()

        when (command.value) {
            is Commands.CreateBatch -> verifyCreateBatch(tx, signers)
            is Commands.CloseBatch -> verifyCloseBatch(tx, signers)
            is Commands.SettleBatch -> verifySettleBatch(tx, signers)
            else -> throw IllegalArgumentException("Unrecognised command.")
        }
    }

    private fun verifySettleBatch(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        "Must consume at least one input state of servicing interval." using (
                tx.inputsOfType<ServicingInterval>().isNotEmpty())

        val servicingIntervals = tx.inputsOfType<ServicingInterval>()

        ContractUtil.verifyTxComponents(tx = tx,
                inputs = servicingIntervals.size + 1,
                outputs = 1,
                inputStateTypeAndCount = ServicingBatch::class.java to 1,
                outputStateTypeAndCount = ServicingBatch::class.java to 1)


        val inBatch = tx.inputsOfType<ServicingBatch>().single()
        val outBatch = tx.outputsOfType<ServicingBatch>().single()
        val tempState = outBatch.copy(status = inBatch.status)

        "The batch output state contains invalid updates." using (tempState == inBatch)
        INVALID_BATCH_STATUS using (outBatch.isSettled())

        val isServicingIntervalsAreValid = servicingIntervals.all { it.isClosed() && it.batchId == inBatch.linearId }
        "One or more servicing interval has invalid batch Id or status field value." using (isServicingIntervalsAreValid)

        val expectedPayout = servicingIntervals.fold(BigDecimal.ZERO) { sum, state -> sum + state.calculatedPayout }
        "Invalid servicing intervals inputs states." using (outBatch.calculatedPayout == expectedPayout)

        "The owning investor party should sign the transaction." using (signers.contains(outBatch.owningInvestor.owningKey))
    }

    private fun verifyCloseBatch(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        ContractUtil.verifyTxComponents(tx = tx,
                inputs = 1,
                outputs = 1,
                inputStateTypeAndCount = ServicingBatch::class.java to 1,
                outputStateTypeAndCount = ServicingBatch::class.java to 1)

        "Must have at least one reference input servicing interval state." using (
                tx.referenceInputRefsOfType<ServicingInterval>().isNotEmpty())
        "Must not product output states for servicing interval." using (
                tx.outputsOfType<ServicingInterval>().isEmpty())

        val inBatch = tx.inputsOfType<ServicingBatch>().single()
        val outBatch = tx.outputsOfType<ServicingBatch>().single()
        val tempState = outBatch.copy(
                calculatedPayout = inBatch.calculatedPayout,
                wireXferDate = inBatch.wireXferDate,
                wireId = inBatch.wireId,
                status = inBatch.status
        )

        "The batch output state contains invalid updates." using (tempState == inBatch)
        "Invalid wire Id." using (outBatch.wireId.trim().isNotBlank() || outBatch.wireId.trim().isNotEmpty())

        // TODO Need to caution about the wireXferDate, it should not be so far past. Need to check with business. We can use tx.timeWindow to ensure date is valid.
        "Invalid wire transfer date." using (outBatch.wireXferDate != null)

        INVALID_BATCH_STATUS using (outBatch.isClosed())

        val servicingIntervals = tx.referenceInputRefsOfType<ServicingInterval>()

        val isServicingIntervalsAreValid = servicingIntervals.all { it.state.data.isClosed() && it.state.data.batchId == inBatch.linearId }
        "One or more servicing interval had invalid batch Id or status." using (isServicingIntervalsAreValid)

        val expectedPayout = servicingIntervals.fold(BigDecimal.ZERO) { sum, state -> sum + state.state.data.calculatedPayout }
        "Invalid batch calculated payout amount." using (outBatch.calculatedPayout == expectedPayout)

        "The servicer should sign the transaction." using (signers.contains(outBatch.servicer.owningKey))
    }


    private fun verifyCreateBatch(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        ContractUtil.verifyTxComponents(tx = tx,
                outputStateTypeAndCount = ServicingBatch::class.java to 1)
        val output = tx.outputsOfType<ServicingBatch>().single()

        "Invalid servicing batch Id." using (output.servicingBatchId.trim().isNotEmpty())
        "Invalid start date, must be before cutoff date." using (output.startDate < output.cutOffDate)
        "Wire Id must not be given while creating new batch." using (output.wireId.trim().isEmpty())
        "Wire transfer date must not be given while creating new batch." using (output.wireXferDate == null)
        INVALID_BATCH_STATUS using (output.isOpen())
        "Invalid calculated payout amount." using (output.calculatedPayout == BigDecimal.ZERO)

        "Invalid participants list." using (output.participants.containsAll(listOf(output.owningInvestor, output.servicer)))
        "Invalid external Id of LinearId." using (output.linearId.externalId != null
                && output.linearId.externalId == output.servicingBatchId)

        "The servicer should sign the transaction." using (signers.contains(output.servicer.owningKey))
    }
}