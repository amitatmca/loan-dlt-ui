package com.loandlt.cordapp.schema

import com.loandlt.cordapp.state.ServicingBatch
import net.corda.core.crypto.NullKeys
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import java.math.BigDecimal
import java.time.Instant
import javax.persistence.*

/**
 * The family of schemas for [ServicingBatch].
 */
object ServicingBatchSchema

/**
 * First version of an [ServicingBatchSchema] schema.
 */
object ServicingBatchSchemaV1 : MappedSchema(schemaFamily = ServicingBatchSchema.javaClass,
        version = 1, mappedTypes = listOf(PersistentServicingBatch::class.java)) {
    @Entity
    @Table(name = "servicing_batch", indexes = arrayOf(
            Index(name = "servicing_batch_linear_id_idx", columnList = "linear_id"),
            Index(name = "servicing_batch_servicing_batch_id", columnList = "servicing_batch_id"),
            Index(name = "servicing_batch_status_idx", columnList = "status")
    ))
    class PersistentServicingBatch(
            @Column(name = "owning_investor")
            val owningInvestor: AbstractParty,

            @Column(name = "servicer")
            val servicer: AbstractParty,

            @Column(name = "servicing_batch_id")
            val servicingBatchId: String,

            @Column(name = "start_date")
            val startDate: Instant,

            @Column(name = "cutoff_date")
            val cutOffDate: Instant,

            @Column(name = "wire_id")
            val wireId: String = "",

            @Column(name = "wire_xfer_date")
            val wireXferDate: Instant? = null,

            @Column(name = "calculated_payout")
            val calculatedPayout: BigDecimal,

            @Column(name = "status")
            val status: String,

            @Column(name = "linear_id")
            val linearId: String,

            @ElementCollection
            @Column(name = "participants")
            @CollectionTable(name = "servicing_batch_participants", joinColumns = arrayOf(
                    JoinColumn(name = "output_index", referencedColumnName = "output_index"),
                    JoinColumn(name = "transaction_id", referencedColumnName = "transaction_id")))
            var participants: MutableSet<AbstractParty>? = null
    ) : PersistentState() {
        //Default ctor for hibernate.
        constructor() : this(NullKeys.NULL_PARTY, NullKeys.NULL_PARTY, "", Instant.now(), Instant.now(), "", null,
                BigDecimal.ZERO, "", "", null)
    }
}