package com.loandlt.cordapp.test

import com.loandlt.cordapp.commons.flows.TxNoteAcceptorFlow
import com.loandlt.cordapp.flows.FlowHelper
import com.loandlt.cordapp.investor.flows.*
import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.schema.LoanSnapshotSchemaV1
import com.loandlt.cordapp.schema.LoanStateSchemaV1
import com.loandlt.cordapp.servicer.flows.*
import com.loandlt.cordapp.servicer.model.*
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.LoanState
import net.corda.core.contracts.ContractState
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.CordaX500Name
import net.corda.core.identity.Party
import net.corda.core.schemas.PersistentState
import net.corda.core.utilities.getOrThrow
import net.corda.testing.common.internal.testNetworkParameters
import net.corda.testing.internal.chooseIdentity
import net.corda.testing.node.*
import org.junit.After
import org.junit.Before
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Duration
import java.time.Instant
import kotlin.reflect.KProperty1

/**
 * A base class to reduce the boilerplate when writing obligation flow tests.
 */
abstract class AbstractFlowUnitTests : FlowHelper {
    lateinit var network: MockNetwork
    lateinit var investorNode1: StartedMockNode
    lateinit var investorNode2: StartedMockNode
    lateinit var servicerNode1: StartedMockNode
    lateinit var servicerNode2: StartedMockNode
    lateinit var notary: Party
    lateinit var investor1: Party
    lateinit var investor2: Party
    lateinit var servicer1: Party
    lateinit var servicer2: Party

    @Before
    fun setup() {
        val corDappsForAllNodes = listOf("com.loandlt.cordapp.contract", "com.loandlt.cordapp.exception", "com.loandlt.cordapp.flows",
                "com.loandlt.cordapp.plugin", "com.loandlt.cordapp.schema", "com.loandlt.cordapp.state", "net.corda.finance")

        network = MockNetwork(threadPerNode = true,
                notarySpecs = listOf(MockNetworkNotarySpec(name = CordaX500Name.parse("O=Notary,L=London,C=GB"), validating = false)),
                cordappPackages = corDappsForAllNodes,
                networkParameters = testNetworkParameters(minimumPlatformVersion = 4)
        )
        investorNode1 = network.createNode(parameters = MockNodeParameters(legalName = CordaX500Name("Investor1", "NYC", "US"),
                additionalCordapps = listOf(TestCordapp.findCordapp("com.loandlt.cordapp.investor")))
        )
        servicerNode1 = network.createNode(parameters = MockNodeParameters(legalName = CordaX500Name("Servicer1", "NJ", "US"),
                additionalCordapps = listOf(TestCordapp.findCordapp("com.loandlt.cordapp.servicer")))
        )
        investorNode2 = network.createNode(parameters = MockNodeParameters(legalName = CordaX500Name("Investor2", "NYC", "US"),
                additionalCordapps = listOf(TestCordapp.findCordapp("com.loandlt.cordapp.investor")))
        )
        servicerNode2 = network.createNode(parameters = MockNodeParameters(legalName = CordaX500Name("Servicer2", "NYC", "US"),
                additionalCordapps = listOf(TestCordapp.findCordapp("com.loandlt.cordapp.servicer")))
        )
        notary = network.defaultNotaryIdentity
        investor1 = investorNode1.info.chooseIdentity()
        servicer1 = servicerNode1.info.chooseIdentity()
        investor2 = investorNode2.info.chooseIdentity()
        servicer2 = servicerNode2.info.chooseIdentity()

        listOf(TxNoteAcceptorFlow::class.java,
                ServicerConfirmationFlowResponder::class.java,
                AddActionFlowResponder::class.java,
                RemovePrevActionFlowResponder::class.java,
                CloseServicingIntervalFlowResponder::class.java,
                ServicerConfirmationWithExistingServicingIntervalFlowResponder::class.java
        ).forEach {
            investorNode1.registerInitiatedFlow(it)
            investorNode2.registerInitiatedFlow(it)
        }

        listOf(TxNoteAcceptorFlow::class.java,
                LoanOnboardingResponder::class.java
        ).forEach {
            servicerNode1.registerInitiatedFlow(it)
            servicerNode2.registerInitiatedFlow(it)
        }
    }

    @After
    open fun tearDown() {
        network.stopNodes()
    }

    fun loanOnboarding(loan: Loan, investorNode: StartedMockNode) {
        investorNode.startFlow(LoanOnboardingFlow(loan)).getOrThrow()
    }

    fun confirmLoanSnapshot(servicerConfirmDto: ServicerConfirmDto, servicerNode: StartedMockNode) {
        servicerNode.startFlow(ServicerConfirmationFlow(servicerConfirmDto)).getOrThrow()
    }

    fun confirmLoanSnapshotWithExistingServicingInterval(servicingIntervalDtoDataServicer: ServicerConfirmWithExistingServicingIntervalDto, servicerNode: StartedMockNode) {
        servicerNode.startFlow(ServicerConfirmationWithExistingServicingIntervalFlow(servicingIntervalDtoDataServicer)).getOrThrow()
    }

    fun addAction(actionData: ActionData, servicerNode: StartedMockNode) {
        servicerNode.startFlow(AddActionFlow(actionData)).getOrThrow()
    }

    fun removeAction(linearIdOfHead: String, servicerNode: StartedMockNode) {
        servicerNode.startFlow(RemovePrevActionFlow(linearIdOfHead)).getOrThrow()
    }

    fun closeServicingInterval(servicingIntervalLinearId: String,
                               servicingBatchLinearId: String,
                               servicerNode: StartedMockNode) {
        val flow = CloseServicingIntervalFlow(servicingIntervalLinearId, servicingBatchLinearId)
        servicerNode.startFlow(flow).getOrThrow()
    }

    fun closeServicingInterval(servicingIntervalLinearId: String,
                               servicingBatchData: BatchData, servicerNode: StartedMockNode) {
        val flow = CloseServicingIntervalFlow(servicingIntervalLinearId, servicingBatchData)
        servicerNode.startFlow(flow).getOrThrow()
    }

    fun closeServicingIntervalUsingExistingBatch(
            servicingIntervalLinearId: String,
            servicingBatchLinearId: String,
            servicerNode: StartedMockNode) {
        val flow = CloseServicingIntervalFlow(servicingIntervalLinearId, servicingBatchLinearId)
        servicerNode.startFlow(flow).getOrThrow()
    }

    fun closeServicingBatch(closeBatchDto: CloseBatchDto, servicerNode: StartedMockNode) {
        val flow = CloseServicingBatchFlow(closeBatchDto)
        servicerNode.startFlow(flow).getOrThrow()
    }

    fun confirmPayment(batchLinearId: String, investorNode: StartedMockNode) {
        val flow = ConfirmPaymentFlow(batchLinearId)
        investorNode.startFlow(flow).getOrThrow()
    }

    //region Helper functions to create contract states for a business case.
    private fun getActionDataInstance(prevLoanSnapshot: LoanSnapshot, actionAmount: BigDecimal, actionType: ActionType): ActionData {
        return ActionData(prevLoanSnapshot.loanId.toString(),
                actionType,
                actionAmount,
                Instant.now(),
                prevLoanSnapshot.unpaidPrincipalBalance - actionAmount,
                Instant.now())
    }

    protected fun pni(prevLoanSnapshot: LoanSnapshot, actionAmount: BigDecimal): ActionData {
        return getActionDataInstance(prevLoanSnapshot, actionAmount, ActionType.PNI)

    }

    protected fun curtailment(prevLoanSnapshot: LoanSnapshot, actionAmount: BigDecimal): ActionData {
        return getActionDataInstance(prevLoanSnapshot, actionAmount, ActionType.CURTAILMENT)

    }

    protected fun corpAdv(prevLoanSnapshot: LoanSnapshot, actionAmount: BigDecimal): ActionData {
        return getActionDataInstance(prevLoanSnapshot, actionAmount, ActionType.CORP_ADV)
    }

    protected fun escrowAdv(prevLoanSnapshot: LoanSnapshot, actionAmount: BigDecimal): ActionData {
        return getActionDataInstance(prevLoanSnapshot, actionAmount, ActionType.ESCROW_ADV)
    }

    protected fun loanOnboarding(investorNode: StartedMockNode, servicerNode: StartedMockNode): LoanState {
        val investorParty = investorNode.info.chooseIdentity()
        val servicerParty = servicerNode.info.chooseIdentity()

        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("1000000")

        val loan = Loan("LOAN${Instant.now().toEpochMilli()}",
                loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investorParty.toString(), servicerParty.toString())

        // Loan on-boarding.
        loanOnboarding(loan, investorNode)

        // Verify vault state.
        val loanStates1 = investorNode.getStateByFieldValue(
                LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan.loanId
        )
        assert(loanStates1.size == 1)

        val loanStates2 = servicerNode.getStateByFieldValue(
                LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan.loanId
        )
        assert(loanStates2.size == 1)

        return loanStates1.first()
    }

    protected fun <T : ContractState> StartedMockNode.get(clazz: Class<T>): T {
        return this.transaction {
            val loanStates = this.services.vaultService.queryBy(clazz).states
            assert(loanStates.size == 1)
            loanStates.single().state.data
        }
    }

    protected fun <T : ContractState> StartedMockNode.getStates(clazz: Class<T>): List<T> {
        return this.transaction {
            this.services.vaultService.queryBy(clazz).states.map { it.state.data }
        }
    }

    protected fun <T : ContractState, P : PersistentState> StartedMockNode.getStateByFieldValue(
            clazz: Class<T>,
            field: KProperty1<P, Any?>,
            criteriaValue: Any): List<T> {
        return this.services.getStateByFieldValue(clazz, field, criteriaValue).map { it.state.data }
    }

    protected fun StartedMockNode.getSnapshotByLoanId(loanLinearId: UniqueIdentifier): List<LoanSnapshot> {
        return this.getStateByFieldValue(
                LoanSnapshot::class.java,
                LoanSnapshotSchemaV1.PersistentLoanSnapshot::loanId,
                loanLinearId.toString())
    }

    protected fun StartedMockNode.getSnapshotByIntervalId(servicingIntervalLinearId: UniqueIdentifier): List<LoanSnapshot> {
        return this.getStateByFieldValue(
                LoanSnapshot::class.java,
                LoanSnapshotSchemaV1.PersistentLoanSnapshot::servicingIntervalId,
                servicingIntervalLinearId.toString())
    }

    protected fun <T : ContractState> StartedMockNode.getSingleStateByLinearId(
            clazz: Class<T>,
            linearId: UniqueIdentifier): StateAndRef<T> {
        return this.services.getSingleStateByLinearId(linearId, clazz)
    }

    protected fun <T : ContractState> StartedMockNode.getStatesByLinearId(
            clazz: Class<T>,
            linearId: UniqueIdentifier): List<StateAndRef<T>> {
        return this.services.getStatesByLinearId(linearId, clazz)
    }
    //endregion
}
