# CorDapp Application  
  
## Built With  
For building and running the application you need:  
  
- JDK 1.8 update 171  
- Gradle 4.10.3  
- Corda release version 4.0  

## Running the application  
In the 'loan-dlt-cordapp' directory, open console and build the app by running following commands.

- For building the CorDapp:
### `gradlew clean build`

- For building by skipping unit or integration test cases:
### `gradlew clean build -x test`  
  
- For deploy corda nodes:
### `gradlew deploynodes`
  
Your app is ready to run!  
  
You can run the all nodes go to the `loan-dlt-cordapp/build/nodes` and run the `runnodes.bat` or `runnodes.sh` file dependen on your machine's OS.
