package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.hash
import net.corda.testing.node.StartedMockNode
import org.junit.Test
import java.math.BigDecimal
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class RemovePrevActionFlowTests : AbstractFlowUnitTests() {

    private fun verifyLedger(servicer: StartedMockNode, investor: StartedMockNode, prevSnapshot: LoanSnapshot) {
        listOf(servicer, investor).forEach { node ->
            val head = node.get(LoanSnapshot::class.java)
            assertNotNull(head.prevSnapshotId)
            assertEquals(head.actionType, ActionType.REMOVE_PREV_ACTION)
            assertEquals(head.actionAmount, BigDecimal.ZERO)

            val tempPrevSnapshot = head.copy(
                    linearId = prevSnapshot.linearId,
                    actionType = prevSnapshot.actionType,
                    actionDate = prevSnapshot.actionDate,
                    actionAmount = prevSnapshot.actionAmount)
            assertEquals(tempPrevSnapshot.hash(), prevSnapshot.hash())
        }
    }

    @Test
    fun `remove pni payment action`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData = pni(snapshot1, BigDecimal(10000))
        addAction(actionData, servicerNode1)
        network.waitQuiescent()


        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()

        verifyLedger(servicerNode1, investorNode1, snapshot2)
    }

    @Test
    fun `remove corp adv payment action`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData = pni(snapshot1, BigDecimal(10000))
        addAction(actionData, servicerNode1)
        network.waitQuiescent()


        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot4 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                corpAdv(snapshot4, BigDecimal(5000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot5 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot5.linearId.toString(), servicerNode1)
        network.waitQuiescent()

        verifyLedger(servicerNode1, investorNode1, snapshot4)
    }

    @Test
    fun `remove curtailment then add and remove curtailment payment action`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)

        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        addAction(
                pni(snapshot2, BigDecimal(10000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        addAction(
                pni(snapshot3, BigDecimal(10000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot4 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                corpAdv(snapshot4, BigDecimal(5000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot5 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                corpAdv(snapshot5, BigDecimal(5000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot6 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                curtailment(snapshot6, BigDecimal(20000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot7 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot7.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        // Verify the ledger after removal of prev action.
        verifyLedger(servicerNode1, investorNode1, snapshot6)

        //Get last unconsumed loan snapshot.
        val rollbackTo6 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                pni(rollbackTo6, BigDecimal(15000)),
                servicerNode1
        )
        network.waitQuiescent()

        val snapshot8 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                pni(snapshot8, BigDecimal(12000)),
                servicerNode1
        )
        network.waitQuiescent()

        val snapshot9 = servicerNode1.get(LoanSnapshot::class.java)
        addAction(
                curtailment(snapshot9, BigDecimal(12000)),
                servicerNode1
        )
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot10 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot10.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        // Verify the ledger after removal of prev action.
        verifyLedger(servicerNode1, investorNode1, snapshot9)

        val rollbackTo9 = servicerNode1.get(LoanSnapshot::class.java)
        // Check the linked list of all valid loan snapshots.
        // snapshot2 <- snapshot3 <- snapshot4 <- snapshot5 <- rollbackTo6(copy of snapshot6) <- snapshot8 <- rollbackTo9(copy of snapshot9)

        assert(rollbackTo9.prevSnapshotId == snapshot9.prevSnapshotId)
        assert(rollbackTo9.prevSnapshotHash == snapshot9.prevSnapshotHash)

        assert(rollbackTo9.prevSnapshotId == snapshot8.linearId)
        assert(rollbackTo9.prevSnapshotHash == snapshot8.hash())

        assert(snapshot8.prevSnapshotId == rollbackTo6.linearId)
        assert(snapshot8.prevSnapshotHash == rollbackTo6.hash())

        assert(rollbackTo6.prevSnapshotId == snapshot6.prevSnapshotId)
        assert(rollbackTo6.prevSnapshotHash == snapshot6.prevSnapshotHash)

        assert(rollbackTo6.prevSnapshotId == snapshot5.linearId)
        assert(rollbackTo6.prevSnapshotHash == snapshot5.hash())

        assert(snapshot5.prevSnapshotId == snapshot4.linearId)
        assert(snapshot5.prevSnapshotHash == snapshot4.hash())

        assert(snapshot4.prevSnapshotId == snapshot3.linearId)
        assert(snapshot4.prevSnapshotHash == snapshot3.hash())

        assert(snapshot3.prevSnapshotId == snapshot2.linearId)
        assert(snapshot3.prevSnapshotHash == snapshot2.hash())

        assert(snapshot2.prevSnapshotId == snapshot1.linearId)
        assert(snapshot2.prevSnapshotHash == snapshot1.hash())

        assertNull(snapshot1.prevSnapshotId)
        assertNull(snapshot1.prevSnapshotHash)
    }
}