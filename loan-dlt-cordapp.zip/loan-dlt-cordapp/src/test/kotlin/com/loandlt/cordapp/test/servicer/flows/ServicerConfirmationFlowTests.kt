package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.ServicingInterval
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import org.junit.Test
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertNotNull

class ServicerConfirmationFlowTests : AbstractFlowUnitTests() {

    @Test
    fun `confirming loan snapshot and issuance of servicing interval`() {
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        val prevLoanSnapshot = servicerNode1.get(LoanSnapshot::class.java)

        val servicingIntervalDto = ServicerConfirmDto("Sep2019", loanState.linearId.toString(), Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)

        listOf(servicerNode1, investorNode1).forEach { node ->
            val loanSnapshot = node.get(LoanSnapshot::class.java)
            val servicingInterval = node.get(ServicingInterval::class.java)
            assert(loanSnapshot.loanId == loanState.linearId)
            assertNotNull(loanSnapshot.prevSnapshotId)
            assert(loanSnapshot.prevSnapshotId == prevLoanSnapshot.linearId)
            assert(servicingInterval.isOpen())
            assert(servicingInterval.loanId == loanState.linearId)
            assert(servicingInterval.servicingIntervalId == servicingIntervalDto.servicingIntervalId)
        }
    }
}