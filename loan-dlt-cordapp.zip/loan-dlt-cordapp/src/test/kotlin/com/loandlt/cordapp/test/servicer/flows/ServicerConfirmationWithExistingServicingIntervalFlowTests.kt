package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.servicer.model.ServicerConfirmWithExistingServicingIntervalDto
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.ServicingInterval
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.hash
import org.junit.Test
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class ServicerConfirmationWithExistingServicingIntervalFlowTests : AbstractFlowUnitTests() {

    @Test
    fun `confirming loan snapshot and issuance of servicing interval`() {
        //region ############# First loan onboarding. #############
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        val prevLoanSnapshot = servicerNode1.get(LoanSnapshot::class.java)

        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS)
        )
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        listOf(servicerNode1, investorNode1).forEach { node ->
            val loanSnapshot = node.get(LoanSnapshot::class.java)
            val servicingInterval = node.get(ServicingInterval::class.java)
            assert(loanSnapshot.loanId == loanState.linearId)
            assertNotNull(loanSnapshot.prevSnapshotId)
            assert(loanSnapshot.prevSnapshotId == prevLoanSnapshot.linearId)
            assert(servicingInterval.isOpen())
            assert(servicingInterval.loanId == loanState.linearId)
            assert(servicingInterval.servicingIntervalId == servicingIntervalDto.servicingIntervalId)
        }
        //endregion

        //region ############# Second loan onboarding. #############
        val loanState2 = loanOnboarding(investorNode1, servicerNode1)
        val prevLoanSnapshot2 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()

        // Confirm servicing interval.
        val servicingInterval = servicerNode1.get(ServicingInterval::class.java)
        val servicingData2 = ServicerConfirmWithExistingServicingIntervalDto(
                servicingInterval.linearId.toString(),
                loanState2.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS)
        )

        confirmLoanSnapshotWithExistingServicingInterval(servicingData2, servicerNode1)
        network.waitQuiescent()

        // ############# Verify state of vault. #############
        listOf(servicerNode1, investorNode1).forEach { node ->
            node.transaction {
                assertEquals(1,
                        node.getStates(ServicingInterval::class.java).size,
                        "Must have single servicing interval contract state on ledger")

                val loanSnapshots = node.getStates(LoanSnapshot::class.java)
                assert(loanSnapshots.size == 2)

                // Retrieve loan snapshot for second loan.
                val loanSnapshot2 = loanSnapshots.firstOrNull { it.loanId == loanState2.linearId }
                assertNotNull(loanSnapshot2)
                assertNotNull(loanSnapshot2!!.prevSnapshotId)
                assertEquals(loanSnapshot2.prevSnapshotId, prevLoanSnapshot2.linearId)
                assertEquals(loanSnapshot2.prevSnapshotHash, prevLoanSnapshot2.hash())
                assertEquals(loanSnapshot2.actionType, ActionType.SERVICER_CONFIRM)

                // Check loanIds.
                assert(loanSnapshots.asSequence()
                        .map { it.loanId }.toSet()
                        .containsAll(setOf(loanState.linearId, loanState2.linearId))
                )

                // Check servicing interval reference.
                val servicingIntervals = loanSnapshots.asSequence()
                        .map { it.servicingIntervalId }
                        .toSet()
                assert(servicingIntervals.size == 1)

                val interval = node.get(ServicingInterval::class.java)
                assert(servicingIntervals.single() == interval.linearId)
                assert(interval.isOpen())
            }
        }
        //endregion
    }
}