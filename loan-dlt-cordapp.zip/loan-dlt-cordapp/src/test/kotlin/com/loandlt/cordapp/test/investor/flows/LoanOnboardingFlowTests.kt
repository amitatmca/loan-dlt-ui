package com.loandlt.cordapp.test.investor.flows

import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.state.LoanState
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import org.junit.Test
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Duration
import java.time.Instant

class LoanOnboardingFlowTests : AbstractFlowUnitTests() {

    @Test
    fun `on-boarding a loan`() {
        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("100000")
        val loan = Loan("L123", loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investor1.toString(), servicer1.toString())

        loanOnboarding(loan, investorNode1)

        investorNode1.transaction {
            val loanStates = investorNode1.services.vaultService.queryBy(LoanState::class.java).states
            assert(loanStates.size == 1)
            assert(loanStates.first().state.data.loanId == loan.loanId)
        }

        servicerNode1.transaction {
            val loanStates = servicerNode1.services.vaultService.queryBy(LoanState::class.java).states
            assert(loanStates.size == 1)
            assert(loanStates.first().state.data.loanId == loan.loanId)
        }
    }

    fun `loan on-boarding tx format check`() {
        //TODO Add logic to verify expected transaction format.
    }
}