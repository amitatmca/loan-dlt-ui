package com.loandlt.cordapp.test.servicer.flows

import com.loandlt.cordapp.investor.model.Loan
import com.loandlt.cordapp.schema.LoanStateSchemaV1
import com.loandlt.cordapp.servicer.model.BatchData
import com.loandlt.cordapp.servicer.model.ServicerConfirmDto
import com.loandlt.cordapp.servicer.model.ServicerConfirmWithExistingServicingIntervalDto
import com.loandlt.cordapp.state.*
import com.loandlt.cordapp.test.AbstractFlowUnitTests
import net.corda.core.contracts.hash
import net.corda.core.internal.sum
import net.corda.testing.node.StartedMockNode
import org.junit.Test
import java.math.BigDecimal
import java.math.BigInteger
import java.time.Duration
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class CloseServicingIntervalFlowTests : AbstractFlowUnitTests() {

    private fun verifyLedger(servicer: StartedMockNode, investor: StartedMockNode, prevSnapshot: LoanSnapshot) {
        listOf(servicer, investor).forEach { node ->
            val head = node.getSnapshotByLoanId(prevSnapshot.loanId).single()
            assertNotNull(head.prevSnapshotId)
            assertEquals(head.actionType, ActionType.REMOVE_PREV_ACTION)
            assertEquals(head.actionAmount, BigDecimal.ZERO)

            val tempPrevSnapshot = head.copy(
                    linearId = prevSnapshot.linearId,
                    actionType = prevSnapshot.actionType,
                    actionDate = prevSnapshot.actionDate,
                    actionAmount = prevSnapshot.actionAmount)
            assertEquals(tempPrevSnapshot.hash(), prevSnapshot.hash())
        }
    }

    @Test
    fun `close servicing interval`() {
        //Loan on-boarding.
        val loanState = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val servicingIntervalDto = ServicerConfirmDto(
                "Sep2019",
                loanState.linearId.toString(),
                Instant.now().plus(1, ChronoUnit.DAYS))
        confirmLoanSnapshot(servicingIntervalDto, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData = pni(snapshot1, BigDecimal(10000))
        addAction(actionData, servicerNode1)
        network.waitQuiescent()


        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, snapshot2)

        // Close servicing interval.
        val loanSnapshotBeforeCloseInterval = servicerNode1.get(LoanSnapshot::class.java)
        val servIntervalId = servicerNode1.get(ServicingInterval::class.java).linearId.toString()
        val batchData = BatchData(investor1.toString(),
                "Batch001",
                servicingIntervalDto.startDate,
                Instant.now().plus(30L, ChronoUnit.DAYS))
        closeServicingInterval(servIntervalId, batchData, servicerNode1)
        network.waitQuiescent()

        listOf(investorNode1, servicerNode1).forEach {
            val loanSnapshot = it.get(LoanSnapshot::class.java)
            val interval = it.get(ServicingInterval::class.java)
            val batch = it.get(ServicingBatch::class.java)
            assert(loanSnapshot.prevSnapshotId == loanSnapshotBeforeCloseInterval.linearId)
            assert(loanSnapshot.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
            assert(loanSnapshot.actionAmount == BigDecimal.ZERO)
            assert(interval.calculatedPayout == loanSnapshotBeforeCloseInterval.servicingIntervalPayout)
            assert(interval.batchId == batch.linearId)
            assert(interval.cutOffDate == batch.cutOffDate)
            assert(interval.isClosed())
        }
    }

    @Test
    fun `close servicing interval that referenced in two loans`() {
        //region ################# First loan servicing #################
        val loanState1 = loanOnboarding(investorNode1, servicerNode1)
        network.waitQuiescent()
        //Confirm servicing by servicer1.
        val confirmServicing = ServicerConfirmDto(
                "Sep2019",
                loanState1.linearId.toString(),
                Instant.now())
        confirmLoanSnapshot(confirmServicing, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot1 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData1 = pni(snapshot1, BigDecimal(10000))
        addAction(actionData1, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot2 = servicerNode1.get(LoanSnapshot::class.java)
        //Add PNI payment.
        val actionData2 = pni(snapshot2, BigDecimal(10000))
        addAction(actionData2, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot3 = servicerNode1.get(LoanSnapshot::class.java)
        // Remove pni payment action.
        removeAction(snapshot3.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, snapshot2)
        //endregion

        //region ################# Second loan servicing #################
        //Loan on-boarding.
        val dueDate = Instant.now().plus(Duration.ofDays(30))
        val loanAmount = BigDecimal("2000000")
        val loan2 = Loan("LOAN${Instant.now().toEpochMilli()}",
                loanAmount, dueDate, BigDecimal("4.5"), loanAmount, BigInteger.valueOf(12), "F",
                Instant.now(), BigInteger.ZERO, BigDecimal("0.5"), BigDecimal.ZERO, BigDecimal.ZERO,
                investor1.toString(), servicer1.toString())

        // Loan on-boarding.
        loanOnboarding(loan2, investorNode1)
        network.waitQuiescent()

        // Get states from vault
        val loanState2 = servicerNode1.getStateByAnyFieldValue(LoanState::class.java,
                LoanStateSchemaV1.PersistentLoanState::loanId,
                loan2.loanId).single()
        val servicingInterval = servicerNode1.get(ServicingInterval::class.java)

        // Confirm servicing by servicer1.
        val confirmServicingUseExistingInterval = ServicerConfirmWithExistingServicingIntervalDto(
                servicingInterval.linearId.toString(),
                loanState2.linearId.toString(),
                Instant.now())
        confirmLoanSnapshotWithExistingServicingInterval(confirmServicingUseExistingInterval, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot22 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData21 = pni(snapshot22, BigDecimal(20000))
        addAction(actionData21, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot23 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        //Add PNI payment.
        val actionData22 = pni(snapshot23, BigDecimal(20000))
        addAction(actionData22, servicerNode1)
        network.waitQuiescent()

        //Get last unconsumed loan snapshot.
        val snapshot24 = servicerNode1.getSnapshotByLoanId(loanState2.linearId).single()
        // Remove pni payment action.
        removeAction(snapshot24.linearId.toString(), servicerNode1)
        network.waitQuiescent()
        verifyLedger(servicerNode1, investorNode1, snapshot23)
        //endregion

        //region ################# Close servicing interval #################
        val prevLoanSnapshotsOfServicer = servicerNode1.getStates(LoanSnapshot::class.java)
        val prevLoanSnapshotsOfInvestor = investorNode1.getStates(LoanSnapshot::class.java)

        // Close servicing cycle.
        val batchData = BatchData(
                investor1.toString(),
                "Batch001",
                servicingInterval.startDate,
                Instant.now().plus(5L, ChronoUnit.DAYS))
        closeServicingInterval(servicingInterval.linearId.toString(), batchData, servicerNode1)
        network.waitQuiescent()

        verifyLedgerAfterClosingServicingInterval(servicerNode1, prevLoanSnapshotsOfServicer)
        verifyLedgerAfterClosingServicingInterval(investorNode1, prevLoanSnapshotsOfInvestor)
        //endregion
    }

    private fun verifyLedgerAfterClosingServicingInterval(node: StartedMockNode, prevSnapshots: List<LoanSnapshot>) {
        node.transaction {
            val loanSnapshots = node.getStates(LoanSnapshot::class.java)
            val interval = node.get(ServicingInterval::class.java)
            val batch = node.get(ServicingBatch::class.java)

            assert(loanSnapshots.size == prevSnapshots.size)
            assertNotNull(interval)
            assertNotNull(batch)

            loanSnapshots.forEach { loanSnapshot ->
                val prevSnapshot = prevSnapshots.firstOrNull { it.loanId == loanSnapshot.loanId }
                assertNotNull(prevSnapshot)
                assert(loanSnapshot.prevSnapshotId == prevSnapshot!!.linearId)
                assert(loanSnapshot.prevSnapshotHash == prevSnapshot.hash())
                assert(loanSnapshot.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
                assert(loanSnapshot.actionAmount == BigDecimal.ZERO)
            }
            val expectedIntervalPayout = prevSnapshots
                    .map { it.servicingIntervalPayout }
                    .sum()
            assert(interval.calculatedPayout == expectedIntervalPayout)
            assert(interval.batchId == batch.linearId)
            assert(interval.cutOffDate == batch.cutOffDate)
            assert(interval.isClosed())
        }
    }
}