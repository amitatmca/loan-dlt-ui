package com.loandlt.cordapp.servicer.model

import java.time.Instant

data class BatchData(val owningInvestor: String,
                     val servicingBatchId: String,
                     val startDate: Instant,
                     val cutOffDate: Instant)
