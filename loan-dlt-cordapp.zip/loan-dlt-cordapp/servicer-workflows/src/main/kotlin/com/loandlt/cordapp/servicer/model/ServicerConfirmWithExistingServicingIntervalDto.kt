package com.loandlt.cordapp.servicer.model

import com.loandlt.cordapp.state.LoanState
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.serialization.CordaSerializable
import java.time.Instant

@CordaSerializable
data class ServicerConfirmWithExistingServicingIntervalDto(
        /** The [ServicingInterval.linearId] value of existing/on-ledger contract state.*/
        val linearIdOfExistingServicingInterval: String,
        /** The [LoanState.linearId] value of on-leger contract state.*/
        val loanLinearId: String,
        val startDate: Instant
)