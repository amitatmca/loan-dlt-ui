package com.loandlt.cordapp.contract

import com.loandlt.cordapp.contract.ContractUtil.Companion.INVALID_ACTION_AMOUNT
import com.loandlt.cordapp.contract.ContractUtil.Companion.INVALID_ACTION_DATE
import com.loandlt.cordapp.contract.ContractUtil.Companion.INVALID_ACTION_TYPE
import com.loandlt.cordapp.contract.ContractUtil.Companion.INVALID_NOTE_RATE
import com.loandlt.cordapp.contract.ContractUtil.Companion.INVALID_SERV_PAYOUT_AMOUNT
import com.loandlt.cordapp.contract.ContractUtil.Companion.SERVICER_SIGN_ONLY
import com.loandlt.cordapp.state.ActionType
import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.LoanState
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.contracts.*
import net.corda.core.contracts.Requirements.using
import net.corda.core.transactions.LedgerTransaction
import java.math.BigDecimal
import java.security.PublicKey
import java.time.Instant
import java.time.ZoneOffset
import java.util.*

class ServicingContract : Contract {

    companion object {
        @JvmStatic
        val ID = ServicingContract::class.java.name!!
    }

    interface Commands : CommandData {
        class CreateLoanSnapshot : TypeOnlyCommandData(), Commands
        class ServicerConfirms : TypeOnlyCommandData(), Commands
        class ServicerConfirmsWithExistingInterval : TypeOnlyCommandData(), Commands
        class AddAction : TypeOnlyCommandData(), Commands
        /** This command additionally holds the action data of previous loan snapshot being rollback.
         * It required to validate data of original state and one created as output. */
        data class RemovePrevAction(val actionType: ActionType,
                                    val actionDate: Instant,
                                    val actionAmount: BigDecimal) : Commands

        class CloseServicingInterval : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) {
        val timeWindow = tx.timeWindow?.midpoint ?: throw IllegalArgumentException("Transaction must be timestamped.")
        val command = tx.commands.requireSingleCommand<Commands>()
        val signers = command.signers.toSet()

        when (command.value) {
            is Commands.CreateLoanSnapshot -> verifyCreateLoanSnapshot(tx, signers, timeWindow)
            is Commands.ServicerConfirms -> verifyServicerConfirms(tx, signers)
            is Commands.AddAction -> verifyAddAction(tx, signers, timeWindow)
            is Commands.RemovePrevAction -> {
                val prevSnapshotActionData = (command.value as Commands.RemovePrevAction)
                verifyRemovePrevAction(tx, prevSnapshotActionData, signers, timeWindow)
            }
            is Commands.CloseServicingInterval -> verifyClose(tx, timeWindow)
            is Commands.ServicerConfirmsWithExistingInterval -> verifyServicerConfirmsWithExistingInterval(tx, signers)
            else -> throw IllegalArgumentException("Unrecognised command.")
        }
    }

    private fun verifyServicerConfirmsWithExistingInterval(tx: LedgerTransaction, signers: Set<PublicKey>) {
        ContractUtil.verifyTxComponents(tx, 1, 1,
                listOf(LoanSnapshot::class.java to 1),
                listOf(LoanSnapshot::class.java to 1))
        val outLoanSnapshot = tx.outputsOfType<LoanSnapshot>().single()
        val inLoanSnapshot = tx.inputsOfType<LoanSnapshot>().single()

        "Missing reference contract state for ServicingInterval." using (tx.referenceInputRefsOfType<ServicingInterval>().isNotEmpty())
        "Must have reference of single ServicingInterval contract state." using (tx.referenceInputRefsOfType<ServicingInterval>().size == 1)

        val servicingInterval = tx.referenceInputRefsOfType<ServicingInterval>().single().state.data

        verifyPrevSnapshotReference(inLoanSnapshot, outLoanSnapshot)

        INVALID_NOTE_RATE using (outLoanSnapshot.noteRate > BigDecimal.ZERO)

        "Invalid servicer and owning investor identities in LoanSnapshot output state." using (
                inLoanSnapshot.servicer == outLoanSnapshot.servicer && inLoanSnapshot.owningInvestor == outLoanSnapshot.owningInvestor)

        "Both ServicingInterval and LoanSnapshot contract states must have same servicer and/or owning investor identities." using (
                servicingInterval.servicer == inLoanSnapshot.servicer && servicingInterval.owningInvestor == inLoanSnapshot.owningInvestor)

        "LoanSnapshot out state contains invalid servicing-interval Id." using (outLoanSnapshot.servicingIntervalId != null
                && outLoanSnapshot.servicingIntervalId == servicingInterval.linearId)

        "Invalid servicing interval status. It must be Open." using (servicingInterval.isOpen())
        INVALID_ACTION_TYPE using (outLoanSnapshot.actionType == ActionType.SERVICER_CONFIRM)
        INVALID_ACTION_AMOUNT using (outLoanSnapshot.actionAmount == BigDecimal.ZERO)
        INVALID_SERV_PAYOUT_AMOUNT using (outLoanSnapshot.servicingIntervalPayout == BigDecimal.ZERO)
        SERVICER_SIGN_ONLY using (signers.contains(outLoanSnapshot.servicer.owningKey))
    }


    private fun isLoanSnapshotInOutsValid(
            inOut: LedgerTransaction.InOutGroup<LoanSnapshot,
                    UniqueIdentifier>, timeWindow: Instant): Boolean {
        "Must have single input and output state of LoanSnapshot per linearId." using (inOut.inputs.size == 1 && inOut.outputs.size == 1)
        val input = inOut.inputs.single()
        val output = inOut.outputs.single()
        "Invalid action type." using (output.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
        INVALID_ACTION_AMOUNT using (output.actionAmount == BigDecimal.ZERO)
        INVALID_ACTION_DATE using (
                output.actionDate.atZone(ZoneOffset.UTC).toLocalDate() >= timeWindow.atZone(ZoneOffset.UTC).toLocalDate())
        val tempState = input.run {
            output.copy(linearId = linearId,
                    actionType = actionType,
                    actionAmount = actionAmount,
                    actionDate = actionDate,
                    prevSnapshotHash = prevSnapshotHash,
                    prevSnapshotId = prevSnapshotId)
        }
        return tempState == input
    }

    private fun LedgerTransaction.groupLoanSnapshotStates(): List<LedgerTransaction.InOutGroup<LoanSnapshot, UniqueIdentifier>> {
        val inputs = this.inputsOfType<LoanSnapshot>()
        val outputs = this.outputsOfType<LoanSnapshot>()

        val inGroups: Map<UniqueIdentifier, List<LoanSnapshot>> = inputs.groupBy(LoanSnapshot::linearId)
        val outGroups: Map<UniqueIdentifier?, List<LoanSnapshot>> = outputs.groupBy(LoanSnapshot::prevSnapshotId)

        val result = ArrayList<LedgerTransaction.InOutGroup<LoanSnapshot, UniqueIdentifier>>()

        for ((k, v) in inGroups.entries)
            result.add(LedgerTransaction.InOutGroup(v, outGroups[k] ?: emptyList(), k))
        for ((k, v) in outGroups.entries) {
            if (inGroups[k] == null)
                result.add(LedgerTransaction.InOutGroup(emptyList(), v, k!!))
        }

        return result
    }

    private fun verifyClose(tx: LedgerTransaction, timeWindow: Instant) {
        val loanSnapshotInOuts = tx.groupLoanSnapshotStates()
        "Must have at least one pair LoanSnapshot input and output state." using (loanSnapshotInOuts.isNotEmpty())
        val isLoanSnapshotInOutsValid = loanSnapshotInOuts.parallelStream().allMatch { it -> isLoanSnapshotInOutsValid(it, timeWindow) }
        "The LoanSnapshot output state contains invalid data." using (isLoanSnapshotInOutsValid)
        val owningInvestor = loanSnapshotInOuts.first().inputs.first().owningInvestor

        val inputs = loanSnapshotInOuts.flatMap { it.inputs }
        val isInputsActionTypeValid = inputs.all { it.actionType != ActionType.CLOSE_SERVICING_INTERVAL }
        val hasSingleInvestor = inputs.all { it.owningInvestor == owningInvestor }

        "The servicing interval was already closed for one or more loan snapshots." using (isInputsActionTypeValid)
        "The LoanSnapshot states must be of single owning investor." using (hasSingleInvestor)
    }

    private fun verifyRemovePrevAction(tx: LedgerTransaction,
                                       prevSnapshotActionData: Commands.RemovePrevAction,
                                       signers: Set<PublicKey>,
                                       timeWindow: Instant) = requireThat {
        ContractUtil.verifyTxComponents(tx, 1, 1, LoanSnapshot::class.java to 1, LoanSnapshot::class.java to 1)
        val inLoanSnapshot = tx.inputsOfType<LoanSnapshot>().single()
        val outLoanSnapshot = tx.outputsOfType<LoanSnapshot>().single()

        "Invalid loan snapshot input state." using (inLoanSnapshot.actionType !in listOf(ActionType.APPOINT, ActionType.SERVICER_CONFIRM))
        "Invalid previous snapshot Id/Hash referenced by input state." using (
                inLoanSnapshot.prevSnapshotId != null && inLoanSnapshot.prevSnapshotHash != null)
        "Invalid linearId field value of loan-snapshot output state." using (
                outLoanSnapshot.linearId != inLoanSnapshot.linearId && outLoanSnapshot.linearId != inLoanSnapshot.prevSnapshotId)
        INVALID_ACTION_TYPE using (outLoanSnapshot.actionType == ActionType.REMOVE_PREV_ACTION)
        INVALID_ACTION_DATE using (
                outLoanSnapshot.actionDate.atZone(ZoneOffset.UTC).toLocalDate() >= timeWindow.atZone(ZoneOffset.UTC).toLocalDate())
        "Invalid action amount. It must be zero." using (outLoanSnapshot.actionAmount == BigDecimal.ZERO)
        // Create an ideal copy of prev snapshot being rollback.
        val tempPrevSnapshot = outLoanSnapshot.copy(
                linearId = inLoanSnapshot.prevSnapshotId!!,
                actionType = prevSnapshotActionData.actionType,
                actionDate = prevSnapshotActionData.actionDate,
                actionAmount = prevSnapshotActionData.actionAmount)
        "Invalid data in output contract state." using (tempPrevSnapshot.hash() == inLoanSnapshot.prevSnapshotHash)
        "Invalid action. The servicing interval for this loan snapshot is closed." using (inLoanSnapshot.actionType != ActionType.CLOSE_SERVICING_INTERVAL)
        SERVICER_SIGN_ONLY using (signers.contains(inLoanSnapshot.servicer.owningKey))
    }

    private fun verifyAddAction(tx: LedgerTransaction, signers: Set<PublicKey>, timeWindow: Instant) = requireThat {
        ContractUtil.verifyTxComponents(tx, 1, 1, LoanSnapshot::class.java to 1, LoanSnapshot::class.java to 1)
        val inLoanSnapshot = tx.inputsOfType<LoanSnapshot>().single()
        val outLoanSnapshot = tx.outputsOfType<LoanSnapshot>().single()

        verifyPrevSnapshotReference(inLoanSnapshot, outLoanSnapshot)
        INVALID_ACTION_TYPE using (outLoanSnapshot.actionType in ActionType.addActions)
        "Invalid action amount" using (outLoanSnapshot.actionAmount > BigDecimal.ZERO)
        "Invalid action timestamp" using (outLoanSnapshot.actionDate.atZone(ZoneOffset.UTC)
                .toLocalDate() >= timeWindow.atZone(ZoneOffset.UTC).toLocalDate())
        val expectedPayout = inLoanSnapshot.servicingIntervalPayout + outLoanSnapshot.actionAmount
        val actualPayout = outLoanSnapshot.servicingIntervalPayout
        "Invalid servicing interval payout amount. Must be equal to $expectedPayout but it is $actualPayout." using (
                actualPayout == expectedPayout)
        //TODO Are we calculating Unpaid Principle Balance correctly?
        //TODO What business logic says? Could be different calculation formula per action type?
        val expectedPmtBal = inLoanSnapshot.unpaidPrincipalBalance - outLoanSnapshot.actionAmount
        val actualPmtBal = outLoanSnapshot.unpaidPrincipalBalance
        "Invalid unpaid principle balance amount." using (actualPmtBal == expectedPmtBal)
        //Create temp object to validate the output state has valid updates.
        val tempOutLoanSnapshot = when (outLoanSnapshot.actionType) {
            ActionType.PNI, ActionType.CURTAILMENT -> {
                inLoanSnapshot.run {
                    outLoanSnapshot.copy(actionDate = actionDate, actionType = actionType, actionAmount = actionAmount,
                            unpaidPrincipalBalance = unpaidPrincipalBalance, dueDate = dueDate, linearId = linearId,
                            prevSnapshotId = prevSnapshotId, prevSnapshotHash = prevSnapshotHash,
                            servicingIntervalPayout = servicingIntervalPayout)
                }
            }
            ActionType.CORP_ADV -> {
                val expectedCorpAdv = inLoanSnapshot.corporateAdvanceBalance + outLoanSnapshot.actionAmount
                val actualCorpAdv = outLoanSnapshot.corporateAdvanceBalance
                "Invalid corporate advance balance amount." using (actualCorpAdv == expectedCorpAdv)
                inLoanSnapshot.run {
                    outLoanSnapshot.copy(actionDate = actionDate, actionType = actionType, actionAmount = actionAmount,
                            unpaidPrincipalBalance = unpaidPrincipalBalance, dueDate = dueDate, linearId = linearId,
                            prevSnapshotId = prevSnapshotId, prevSnapshotHash = prevSnapshotHash,
                            servicingIntervalPayout = servicingIntervalPayout, corporateAdvanceBalance = corporateAdvanceBalance)
                }
            }
            ActionType.ESCROW_ADV -> {
                val expectedEscrowAdv = inLoanSnapshot.escrowAdvanceBalance + outLoanSnapshot.actionAmount
                val actualEscrow = outLoanSnapshot.escrowAdvanceBalance
                "Invalid corporate advance balance amount." using (actualEscrow == expectedEscrowAdv)
                inLoanSnapshot.run {
                    outLoanSnapshot.copy(actionDate = actionDate, actionType = actionType, actionAmount = actionAmount,
                            unpaidPrincipalBalance = unpaidPrincipalBalance, dueDate = dueDate, linearId = linearId,
                            prevSnapshotId = prevSnapshotId, prevSnapshotHash = prevSnapshotHash,
                            servicingIntervalPayout = servicingIntervalPayout, escrowAdvanceBalance = escrowAdvanceBalance)
                }
            }
            else -> throw IllegalArgumentException(INVALID_ACTION_TYPE)
        }
        // TODO Consider the change in servicing interval Id on first action after close of previous serving interval.
        "The LoanSnapshot output state contains invalid updates." using (tempOutLoanSnapshot == inLoanSnapshot)

        if (inLoanSnapshot.actionType == ActionType.CLOSE_SERVICING_INTERVAL)
            "Invalid reference of the closed servicing interval in loan snapshot out state." using (inLoanSnapshot.servicingIntervalId != outLoanSnapshot.servicingIntervalId)

        SERVICER_SIGN_ONLY using (signers.contains(outLoanSnapshot.servicer.owningKey))
    }

    private fun verifyServicerConfirms(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        ContractUtil.verifyTxComponents(tx, 1, 2,
                listOf(LoanSnapshot::class.java to 1),
                listOf(LoanSnapshot::class.java to 1, ServicingInterval::class.java to 1))
        val outLoanSnapshot = tx.outputsOfType<LoanSnapshot>().single()
        val inLoanSnapshot = tx.inputsOfType<LoanSnapshot>().single()
        val servicingInterval = tx.outputsOfType<ServicingInterval>().single()

        verifyPrevSnapshotReference(inLoanSnapshot, outLoanSnapshot)
        INVALID_NOTE_RATE using (outLoanSnapshot.noteRate > BigDecimal.ZERO)
        "Invalid servicer and owning investor identities in output states" using (
                inLoanSnapshot.servicer == outLoanSnapshot.servicer
                        && inLoanSnapshot.owningInvestor == outLoanSnapshot.owningInvestor
                        && servicingInterval.servicer == inLoanSnapshot.servicer
                        && servicingInterval.owningInvestor == inLoanSnapshot.owningInvestor)
        "LoanSnapshot out state contains invalid servicing-interval Id." using (outLoanSnapshot.servicingIntervalId != null
                && outLoanSnapshot.servicingIntervalId == servicingInterval.linearId)
        INVALID_ACTION_TYPE using (outLoanSnapshot.actionType == ActionType.SERVICER_CONFIRM)
        INVALID_ACTION_AMOUNT using (outLoanSnapshot.actionAmount == BigDecimal.ZERO)
        INVALID_SERV_PAYOUT_AMOUNT using (outLoanSnapshot.servicingIntervalPayout == BigDecimal.ZERO)
        SERVICER_SIGN_ONLY using (signers.contains(outLoanSnapshot.servicer.owningKey))
    }

    private fun verifyPrevSnapshotReference(input: LoanSnapshot, output: LoanSnapshot) = requireThat {
        "Invalid previous snapshot ID/Hash referenced by loan-snapshot output state." using (
                (output.prevSnapshotId != null && output.prevSnapshotHash != null)
                        && (output.prevSnapshotId == input.linearId && output.prevSnapshotHash == input.hash()))
        "Invalid linearId field value of loan-snapshot output state." using (input.linearId != output.linearId)
        "Invalid loanId referenced by loan-snapshot output state." using (input.loanId == output.loanId)
    }

    private fun verifyCreateLoanSnapshot(tx: LedgerTransaction, signers: Set<PublicKey>, timeWindow: Instant) = requireThat {
        ContractUtil.verifyTxComponents(tx, 0, 2,
                emptyList(),
                listOf(LoanSnapshot::class.java to 1, LoanState::class.java to 1))
        val loanSnapshot = tx.outputsOfType<LoanSnapshot>().single()
        val loanState = tx.outputsOfType<LoanState>().single()
        INVALID_NOTE_RATE using (loanSnapshot.noteRate > BigDecimal(0))
        "Invalid loanId referenced by loan-snapshot output state." using (loanSnapshot.loanId == loanState.linearId)
        "Invalid previousSnapshotId field value." using (loanSnapshot.prevSnapshotId == null)
        "Invalid previousSnapshotHash field value." using (loanSnapshot.prevSnapshotHash == null)
        INVALID_ACTION_TYPE using (loanSnapshot.actionType == ActionType.APPOINT)
        INVALID_ACTION_AMOUNT using (loanSnapshot.actionAmount == BigDecimal.ZERO)
        INVALID_ACTION_DATE using (
                loanSnapshot.actionDate.atZone(ZoneOffset.UTC).toLocalDate() >= timeWindow.atZone(ZoneOffset.UTC).toLocalDate())
        INVALID_SERV_PAYOUT_AMOUNT using (loanSnapshot.servicingIntervalPayout == BigDecimal.ZERO)
        "The OwningInvestor and Servicer cannot be the same identity." using (loanSnapshot.servicer != loanSnapshot.owningInvestor)
        "Invalid participants list." using (loanSnapshot.participants.containsAll(listOf(loanSnapshot.owningInvestor, loanSnapshot.servicer)))
        "Invalid external Id of LinearId." using (loanSnapshot.linearId.externalId != null)
        "Owning investor only may sign the transaction." using (signers.contains(loanSnapshot.owningInvestor.owningKey))
    }
}