package com.loandlt.cordapp.contract

import net.corda.core.contracts.ContractState
import net.corda.core.contracts.requireThat
import net.corda.core.transactions.LedgerTransaction
import java.security.PublicKey

class ContractUtil {
    companion object {
        const val INVALID_ACTION_TYPE = "Invalid action type."
        const val SERVICER_SIGN_ONLY = "Servicer only may sign the transaction."
        const val INVALID_NOTE_RATE = "The NoteRate must have a positive amount."
        const val INVALID_ACTION_AMOUNT = "Invalid action amount."
        const val INVALID_SERV_PAYOUT_AMOUNT = "Invalid servicing interval payout amount."
        const val INVALID_ACTION_DATE = "Invalid action date."

        @JvmStatic
        fun keysFromParticipants(loanState: ContractState): Set<PublicKey> {
            return loanState.participants.map {
                it.owningKey
            }.toSet()
        }

        @JvmStatic
        fun <T : ContractState> verifyTxComponents(tx: LedgerTransaction,
                                                   inputs: Int? = null,
                                                   outputs: Int? = null,
                                                   inputStateTypeAndCount: List<Pair<Class<out T>, Int>> = emptyList(),
                                                   outputStateTypeAndCount: List<Pair<Class<out T>, Int>> = emptyList()
        ) = requireThat {
            if (inputs != null) "Input contract states count must be: $inputs" using (tx.inputStates.size == inputs)
            if (outputs != null) "Output contract states count must be: $outputs" using (tx.outputStates.size == outputs)

            inputStateTypeAndCount.forEach { inStatesAndCount ->
                val clazz = inStatesAndCount.first
                "The ${clazz.simpleName} input state(s) count must be: ${inStatesAndCount.second}" using (
                        tx.inputsOfType(clazz).size == inStatesAndCount.second)
            }
            outputStateTypeAndCount.forEach { outStatesAndCount ->
                val clazz = outStatesAndCount.first
                "The ${clazz.simpleName} output state(s) count must be: ${outStatesAndCount.second}" using (
                        tx.outputsOfType(clazz).size == outStatesAndCount.second)
            }
        }

        @JvmStatic
        fun <T : ContractState> verifyTxComponents(tx: LedgerTransaction,
                                                   inputs: Int? = null,
                                                   outputs: Int? = null,
                                                   inputStateTypeAndCount: Pair<Class<T>, Int>? = null,
                                                   outputStateTypeAndCount: Pair<Class<T>, Int>? = null) {
            verifyTxComponents(tx, inputs, outputs,
                    if (inputStateTypeAndCount == null) emptyList() else listOf(inputStateTypeAndCount),
                    if (outputStateTypeAndCount == null) emptyList() else listOf(outputStateTypeAndCount)
            )
        }
    }
}