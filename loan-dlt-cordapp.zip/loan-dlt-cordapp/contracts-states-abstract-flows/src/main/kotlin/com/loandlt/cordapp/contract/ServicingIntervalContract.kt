package com.loandlt.cordapp.contract

import com.loandlt.cordapp.state.LoanSnapshot
import com.loandlt.cordapp.state.ServicingBatch
import com.loandlt.cordapp.state.ServicingInterval
import net.corda.core.contracts.*
import net.corda.core.contracts.Requirements.using
import net.corda.core.transactions.LedgerTransaction
import java.math.BigDecimal
import java.security.PublicKey
import java.time.ZoneOffset

class ServicingIntervalContract : Contract {

    companion object {
        @JvmStatic
        val ID = ServicingIntervalContract::class.java.name!!
    }

    interface Commands : CommandData {
        class CreateServicingInterval : TypeOnlyCommandData(), Commands
        class CloseServicingInterval : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) = requireThat {
        require(tx.timeWindow?.midpoint != null) { "Transaction must be timestamped." }
        val command = tx.commands.requireSingleCommand<Commands>()
        val signers = command.signers.toSet()

        when (command.value) {
            is Commands.CreateServicingInterval -> verifyCreate(tx, signers)
            is Commands.CloseServicingInterval -> verifyClose(tx, signers)
            else -> throw IllegalArgumentException("Unrecognised command.")
        }
    }

    private fun verifyClose(tx: LedgerTransaction, signers: Set<PublicKey>) {
        "Must have LoanSnapshot inputs or output state(s)." using (
                tx.outputsOfType<LoanSnapshot>().isNotEmpty() && tx.inputsOfType<LoanSnapshot>().isNotEmpty())

        ContractUtil.verifyTxComponents(tx = tx,
                outputStateTypeAndCount = ServicingInterval::class.java to 1,
                inputStateTypeAndCount = ServicingInterval::class.java to 1
        )

        val intervalInOuts = tx.groupStates(ServicingInterval::class.java, ServicingInterval::linearId)
        "Invalid pair of input and output states of ServicingInterval." using (intervalInOuts.size == 1)

        val inInterval = intervalInOuts.single().inputs.single()
        val outInterval = intervalInOuts.single().outputs.single()

        "Invalid cutoff date." using (outInterval.cutOffDate != null)
        "Invalid batch Id." using (outInterval.batchId != null)

        val tempInterval = inInterval.run {
            outInterval.copy(cutOffDate = cutOffDate, calculatedPayout = calculatedPayout, batchId = batchId, status = status)
        }
        "The ServicingInterval output state contains invalid data." using (tempInterval == inInterval)

        val outBatches = tx.outputsOfType<ServicingBatch>()
        val refBatches = tx.referenceInputRefsOfType<ServicingBatch>()
        "ServicingBatch is missing or found too many states." using (
                (outBatches.isNotEmpty() && outBatches.size == 1) || (refBatches.isNotEmpty() && refBatches.size == 1))

        val servicingBatch = outBatches.singleOrNull() ?: refBatches[0].state.data
        val outLoanSnapshots = tx.outputsOfType<LoanSnapshot>()

        "All LoanSnapshot state must reference to single ServicingInterval." using (
                outLoanSnapshots.groupBy { it -> it.servicingIntervalId }.keys.size == 1)
        "Invalid ServicingInterval Id referenced by LoanSnapshot out state." using (
                outLoanSnapshots.groupBy { it -> it.servicingIntervalId }.keys.single() == outInterval.linearId)
        "Invalid batch Id." using (outInterval.batchId == servicingBatch.linearId)
        "Invalid servicing interval cutoff date." using (outInterval.cutOffDate!! <= servicingBatch.cutOffDate)

        val expectedPayout = outLoanSnapshots.asSequence()
                .map { it.servicingIntervalPayout }
                .fold(BigDecimal.ZERO, BigDecimal::add)

        "Servicing interval calculated payout amount must be greater than zero." using (expectedPayout > BigDecimal.ZERO)
        "Invalid calculated payout amount." using (outInterval.calculatedPayout == expectedPayout)

        val isInvestorOfSnapshotSameAsIntervalState = outLoanSnapshots.all { it.owningInvestor == outInterval.owningInvestor }
        val isInvestorOfBatchSameAsIntervalState = servicingBatch.owningInvestor == outInterval.owningInvestor

        "The owning investor identity must be same across all contract states i.e. LoanSnapshot, ServicingInterval, ServicingBatch." using (
                isInvestorOfSnapshotSameAsIntervalState && isInvestorOfBatchSameAsIntervalState)

        "Invalid status." using (inInterval.isOpen() && outInterval.isClosed())
        "The servicer should sign the transaction." using (signers.contains(outInterval.servicer.owningKey))
    }

    private fun verifyCreate(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        "No inputs should be consumed when creating servicing interval." using (tx.inputsOfType<ServicingInterval>().isEmpty())
        "Only one loan state should be created while initiating servicing interval." using (tx.outRefsOfType<ServicingInterval>().size == 1)

        val servicingInterval = tx.outputsOfType<ServicingInterval>().single()
        "The OwningInvestor and Servicer cannot be the same identity." using (servicingInterval.servicer != servicingInterval.owningInvestor)
        "The calculated payout field value must be zero while creating serving interval." using (servicingInterval.calculatedPayout == BigDecimal(0))

        "The servicing interval start date must be today or in future." using (
                servicingInterval.startDate.atZone(ZoneOffset.UTC).toLocalDate() >= tx.timeWindow!!.midpoint!!.atZone(ZoneOffset.UTC).toLocalDate())

        "Invalid participants list." using (
                servicingInterval.participants.containsAll(listOf(servicingInterval.owningInvestor, servicingInterval.servicer)))

        "Invalid external Id of LinearId." using (
                servicingInterval.linearId.externalId != null && servicingInterval.linearId.externalId == servicingInterval.servicingIntervalId)

        "Invalid status, it must be open." using (servicingInterval.isOpen())
        "A servicer may only sign the transaction." using (signers.contains(servicingInterval.servicer.owningKey))
    }
}