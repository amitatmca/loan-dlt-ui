package com.loandlt.cordapp.contract

import com.loandlt.cordapp.state.BatchStatus
import com.loandlt.cordapp.state.ServicingBatch
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction
import java.security.PublicKey

class ServicingBatchContract : Contract {

    companion object {
        @JvmStatic
        val ID = ServicingBatchContract::class.java.name!!
    }

    interface Commands : CommandData {
        class CreateBatch : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) {
        tx.timeWindow?.midpoint ?: throw IllegalArgumentException("Transaction must be timestamped.")
        val command = tx.commands.requireSingleCommand<Commands>()
        val signers = command.signers.toSet()

        when (command.value) {
            is Commands.CreateBatch -> verifyCreateBatch(tx, signers)
            else -> throw IllegalArgumentException("Unrecognised command.")
        }
    }

    private fun verifyCreateBatch(tx: LedgerTransaction, signers: Set<PublicKey>) = requireThat {
        ContractUtil.verifyTxComponents(tx = tx,
                outputStateTypeAndCount = ServicingBatch::class.java to 1)
        val output = tx.outputsOfType<ServicingBatch>().single()

        "Invalid servicing batch Id." using (output.servicingBatchId.trim().isNotEmpty())
        "Invalid start date, must be before cutoff date." using (output.startDate < output.cutOffDate)
        "Wire Id must not be given while creating new batch." using (output.wireId.trim().isEmpty())
        "Wire transfer date must not be given while creating new batch." using (output.wireXferDate == null)
        "Invalid batch status." using (output.status == BatchStatus.OPEN)
        "Invalid participants list." using (output.participants.containsAll(listOf(output.owningInvestor, output.servicer)))
        "Invalid external Id of LinearId." using (output.linearId.externalId != null && output.linearId.externalId == output.servicingBatchId)
        "The servicer should sign the transaction." using (signers.contains(output.servicer.owningKey))
    }
}