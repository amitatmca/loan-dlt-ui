package com.loandlt.cordapp.state

import com.loandlt.cordapp.contract.ServicingIntervalContract
import com.loandlt.cordapp.schema.ServicingIntervalSchemaV1
import net.corda.core.contracts.BelongsToContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.time.Instant

/***
 * ServicingInterval state holds loan servicing interval or cycle data.
 */
@BelongsToContract(ServicingIntervalContract::class)
data class ServicingInterval(val servicingIntervalId: String,
                             val loanId: UniqueIdentifier,
                             val startDate: Instant,
                             val cutOffDate: Instant?,
                             val calculatedPayout: BigDecimal,
                             val batchId: UniqueIdentifier?,
                             val owningInvestor: AbstractParty,
                             val servicer: AbstractParty,
                             val status: IntervalStatus = IntervalStatus.OPEN,
                             override val participants: List<AbstractParty> = listOf(owningInvestor, servicer),
                             override val linearId: UniqueIdentifier = UniqueIdentifier(servicingIntervalId)) : LinearState, QueryableState {
    constructor(servicingIntervalId: String, loanId: UniqueIdentifier, startDate: Instant, owningInvestor: AbstractParty, servicer: AbstractParty)
            : this(servicingIntervalId, loanId, startDate, null, BigDecimal.ZERO, null, owningInvestor, servicer)

    fun isOpen() = this.status == IntervalStatus.OPEN
    fun isClosed() = this.status == IntervalStatus.CLOSED

    fun closeInterval(calculatedPayout: BigDecimal, cutOffDate: Instant, batchId: UniqueIdentifier): ServicingInterval {
        return this.copy(calculatedPayout = calculatedPayout,
                cutOffDate = cutOffDate,
                batchId = batchId,
                status = IntervalStatus.CLOSED)
    }

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is ServicingIntervalSchemaV1 -> ServicingIntervalSchemaV1.PersistentServicingInterval(
                    servicingIntervalId = this.servicingIntervalId,
                    loanId = this.loanId.toString(),
                    startDate = this.startDate,
                    cutOffDate = this.cutOffDate,
                    calculatedPayout = this.calculatedPayout,
                    batchId = this.batchId?.toString(),
                    owningInvestor = this.owningInvestor,
                    servicer = this.servicer,
                    status = this.status.name,
                    participants = this.participants.toMutableSet(),
                    linearId = linearId.toString()
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(ServicingIntervalSchemaV1)
}

@CordaSerializable
enum class IntervalStatus {
    OPEN,
    CLOSED
}