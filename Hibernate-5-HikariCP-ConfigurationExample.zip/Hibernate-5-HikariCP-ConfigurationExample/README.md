# HibernateServiceAndDAOLayer

Hibernate Example with Service and DAO layer
