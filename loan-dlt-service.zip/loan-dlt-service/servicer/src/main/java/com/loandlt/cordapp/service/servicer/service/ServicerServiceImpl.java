package com.loandlt.cordapp.service.servicer.service;

import org.springframework.stereotype.Service;

/**
 * A class provides method for Servicer.
 *
 * @author Synechron Technology
 * @version 0.1
 */
@Service
public class ServicerServiceImpl implements ServicerService {

//Implement methods

}
