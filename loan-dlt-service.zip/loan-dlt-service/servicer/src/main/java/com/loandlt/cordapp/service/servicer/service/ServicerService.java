package com.loandlt.cordapp.service.servicer.service;

/**
 * A interface provides method for Servicer.
 *
 * @author Synechron Technology
 * @version 0.1
 */
public interface ServicerService {
    //declare methods
}
