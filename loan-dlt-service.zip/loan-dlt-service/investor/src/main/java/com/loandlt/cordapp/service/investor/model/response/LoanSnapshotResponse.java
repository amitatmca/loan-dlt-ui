package com.loandlt.cordapp.service.investor.model.response;

import java.math.BigDecimal;
import java.math.BigInteger;

public class LoanSnapshotResponse {
    private String loanId;
    private BigDecimal unpaidPrincipalBalance;
    private String dueDate;
    private BigDecimal noteRate;
    private BigDecimal pmtCalcPrincipal;
    private BigInteger pmtCalcTerm;
    private String indexCode;
    private String firstRateChangeDate;
    private BigInteger rateChangeFrequency;
    private BigDecimal rateMargin;
    private BigDecimal corporateAdvanceBalance;
    private BigDecimal escrowAdvanceBalance;

    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public BigDecimal getUnpaidPrincipalBalance() {
        return unpaidPrincipalBalance;
    }

    public void setUnpaidPrincipalBalance(BigDecimal unpaidPrincipalBalance) {
        this.unpaidPrincipalBalance = unpaidPrincipalBalance;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getNoteRate() {
        return noteRate;
    }

    public void setNoteRate(BigDecimal noteRate) {
        this.noteRate = noteRate;
    }

    public BigDecimal getPmtCalcPrincipal() {
        return pmtCalcPrincipal;
    }

    public void setPmtCalcPrincipal(BigDecimal pmtCalcPrincipal) {
        this.pmtCalcPrincipal = pmtCalcPrincipal;
    }

    public BigInteger getPmtCalcTerm() {
        return pmtCalcTerm;
    }

    public void setPmtCalcTerm(BigInteger pmtCalcTerm) {
        this.pmtCalcTerm = pmtCalcTerm;
    }

    public String getIndexCode() {
        return indexCode;
    }

    public void setIndexCode(String indexCode) {
        this.indexCode = indexCode;
    }

    public String getFirstRateChangeDate() {
        return firstRateChangeDate;
    }

    public void setFirstRateChangeDate(String firstRateChangeDate) {
        this.firstRateChangeDate = firstRateChangeDate;
    }

    public BigInteger getRateChangeFrequency() {
        return rateChangeFrequency;
    }

    public void setRateChangeFrequency(BigInteger rateChangeFrequency) {
        this.rateChangeFrequency = rateChangeFrequency;
    }

    public BigDecimal getRateMargin() {
        return rateMargin;
    }

    public void setRateMargin(BigDecimal rateMargin) {
        this.rateMargin = rateMargin;
    }

    public BigDecimal getCorporateAdvanceBalance() {
        return corporateAdvanceBalance;
    }

    public void setCorporateAdvanceBalance(BigDecimal corporateAdvanceBalance) {
        this.corporateAdvanceBalance = corporateAdvanceBalance;
    }

    public BigDecimal getEscrowAdvanceBalance() {
        return escrowAdvanceBalance;
    }

    public void setEscrowAdvanceBalance(BigDecimal escrowAdvanceBalance) {
        this.escrowAdvanceBalance = escrowAdvanceBalance;
    }


}
