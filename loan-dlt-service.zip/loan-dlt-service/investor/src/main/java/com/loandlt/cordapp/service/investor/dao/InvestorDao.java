package com.loandlt.cordapp.service.investor.dao;

import com.loandlt.cordapp.investor.model.Loan;
import com.loandlt.cordapp.state.LoanSnapshot;
import com.loandlt.cordapp.state.LoanState;
import net.corda.core.crypto.SecureHash;

import java.util.List;

/**
 * <h1>Investor<h1/>
 * A DAO interface provides method to call CorDapp by RPCConnection.
 *
 * @author Synechron Technology
 * @version 0.1
 * @see InvestorDaoImpl
 */
public interface InvestorDao {
    /**
     * This method responsible to call CordApp through RPCConnection to appoint servicer.
     *
     * @param loan - LoanResponse Dao Model of CorDapp
     * @return - Hash of transaction
     */
    SecureHash appointServicer(Loan loan);

    /**
     * A method return loan state.
     * <p>
     * This method query to vault by RPCConnection to fetch loan state by unique loan id.
     *
     * @param loanId
     * @return - LoanState
     */
    LoanState getLoanState(String loanId);

    /**
     * A method return loan snapshot.
     * <p>
     * This method query to vault by RPCConnection to fetch loan snapshot by unique loan id.
     *
     * @param loanId
     * @return - List<LoanSnapshot>
     */
    List<LoanSnapshot> getLoanSnapshot(String loanId);

    /**
     *
     * @return
     */
    List<LoanState> getAllLoans();

}
