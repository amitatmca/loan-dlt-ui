package com.loandlt.cordapp.service.investor.service;

import com.loandlt.cordapp.investor.model.Loan;
import com.loandlt.cordapp.service.commons.util.CommonUtils;
import com.loandlt.cordapp.service.investor.dao.InvestorDao;
import com.loandlt.cordapp.service.investor.model.request.AppointServicerRequest;
import com.loandlt.cordapp.service.investor.model.response.LoanResponse;
import com.loandlt.cordapp.service.investor.model.response.LoanSnapshotResponse;
import com.loandlt.cordapp.state.LoanSnapshot;
import com.loandlt.cordapp.state.LoanState;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.AbstractParty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <h1>Investor<h1/>
 * A Service class provides method to manage loan.
 *
 * @author Synechron Technology
 * @version 0.1
 * @see InvestorDao
 */
@Service
public class InvestorServiceImpl implements InvestorService {

    @Autowired
    private InvestorDao investorDao;

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash appointServicer(AppointServicerRequest appointServicerRequest) {

        //TODO: Map parties name with X.500 name in database.
        //Send x.500 names to CordApp
        Map<String, String> partiesX500Names = new HashMap<>();
        partiesX500Names.put("InvestorA", "O=InvestorA,L=New York,C=US");
        partiesX500Names.put("ServicerA", "O=ServicerA,L=New York,C=US");

        Loan loan = appointServicerRequest.createLoanState(partiesX500Names);
        return investorDao.appointServicer(loan);
    }

    @Override
    public LoanResponse getLoan(String loanId) {

        //TODO: Map parties name with X.500 name in database.
        Map<String, String> partiesX500Names = new HashMap<>();
        partiesX500Names.put("O=InvestorA, L=New York, C=US", "InvestorA");
        partiesX500Names.put("O=ServicerA, L=New York, C=US", "ServicerA");

        LoanState loanState = investorDao.getLoanState(loanId);

        List<LoanSnapshotResponse> loanSnapshotResponses = getLoanSnapShot(loanState.getLinearId().toString());
        LoanResponse loanResponse = new LoanResponse();

        loanResponse.setLoanId(loanState.getLoanId());

        loanResponse.setServicer(partiesX500Names.get(loanState.getServicer().toString()));
        loanResponse.setMsrOwner(partiesX500Names.get(loanState.getMsrOwner().toString()));
        loanResponse.setLoanSnapshots(loanSnapshotResponses);

        return loanResponse;
    }

    /**
     * Fetch Loan Snapshots and map to LoanSnapshotResponse.
     *
     * @param loanId
     */
    private List<LoanSnapshotResponse> getLoanSnapShot(String loanId) {
        List<LoanSnapshotResponse> loanSnapshotResponses = new ArrayList<>();
        List<LoanSnapshot> loanSnapshots = investorDao.getLoanSnapshot(loanId);
        loanSnapshots.forEach(loanSnapshot -> {
            LoanSnapshotResponse loanSnapshotResponse = new LoanSnapshotResponse();
            loanSnapshotResponse.setLoanId(loanSnapshot.getLoanId().toString());
            loanSnapshotResponse.setUnpaidPrincipalBalance(loanSnapshot.getUnpaidPrincipalBalance());
            loanSnapshotResponse.setDueDate(CommonUtils.convertDateToString(loanSnapshot.getDueDate()));
            loanSnapshotResponse.setNoteRate(loanSnapshot.getNoteRate());
            loanSnapshotResponse.setPmtCalcPrincipal(loanSnapshot.getPmtCalcPrincipal());
            loanSnapshotResponse.setPmtCalcTerm(loanSnapshot.getPmtCalcTerm());
            loanSnapshotResponse.setIndexCode(loanSnapshot.getIndexCode());
            loanSnapshotResponse.setFirstRateChangeDate(CommonUtils.convertDateToString(loanSnapshot.getFirstRateChangeDate()));
            loanSnapshotResponse.setRateChangeFrequency(loanSnapshot.getRateChangeFrequency());

            loanSnapshotResponse.setRateMargin(loanSnapshot.getRateMargin());
            loanSnapshotResponse.setCorporateAdvanceBalance(loanSnapshot.getCorporateAdvanceBalance());
            loanSnapshotResponse.setEscrowAdvanceBalance(loanSnapshot.getEscrowAdvanceBalance());
            loanSnapshotResponses.add(loanSnapshotResponse);
        });
        return loanSnapshotResponses;
    }
}
