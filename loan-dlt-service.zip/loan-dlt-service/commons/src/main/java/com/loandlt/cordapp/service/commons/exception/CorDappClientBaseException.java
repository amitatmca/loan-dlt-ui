package com.loandlt.cordapp.service.commons.exception;

public class CorDappClientBaseException extends RuntimeException {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 8675007456900089437L;

    private String message;
    private Exception exception;

    public CorDappClientBaseException() {

    }

    public CorDappClientBaseException(String message) {
        this.message = message;
    }

    public CorDappClientBaseException(Exception exception) {
        this.exception = exception;
    }

    public CorDappClientBaseException(String message, Exception exception) {
        this.message = message;
        this.exception = exception;
    }

    /**
     * @return the message
     */
    @Override
    public String getMessage() {
        return message;
    }

    public Exception getException() {
        return exception;
    }

    @Override
    public String toString() {
        return "CorDappClientBaseException{" +
                "message='" + message + '\'' +
                ", exception=" + exception +
                '}';
    }
}
