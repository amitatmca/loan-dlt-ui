package com.loandlt.cordapp.service.investor.controller;

import com.loandlt.cordapp.service.investor.model.request.AppointServicerRequest;
import com.loandlt.cordapp.service.investor.model.response.LoanResponse;
import org.springframework.http.ResponseEntity;

/**
 * <h1>Investor</h1>
 * InvestorApi interface represent a Investor to manage loans.
 *
 * @author Synechron Technology
 * @version 0.1
 * @see InvestorApiController
 */

public interface InvestorApi {

    /**
     * This method responsible to appoint servicer.
     * <p>
     * Investor call this method to appoint servicer.
     *
     * @param issueLoanRequest - loan data
     * @return ResponseEntity - It return hash of transaction
     */
    ResponseEntity appointServicer(AppointServicerRequest issueLoanRequest);

    /**
     * This method return loan with loan snapshots.
     *
     * @param loanId
     * @return - LoanResponse
     */
    ResponseEntity<LoanResponse> getLoan(String loanId);
}
