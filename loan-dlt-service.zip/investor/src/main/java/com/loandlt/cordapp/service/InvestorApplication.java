package com.loandlt.cordapp.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@EnableAspectJAutoProxy
public class InvestorApplication {

    /**
     * This is Main method to which will start Spring Boot Application.
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(InvestorApplication.class, args);
    }

}
