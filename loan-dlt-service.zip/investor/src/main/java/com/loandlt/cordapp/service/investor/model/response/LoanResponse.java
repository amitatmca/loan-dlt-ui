package com.loandlt.cordapp.service.investor.model.response;

import java.util.List;

/**
 * A class holds response detail of loan. A loan can have multiple snapshot.
 */
public class LoanResponse {

    private String loanId;
    private String msrOwner;
    private String servicer;
    private List<LoanSnapshotResponse> loanSnapshots;

    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public String getMsrOwner() {
        return msrOwner;
    }

    public void setMsrOwner(String msrOwner) {
        this.msrOwner = msrOwner;
    }

    public String getServicer() {
        return servicer;
    }

    public void setServicer(String servicer) {
        this.servicer = servicer;
    }

    public List<LoanSnapshotResponse> getLoanSnapshots() {
        return loanSnapshots;
    }

    public void setLoanSnapshots(List<LoanSnapshotResponse> loanSnapshots) {
        this.loanSnapshots = loanSnapshots;
    }
}
