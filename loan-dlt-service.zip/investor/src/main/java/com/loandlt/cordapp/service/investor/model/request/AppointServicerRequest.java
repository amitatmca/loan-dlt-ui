package com.loandlt.cordapp.service.investor.model.request;

import com.loandlt.cordapp.investor.model.Loan;
import com.loandlt.cordapp.service.commons.util.CommonUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Instant;
import java.util.Map;

/**
 * A class holds Issue loan request data.
 */
public class AppointServicerRequest {
    private String loanId;
    private String msrOwner;
    private BigDecimal unpaidPrincipalBalance;
    private String dueDate;
    private BigDecimal noteRate;
    private BigDecimal pmtCalcPrincipal;
    private BigInteger pmtCalcTerm;
    private String indexCode;
    private String firstRateChangeDate;
    private BigInteger rateChangeFrequency;
    private BigDecimal rateMargin;
    private BigDecimal corporateAdvanceBalance;
    private BigDecimal escrowAdvanceBalance;
    private String servicer;

    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public String getMsrOwner() {
        return msrOwner;
    }

    public void setMsrOwner(String msrOwner) {
        this.msrOwner = msrOwner;
    }

    public BigDecimal getUnpaidPrincipalBalance() {
        return unpaidPrincipalBalance;
    }

    public void setUnpaidPrincipalBalance(BigDecimal unpaidPrincipalBalance) {
        this.unpaidPrincipalBalance = unpaidPrincipalBalance;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getNoteRate() {
        return noteRate;
    }

    public void setNoteRate(BigDecimal noteRate) {
        this.noteRate = noteRate;
    }

    public BigDecimal getPmtCalcPrincipal() {
        return pmtCalcPrincipal;
    }

    public void setPmtCalcPrincipal(BigDecimal pmtCalcPrincipal) {
        this.pmtCalcPrincipal = pmtCalcPrincipal;
    }

    public BigInteger getPmtCalcTerm() {
        return pmtCalcTerm;
    }

    public void setPmtCalcTerm(BigInteger pmtCalcTerm) {
        this.pmtCalcTerm = pmtCalcTerm;
    }

    public String getIndexCode() {
        return indexCode;
    }

    public void setIndexCode(String indexCode) {
        this.indexCode = indexCode;
    }

    public String getFirstRateChangeDate() {
        return firstRateChangeDate;
    }

    public void setFirstRateChangeDate(String firstRateChangeDate) {
        this.firstRateChangeDate = firstRateChangeDate;
    }

    public BigInteger getRateChangeFrequency() {
        return rateChangeFrequency;
    }

    public void setRateChangeFrequency(BigInteger rateChangeFrequency) {
        this.rateChangeFrequency = rateChangeFrequency;
    }

    public BigDecimal getRateMargin() {
        return rateMargin;
    }

    public void setRateMargin(BigDecimal rateMargin) {
        this.rateMargin = rateMargin;
    }

    public BigDecimal getCorporateAdvanceBalance() {
        return corporateAdvanceBalance;
    }

    public void setCorporateAdvanceBalance(BigDecimal corporateAdvanceBalance) {
        this.corporateAdvanceBalance = corporateAdvanceBalance;
    }

    public BigDecimal getEscrowAdvanceBalance() {
        return escrowAdvanceBalance;
    }

    public void setEscrowAdvanceBalance(BigDecimal escrowAdvanceBalance) {
        this.escrowAdvanceBalance = escrowAdvanceBalance;
    }

    public String getServicer() {
        return servicer;
    }

    public void setServicer(String servicer) {
        this.servicer = servicer;
    }

    public Loan createLoanState(Map<String, String> map) {
        Loan loan = new Loan(this.loanId,
                this.unpaidPrincipalBalance, Instant.ofEpochMilli(CommonUtils.convertStringToDate(this.dueDate).getTime()),
                this.noteRate, this.pmtCalcPrincipal, this.pmtCalcTerm,
                this.indexCode, Instant.ofEpochMilli(CommonUtils.convertStringToDate(this.firstRateChangeDate).getTime()),
                this.rateChangeFrequency, this.rateMargin, this.corporateAdvanceBalance,
                this.escrowAdvanceBalance, map.get(this.msrOwner), map.get(this.servicer));
        return loan;
    }
}
