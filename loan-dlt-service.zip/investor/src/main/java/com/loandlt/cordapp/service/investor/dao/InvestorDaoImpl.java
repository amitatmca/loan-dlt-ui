package com.loandlt.cordapp.service.investor.dao;

import com.loandlt.cordapp.investor.flows.LoanOnboardingFlow;
import com.loandlt.cordapp.investor.model.Loan;
import com.loandlt.cordapp.service.commons.exception.CorDappClientBaseException;
import com.loandlt.cordapp.service.commons.rpc.NodeRPCConnection;
import com.loandlt.cordapp.state.LoanSnapshot;
import com.loandlt.cordapp.state.LoanState;
import net.corda.core.crypto.SecureHash;
import net.corda.core.messaging.FlowHandle;
import net.corda.core.transactions.SignedTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <h1>Investor<h1/>
 * A Dao class call the CorDapp by rpc connection.
 *
 * @author Synechron Technology
 * @version 0.1
 */
@Repository
public class InvestorDaoImpl implements InvestorDao {

    @Autowired
    private NodeRPCConnection rpcConnection;

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash appointServicer(Loan loan) {

        try {
            FlowHandle<SignedTransaction> flowHandle = rpcConnection.getProxy().startFlowDynamic(LoanOnboardingFlow.class, loan);
            return flowHandle.getReturnValue().get().getId();
        } catch (Exception exception) {
            throw new CorDappClientBaseException(exception);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<LoanState> getAllLoans() {

        List<LoanState> loanStates = rpcConnection.getProxy().
                vaultQuery(LoanState.class).getStates().stream()
                .map(it -> it.getState().getData()).collect(Collectors.toList());

        return loanStates;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LoanState getLoanState(String loanId) {

        LoanState loanState = rpcConnection.getProxy().
                vaultQuery(LoanState.class).getStates().stream()
                .filter(it -> it.getState().getData().getLoanId().equals(loanId))
                .map(it -> it.getState().getData()).collect(Collectors.toList()).get(0);

        return loanState;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<LoanSnapshot> getLoanSnapshot(String loanId) {

        List<LoanSnapshot> loanSnapshots = rpcConnection.getProxy().
                vaultQuery(LoanSnapshot.class).getStates().stream()
                .filter(it -> it.getState().getData().getLoanId().toString().equals(loanId))
                .map(it -> it.getState().getData()).collect(Collectors.toList());
        return loanSnapshots;
    }
}
