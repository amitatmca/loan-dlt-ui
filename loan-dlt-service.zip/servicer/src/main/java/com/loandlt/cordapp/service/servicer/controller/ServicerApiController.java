package com.loandlt.cordapp.service.servicer.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * A Controller class provides method for Servicer.
 *
 * @author Synechron Technology
 * @version 0.1
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/servicer")
public class ServicerApiController implements ServicerApi {

    //Implement Methods
}
