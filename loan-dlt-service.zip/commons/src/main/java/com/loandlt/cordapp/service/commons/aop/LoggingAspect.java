package com.loandlt.cordapp.service.commons.aop;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * An Aspect for logging the method entry & exit points.
 *
 */
@Aspect
@Component
public class LoggingAspect {
    @Autowired
    private ObjectMapper objectMapper;
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Before Aspect for logging the method entry point.
     *
     * @param joinPoint of type JoinPoint
     */
    @Before("execution(* com.synechron.cordapp.caap..*(..)) && !execution(* com.synechron.cordapp.caap.commons.config..*(..)) && !execution(* com.synechron.cordapp.caap.commons.jwt..*(..)) && !execution(* com.synechron.cordapp.caap.commons.rpc..*(..)) && !execution(* org..*(..))")
    public void before(JoinPoint joinPoint) {
        logger.info("{}.{}() Start", joinPoint.getSignature().getDeclaringType().getSimpleName(), joinPoint.getSignature().getName());
    }

    /**
     * Before Aspect for logging the method input param details entry point.
     *
     * @param joinPoint of type JoinPoint
     */
    @Before("execution(* com.synechron.cordapp.caap.**.controller..*(..))")
    public void loggingParameters(JoinPoint joinPoint) {

        StringBuilder requestParameters = new StringBuilder();
        for (Object requestParam : joinPoint.getArgs()) {
            try {
                String requestParamString = objectMapper.writeValueAsString(requestParam);
                requestParameters.append(requestParamString).append(", ");
            } catch (JsonProcessingException jsonProcessingException) {
                logger.error("Exception while logging request parameters. {}", jsonProcessingException);
            }
        }

        logger.debug("Request Parameter = {}", requestParameters);
    }

    /**
     * Around Aspect for logging the method execution time.
     *
     * @param joinPoint of type ProceedingJoinPoint
     * @return Object
     * @throws Throwable
     */
    @Around("execution(* com.synechron.cordapp.caap.**.controller..*(..)) || execution(* com.synechron.cordapp.caap.**.service..*(..)) || execution(* com.synechron.cordapp.caap.**.dao..*(..)) && !execution(* com.synechron.cordapp.caap.commons.jwt..*(..))  && !execution(* com.synechron.cordapp.caap.commons.config..*(..)) && !execution(* com.synechron.cordapp.caap.commons.rpc..*(..)) && !execution(* org..*(..))")
    public Object measureMethodExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {

        long startTime = System.currentTimeMillis();

        Object output = joinPoint.proceed();

        long endTime = System.currentTimeMillis();
        logger.info("PERFORMANCE: {}.{}() - Total execution time = {} ms.", joinPoint.getSignature().getDeclaringType().getSimpleName(),
                joinPoint.getSignature().getName(), (endTime - startTime));
        return output;
    }

    /**
     * After Aspect for logging the method exit point.
     *
     * @param joinPoint of type JoinPoint
     */
    @After("execution(* com.synechron.cordapp.caap..*(..)) && !execution(* com.synechron.cordapp.caap.commons.jwt..*(..))  && !execution(* com.synechron.cordapp.caap.commons.config..*(..)) && !execution(* com.synechron.cordapp.caap.commons.rpc..*(..)) && !execution(* org..*(..))")
    public void after(JoinPoint joinPoint) {
        logger.info("{}.{}() End", joinPoint.getSignature().getDeclaringType().getSimpleName(), joinPoint.getSignature().getName());
    }

    @AfterThrowing(pointcut = "execution(* com.synechron.cordapp.caap.**.controller..*(..)) && !execution(* com.synechron.cordapp.caap.commons.jwt..*(..))  && !execution(* com.synechron.cordapp.caap.commons.config..*(..))", throwing = "exception")
    public void logException(Exception exception) {
        logger.error(exception.getClass().getName(), exception);
    }
}
