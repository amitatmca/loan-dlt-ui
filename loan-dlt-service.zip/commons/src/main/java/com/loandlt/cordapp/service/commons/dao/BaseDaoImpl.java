package com.loandlt.cordapp.service.commons.dao;

import com.loandlt.cordapp.service.commons.exception.InvalidCordaX500NameException;
import com.loandlt.cordapp.service.commons.exception.PartyNotFoundException;
import com.loandlt.cordapp.service.commons.rpc.NodeRPCConnection;
import com.loandlt.cordapp.service.commons.util.CommonUtils;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BaseDaoImpl implements BaseDao {

    @Autowired
    private NodeRPCConnection rpcConnection;
    private Party nodeIdentity;

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName() {
        String orgName = CommonUtils.getOrganisation(getParty());
        return orgName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName(AbstractParty party) {
        return CommonUtils.getOrganisation(resolveIdentity(party));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty() {
        if (nodeIdentity == null) {
            List<Party> party = rpcConnection.getProxy().nodeInfo().getLegalIdentities();
            nodeIdentity = party.get(0);
            return nodeIdentity;
        }
        return nodeIdentity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty(String partyName) {
        CordaX500Name x500Name;
        Party party = null;
        try {
            x500Name = CordaX500Name.parse(partyName);
        } catch (Exception exception) {
            throw new InvalidCordaX500NameException(partyName, exception);
        }

        party = rpcConnection.getProxy().wellKnownPartyFromX500Name(x500Name);
        if (party == null) {
            throw new PartyNotFoundException(partyName);

        }
        return party;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party resolveIdentity(AbstractParty party) {
        if (party instanceof Party) {
            return (Party) party;
        }
        Party wellKnownParty = rpcConnection.getProxy().wellKnownPartyFromAnonymous(party);
        return wellKnownParty;
    }

}
