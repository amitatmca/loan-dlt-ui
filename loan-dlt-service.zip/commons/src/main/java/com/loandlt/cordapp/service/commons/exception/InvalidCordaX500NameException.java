package com.loandlt.cordapp.service.commons.exception;

public class InvalidCordaX500NameException extends CorDappClientBaseException {

    public InvalidCordaX500NameException() {
    }

    public InvalidCordaX500NameException(String message) {
        super(message);
    }

    public InvalidCordaX500NameException(Exception exception) {
        super(exception);
    }

    public InvalidCordaX500NameException(String message, Exception exception) {
        super(message, exception);
    }
}
