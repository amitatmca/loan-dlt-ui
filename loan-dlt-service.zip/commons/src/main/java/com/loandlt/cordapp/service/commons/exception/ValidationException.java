package com.loandlt.cordapp.service.commons.exception;

import java.text.ParseException;

public class ValidationException extends CorDappClientBaseException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor to call super class constructor and initialize message.
     *
     * @param message
     * @param parseException
     */
    public ValidationException(String message, ParseException parseException) {
        super(message, parseException);
    }
}
