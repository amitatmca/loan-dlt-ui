package com.loandlt.cordapp.service.commons.service;

import com.loandlt.cordapp.service.commons.dao.BaseDao;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BaseServiceImpl implements BaseService {

    @Autowired
    BaseDao baseDao;

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName() {
        String nodeName = baseDao.getNodeName();
        return nodeName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName(AbstractParty party) {
        String nodeName = baseDao.getNodeName(party);
        return nodeName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty() {
        Party party = baseDao.getParty();
        return party;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty(String partyName) {
        Party party = baseDao.getParty(partyName);
        return party;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party resolveIdentity(AbstractParty party) {
        Party party1 = baseDao.resolveIdentity(party);
        return party1;
    }

}
