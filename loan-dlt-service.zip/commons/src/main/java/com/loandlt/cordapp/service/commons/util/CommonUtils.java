package com.loandlt.cordapp.service.commons.util;

import com.loandlt.cordapp.service.commons.exception.ErrorCode;
import com.loandlt.cordapp.service.commons.exception.PartyNotFoundException;
import com.loandlt.cordapp.service.commons.exception.ValidationException;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.Party;
import net.corda.core.messaging.CordaRPCOps;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class CommonUtils {

    public static UniqueIdentifier toUniqueIdentifier(String str) {
        if (str == null) {
            throw new IllegalArgumentException("Invalid UniqueIdentifier string: " + str);
        }
        try {
            // Check if externalId and UUID may be separated by underscore.
            if (str.contains("_")) {
                String[] ids = str.split("_");
                // Create UUID object from string.
                UUID uuid = UUID.fromString(ids[1]);
                // Create UniqueIdentifier object using externalId and UUID.
                return new UniqueIdentifier(ids[0], uuid);
            }

            // Any other string used as id (i.e. UUID).
            return new UniqueIdentifier(null, UUID.fromString(str));
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("Invalid UniqueIdentifier string: " + exception);
        }
    }

    public static Party getNotary(CordaRPCOps proxy) {
        final List<Party> notaries = proxy.notaryIdentities();
        if (notaries.isEmpty()) {
            throw new PartyNotFoundException("Could not find a notary on the network.");
        }
        final Party notary = notaries.get(0);
        return notary;
    }

    public static String getOrganisation(Party party) {
        return party != null ? party.getName().getOrganisation() : "";
    }

    public static Date convertStringToDate(String date) {
        Date convertedDate = null;
        try {
            SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
            convertedDate = new Date(sdf1.parse(date).getTime());

        } catch (ParseException parseException) {
            throw new ValidationException(ErrorCode.INVALID_DATE_FORMAT.getDescription(), parseException);
        }
        return convertedDate;
    }

    public static String convertDateToString(Instant instant) {
        java.util.Date recordDate = java.util.Date.from(instant);
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String formattedDate = formatter.format(recordDate);
        return formattedDate;
    }

}
