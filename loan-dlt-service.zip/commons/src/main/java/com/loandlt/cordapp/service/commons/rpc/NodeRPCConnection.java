package com.loandlt.cordapp.service.commons.rpc;

import net.corda.client.rpc.CordaRPCConnection;
import net.corda.core.messaging.CordaRPCOps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
public class NodeRPCConnection {

    @Autowired
    private RPCConnectionManager rpcConnectionManager;
    CordaRPCConnection rpcConnection = null;

    @PostConstruct
    void getRPCConnection() throws Exception {
        rpcConnection = rpcConnectionManager.getConnection();
    }

    /**
     * This method returns rpc connection object for currently logged-in user.
     *
     * @return an instance that can be served from the pool of type {@link CordaRPCOps}
     */
    public CordaRPCOps getProxy() {
        return rpcConnection.getProxy();
    }

    @PreDestroy
    void destroy() throws Exception {
        if (rpcConnection != null) {
            rpcConnectionManager.returnConnection(rpcConnection);
        }
    }
}