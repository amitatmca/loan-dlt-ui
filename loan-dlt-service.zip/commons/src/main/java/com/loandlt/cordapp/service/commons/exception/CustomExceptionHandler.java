package com.loandlt.cordapp.service.commons.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
    private final Logger LOGGER = LoggerFactory.getLogger(CustomExceptionHandler.class);

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<ErrorResponse> genericExceptionHandler(Exception exception) {
        LOGGER.error("Exception Caught: ", exception);
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.EXCEPTION, exception, HttpStatus.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @ExceptionHandler(value = PartyNotFoundException.class)
    public ResponseEntity<ErrorResponse> partyNotFoundExceptionHandler(PartyNotFoundException exception) {
        LOGGER.error("PartyNotFoundException Caught: ", exception);
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.PARTY_NOT_FOUND, exception, HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @ExceptionHandler(value = InvalidCordaX500NameException.class)
    public ResponseEntity<ErrorResponse> invalidCordaX500NameExceptionHandler(InvalidCordaX500NameException exception) {
        LOGGER.error("InvalidCordaX500NameException Caught: ", exception);
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.INVALID_X500_NAME, exception, HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }


    private ErrorResponse getErrorResponse(ErrorCode errorCode, Exception exception, HttpStatus httpStatus) {
        String code = errorCode.getCode();
        String msg = errorCode.getDescription() + exception.getMessage();
        ErrorResponse errorResponse = new ErrorResponse(code, msg, httpStatus);
        return errorResponse;
    }
}
