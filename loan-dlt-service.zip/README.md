# Spring Boot Application  
  
## Built With  
For building and running the application you need:  
  
- JDK 1.8  
- Spring Boot Version 2.0.2.RELEASE  
- Gradle 4.10.3  
- Corda release version 4.0  
   
CorDapp dependenices :

- cordapp-commons-0.1.0
- contracts-states-abstract-flows-0.1.0
- investor-workflows-0.1.0
- servicer-workflows-0.1.0

You need to build and install CorDaap, So Jar will store to your local repository, from there service will get jars.

Running the application  
In the loan-dlt-service directory, open console and build the app.  
  
### `gradlew clean build`  
  
  
Your app is ready to run!  
  
Run jar of individual party.  
  
Goto the lib folder of party and run following command.  
  
### `java -jar "name of jar file"`
  
Example : To run investor  : 'java -jar investor-0.1.0'  
  
  
## Files and Directories  
  
The project has a particular directory structure. A representative project is shown below:  
  
```  
loan-dlt-service  
│  
├── Commons  
│  ├── build.gradle  
│  └── src  
│      └── main  
│          └── java  
│              ├── com.loandlt.cordapp.service.commons  
│              ├── com.loandlt.cordapp.service.commons.config  
│              ├── com.loandlt.cordapp.service.commons.aop  
│              ├── com.loandlt.cordapp.service.commons.dao  
│              ├── com.loandlt.cordapp.service.commons.exception  
│              ├── com.loandlt.cordapp.service.commons.model  
│              ├── com.loandlt.cordapp.service.commons.rpc  
│              ├── com.loandlt.cordapp.service.commons.service  
│              └── com.loandlt.cordapp.service.commons.util  
├── investor  
│  ├── build.gradle  
│  └── src  
│      └── main  
│          └── java  
│          │   ├── com.loandlt.cordapp.service.investor  
│          │   ├── com.loandlt.cordapp.service.investor.controller  
│          │   ├── com.loandlt.cordapp.service.investor.model  
│          │   ├── com.loandlt.cordapp.service.investor.service  
│          │   └── com.loandlt.cordapp.service.investor.dao  
│          │  
│          └── resources  
│              ├── application.yml  
│              ├── application-prod.yml  
│              └── logback.xml  
├── servicer  
│  ├── build.gradle  
│  └── src  
│      └── main  
│          └── java  
│          │   ├── com.loandlt.cordapp.service.servicer  
│          │   ├── com.loandlt.cordapp.service.servicer.controller  
│          │   ├── com.loandlt.cordapp.service.servicer.model  
│          │   ├── com.loandlt.cordapp.service.servicer.service  
│          │   └── com.loandlt.cordapp.service.servicer.dao  
│          │  
│          └── resources  
│              ├── application.yml  
│              ├── application-prod.yml  
│              └── logback.xml  
│  
│  
│  
├── gradle  
├── build.gradle  
├── settings.gradle  
├── gradle.properties  
├── gradlew  
└── README.md  
```